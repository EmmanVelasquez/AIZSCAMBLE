<?php
session_start();
require '../includes/db.php';

// Set JSON response header
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$orderId = $_POST['order_id'] ?? null;
$status = $_POST['status'] ?? null;
$userId = $_SESSION['user_id'];

if (!$orderId || !$status) {
    echo json_encode(['success' => false, 'message' => 'Missing required parameters']);
    exit;
}

// Validate status
$allowedStatuses = ['canceled', 'delivered'];
if (!in_array($status, $allowedStatuses)) {
    echo json_encode(['success' => false, 'message' => 'Invalid status']);
    exit;
}

try {
    // Verify the order belongs to the user and check current status
    $stmt = $conn->prepare("SELECT status FROM orders WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $orderId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Order not found']);
        exit;
    }
    
    $order = $result->fetch_assoc();
    $currentStatus = $order['status'];
    
    // Validate status transitions
    if ($status === 'canceled') {
        // Can only cancel pending or approved orders
        if (!in_array($currentStatus, ['pending', 'approved'])) {
            echo json_encode(['success' => false, 'message' => 'Cannot cancel order in current status']);
            exit;
        }
    } elseif ($status === 'delivered') {
        // Can only mark as delivered if out for delivery
        if ($currentStatus !== 'out_for_delivery') {
            echo json_encode(['success' => false, 'message' => 'Can only mark orders as delivered when out for delivery']);
            exit;
        }
    }
    
    // Update the order status
    $updateStmt = $conn->prepare("UPDATE orders SET status = ?, status_updated_at = NOW() WHERE id = ? AND user_id = ?");
    $updateStmt->bind_param("sii", $status, $orderId, $userId);
    
    if ($updateStmt->execute()) {
        echo json_encode([
            'success' => true, 
            'message' => 'Order status updated successfully',
            'new_status' => $status
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update order status']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
