
<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include('../includes/db.php');


if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("HTTP/1.1 403 Forbidden");
    die(json_encode(['success' => false, 'message' => 'Unauthorized access']));
}


$order_id = $_POST['order_id'] ?? null;
$reason = $_POST['reason'] ?? '';


if (!$order_id) {
    die(json_encode(['success' => false, 'message' => 'Missing order ID']));
}

try {
    
    $stmt = $conn->prepare("UPDATE orders SET status = 'canceled', cancel_reason = ? WHERE id = ?");
    $stmt->bind_param("si", $reason, $order_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Database update failed']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}

$stmt->close();
$conn->close();
?>