<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <title>About Us - AIZCAmble | Our Story</title>
    
    <!-- Meta Tags -->
    <meta name="description" content="Discover the story behind AIZCAmble - From a simple idea in 2021 to becoming a beloved part of the Angat Bulacan community.">
    <meta name="keywords" content="AIZCAmble story, ice scramble, mini donuts, Angat Bulacan, food cart, community">
    <meta name="author" content="AIZCAmble Team">
    
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --accent-gold: #F59E0B;
            --accent-gold-light: #FCD34D;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --background-deep-start: #831843;
            --background-deep-end: #BE185D;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --error-color: #EF4444;
            --shadow-pink: rgba(236, 72, 153, 0.3);
            --shadow-strong: rgba(0, 0, 0, 0.25);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-deep-start) 0%, var(--background-deep-end) 50%, var(--primary-pink-dark) 100%);
            color: var(--text-primary);
            overflow-x: hidden;
            position: relative;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: fixed;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, var(--primary-pink) 1px, transparent 1px);
            background-size: 50px 50px;
            animation: backgroundMove 20s linear infinite;
            opacity: 0.1;
            z-index: -2;
        }

        body::after {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(circle at 20% 80%, var(--primary-pink) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, var(--accent-purple) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, var(--secondary-pink) 0%, transparent 50%);
            opacity: 0.15;
            animation: gradientShift 15s ease-in-out infinite;
            z-index: -1;
        }

        @keyframes backgroundMove {
            0% { transform: translate(0, 0) rotate(0deg); }
            100% { transform: translate(50px, 50px) rotate(360deg); }
        }

        @keyframes gradientShift {
            0%, 100% { opacity: 0.15; }
            50% { opacity: 0.25; }
        }

        /* Navigation */
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: var(--surface-white);
            backdrop-filter: blur(25px);
            border-bottom: 1px solid var(--border-light);
            box-shadow: 0 8px 32px var(--shadow-pink);
            z-index: 1000;
            padding: 0;
            transition: all 0.3s ease;
        }

        .navbar.scrolled {
            background: rgba(255, 255, 255, 0.98);
            box-shadow: 0 12px 48px var(--shadow-pink);
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 32px;
        }

        .nav-brand {
            display: flex;
            align-items: center;
            gap: 16px;
            text-decoration: none;
            color: var(--text-primary);
        }

        .nav-logo {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            border: 3px solid var(--primary-pink);
            object-fit: cover;
            transition: all 0.3s ease;
            position: relative;
        }

        .nav-logo::before {
            content: '';
            position: absolute;
            top: -6px;
            left: -6px;
            right: -6px;
            bottom: -6px;
            background: linear-gradient(45deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            border-radius: 50%;
            z-index: -1;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .nav-brand:hover .nav-logo::before {
            opacity: 1;
        }

        .nav-brand:hover .nav-logo {
            transform: scale(1.1) rotate(5deg);
        }

        .brand-text {
            display: flex;
            flex-direction: column;
        }

        .brand-name {
            font-size: 28px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            line-height: 1;
        }

        .brand-tagline {
            font-size: 12px;
            color: var(--text-light);
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 32px;
        }

        .nav-link {
            text-decoration: none;
            color: var(--text-secondary);
            font-weight: 600;
            font-size: 16px;
            padding: 12px 20px;
            border-radius: 12px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
        }

        .nav-link::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(236, 72, 153, 0.1), transparent);
            transition: left 0.5s ease;
        }

        .nav-link:hover::before {
            left: 100%;
        }

        .nav-link:hover {
            color: var(--primary-pink);
            background: rgba(236, 72, 153, 0.1);
            transform: translateY(-2px);
        }

        .nav-link.active {
            color: var(--primary-pink);
            background: rgba(236, 72, 153, 0.1);
        }

        /* Mobile Menu Toggle */
        .mobile-toggle {
            display: none;
            background: none;
            border: none;
            font-size: 24px;
            color: var(--primary-pink);
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .mobile-toggle:hover {
            background: rgba(236, 72, 153, 0.1);
        }

        /* Hero Section */
        .hero-section {
            padding: 120px 32px 80px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .hero-container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .hero-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            padding: 12px 20px;
            border-radius: 50px;
            border: 1px solid var(--border-light);
            box-shadow: 0 8px 32px var(--shadow-pink);
            margin-bottom: 32px;
            font-size: 14px;
            font-weight: 600;
            color: var(--primary-pink);
            animation: slideInDown 1s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .hero-badge i {
            animation: sparkle 2s ease-in-out infinite;
        }

        @keyframes sparkle {
            0%, 100% { transform: scale(1) rotate(0deg); }
            50% { transform: scale(1.2) rotate(180deg); }
        }

        .hero-title {
            font-size: 64px;
            font-weight: 900;
            line-height: 1.1;
            margin-bottom: 24px;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: slideInUp 1s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .hero-subtitle {
            font-size: 24px;
            color: rgba(255, 255, 255, 0.9);
            margin-bottom: 48px;
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
            animation: slideInUp 1s cubic-bezier(0.175, 0.885, 0.32, 1.275) 0.2s both;
        }

        @keyframes slideInDown {
            0% { opacity: 0; transform: translateY(-50px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideInUp {
            0% { opacity: 0; transform: translateY(50px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        /* Story Section */
        .story-section {
            padding: 80px 32px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            position: relative;
        }

        .story-container {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 80px;
            align-items: center;
        }

        .story-content {
            animation: slideInLeft 1s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .story-title {
            font-size: 48px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 24px;
            line-height: 1.2;
        }

        .story-text {
            font-size: 18px;
            color: var(--text-secondary);
            line-height: 1.8;
            margin-bottom: 32px;
            text-align: justify;
        }

        .story-highlights {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 24px;
        }

        .highlight-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 16px;
            background: rgba(236, 72, 153, 0.05);
            border-radius: 12px;
            border: 1px solid var(--border-light);
        }

        .highlight-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 18px;
        }

        .highlight-text {
            font-weight: 600;
            color: var(--text-primary);
        }

        .story-image {
            position: relative;
            animation: slideInRight 1s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .main-image {
            width: 100%;
            height: 500px;
            object-fit: cover;
            border-radius: 24px;
            box-shadow: 0 32px 64px var(--shadow-strong);
            border: 4px solid rgba(255, 255, 255, 0.9);
        }

        @keyframes slideInLeft {
            0% { opacity: 0; transform: translateX(-50px); }
            100% { opacity: 1; transform: translateX(0); }
        }

        @keyframes slideInRight {
            0% { opacity: 0; transform: translateX(50px); }
            100% { opacity: 1; transform: translateX(0); }
        }

        /* Gallery Section */
        .gallery-section {
            padding: 80px 32px;
            background: linear-gradient(135deg, var(--background-gradient-start) 0%, var(--background-gradient-end) 100%);
        }

        .gallery-container {
            max-width: 1400px;
            margin: 0 auto;
            text-align: center;
        }

        .gallery-title {
            font-size: 48px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 24px;
        }

        .gallery-subtitle {
            font-size: 20px;
            color: var(--text-secondary);
            margin-bottom: 64px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 32px;
        }

        .gallery-item {
            position: relative;
            border-radius: 24px;
            overflow: hidden;
            box-shadow: 0 8px 32px var(--shadow-pink);
            transition: all 0.3s ease;
            background: white;
            border: 1px solid var(--border-light);
        }

        .gallery-item:hover {
            transform: translateY(-8px);
            box-shadow: 0 16px 48px var(--shadow-pink);
        }

        .gallery-image {
            width: 100%;
            height: 250px;
            object-fit: cover;
            transition: all 0.3s ease;
        }

        .gallery-item:hover .gallery-image {
            transform: scale(1.05);
        }

        .gallery-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, rgba(236, 72, 153, 0.8), rgba(139, 92, 246, 0.8));
            opacity: 0;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
        }

        .gallery-item:hover .gallery-overlay {
            opacity: 1;
        }

        .gallery-caption {
            padding: 20px;
            text-align: center;
        }

        .gallery-caption h3 {
            font-size: 18px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 8px;
        }

        .gallery-caption p {
            font-size: 14px;
            color: var(--text-secondary);
        }

        /* Timeline Section */
        .timeline-section {
            padding: 80px 32px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
        }

        .timeline-container {
            max-width: 1000px;
            margin: 0 auto;
            text-align: center;
        }

        .timeline-title {
            font-size: 48px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 64px;
        }

        .timeline {
            position: relative;
            padding: 40px 0;
        }

        .timeline::before {
            content: '';
            position: absolute;
            left: 50%;
            top: 0;
            bottom: 0;
            width: 4px;
            background: linear-gradient(180deg, var(--primary-pink), var(--accent-purple));
            transform: translateX(-50%);
        }

        .timeline-item {
            position: relative;
            margin-bottom: 60px;
            display: flex;
            align-items: center;
        }

        .timeline-item:nth-child(odd) {
            flex-direction: row;
        }

        .timeline-item:nth-child(even) {
            flex-direction: row-reverse;
        }

        .timeline-content {
            flex: 1;
            padding: 32px;
            background: white;
            border-radius: 20px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            margin: 0 40px;
            position: relative;
        }

        .timeline-content::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple));
            border-radius: 20px 20px 0 0;
        }

        .timeline-date {
            font-size: 14px;
            font-weight: 700;
            color: var(--primary-pink);
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 12px;
        }

        .timeline-title-item {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 16px;
        }

        .timeline-description {
            font-size: 16px;
            color: var(--text-secondary);
            line-height: 1.6;
        }

        .timeline-marker {
            width: 20px;
            height: 20px;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            border-radius: 50%;
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            z-index: 2;
            border: 4px solid white;
            box-shadow: 0 4px 12px var(--shadow-pink);
        }

        /* Floating particles */
        .floating-element {
            position: absolute;
            border-radius: 50%;
            background: linear-gradient(45deg, var(--primary-pink), var(--secondary-pink));
            animation: float 20s infinite linear;
            pointer-events: none;
            opacity: 0.6;
        }

        .floating-element.pink {
            background: linear-gradient(45deg, var(--secondary-pink), var(--primary-pink-light));
            animation: floatPink 25s infinite linear;
            opacity: 0.4;
        }

        @keyframes float {
            0% {
                transform: translateY(100vh) rotate(0deg) scale(0);
                opacity: 0;
            }
            10% {
                opacity: 0.6;
                transform: translateY(90vh) rotate(36deg) scale(1);
            }
            90% {
                opacity: 0.6;
                transform: translateY(-10vh) rotate(324deg) scale(1);
            }
            100% {
                transform: translateY(-100vh) rotate(360deg) scale(0);
                opacity: 0;
            }
        }

        @keyframes floatPink {
            0% {
                transform: translateY(100vh) rotate(0deg) scale(0);
                opacity: 0;
            }
            15% {
                opacity: 0.4;
                transform: translateY(85vh) rotate(54deg) scale(1);
            }
            85% {
                opacity: 0.4;
                transform: translateY(-15vh) rotate(306deg) scale(1);
            }
            100% {
                transform: translateY(-100vh) rotate(360deg) scale(0);
                opacity: 0;
            }
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .story-container {
                gap: 60px;
            }
            
            .hero-title {
                font-size: 56px;
            }
        }

        @media (max-width: 768px) {
            .mobile-toggle {
                display: block;
            }
            
            .nav-links {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: var(--surface-white);
                backdrop-filter: blur(25px);
                flex-direction: column;
                padding: 20px;
                box-shadow: 0 8px 32px var(--shadow-pink);
                border-top: 1px solid var(--border-light);
            }
            
            .nav-links.open {
                display: flex;
            }
            
            .hero-title {
                font-size: 40px;
            }
            
            .story-container {
                grid-template-columns: 1fr;
                gap: 40px;
                text-align: center;
            }
            
            .story-highlights {
                grid-template-columns: 1fr;
            }
            
            .gallery-grid {
                grid-template-columns: 1fr;
                gap: 24px;
            }
            
            .timeline::before {
                left: 20px;
            }
            
            .timeline-item {
                flex-direction: row !important;
                padding-left: 60px;
            }
            
            .timeline-content {
                margin: 0;
            }
            
            .timeline-marker {
                left: 20px;
            }
        }

        @media (max-width: 480px) {
            .nav-container {
                padding: 12px 20px;
            }
            
            .hero-section {
                padding: 100px 20px 60px;
            }
            
            .hero-title {
                font-size: 32px;
            }
            
            .story-section,
            .gallery-section,
            .timeline-section {
                padding: 60px 20px;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(236, 72, 153, 0.1);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--primary-pink-dark), var(--primary-pink));
        }
    </style>
</head>
<body>
    <!-- Floating Elements -->
    <div class="floating-element" style="left: 5%; width: 6px; height: 6px; animation-delay: 0s;"></div>
    <div class="floating-element pink" style="left: 15%; width: 4px; height: 4px; animation-delay: 3s;"></div>
    <div class="floating-element" style="left: 25%; width: 8px; height: 8px; animation-delay: 6s;"></div>
    <div class="floating-element pink" style="left: 35%; width: 5px; height: 5px; animation-delay: 9s;"></div>
    <div class="floating-element" style="left: 45%; width: 7px; height: 7px; animation-delay: 12s;"></div>
    <div class="floating-element pink" style="left: 55%; width: 4px; height: 4px; animation-delay: 15s;"></div>
    <div class="floating-element" style="left: 65%; width: 6px; height: 6px; animation-delay: 18s;"></div>
    <div class="floating-element pink" style="left: 75%; width: 5px; height: 5px; animation-delay: 21s;"></div>
    <div class="floating-element" style="left: 85%; width: 7px; height: 7px; animation-delay: 24s;"></div>
    <div class="floating-element pink" style="left: 95%; width: 4px; height: 4px; animation-delay: 27s;"></div>

    <!-- Navigation -->
    <nav class="navbar" id="navbar">
        <div class="nav-container">
            <a href="index.php" class="nav-brand">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo" class="nav-logo">
                <div class="brand-text">
                    <div class="brand-name">AIZCAmble</div>
                    <div class="brand-tagline">Our Story</div>
                </div>
            </a>
            
            <div class="nav-links" id="navLinks">
                <a href="index.php" class="nav-link">Home</a>
                <a href="Home.php" class="nav-link">Shop</a>
                <a href="About.php" class="nav-link active">About Us</a>
                <a href="Visit.php" class="nav-link">Visit Us</a>
            </div>
            
            <button class="mobile-toggle" id="mobileToggle">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="hero-container">
            <div class="hero-badge">
                <i class="fas fa-heart"></i>
                Our Journey Since 2021
            </div>
            
            <h1 class="hero-title">About AIZCAmble</h1>
            <p class="hero-subtitle">
                From a simple idea to a beloved community staple in Angat, Bulacan
            </p>
        </div>
    </section>

    <!-- Story Section -->
    <section class="story-section">
        <div class="story-container">
            <div class="story-content">
                <h2 class="story-title">Our Story</h2>
                <p class="story-text">
                    AIZCAmble was launched in 2021 in Sta Cruz Angat Bulacan with a simple yet passionate vision. We began with the concept of producing Ice Scramble and Mini Donuts, inspired by our own creative ideas and online inspiration. Our philosophy was clear: create products that would be simple yet stylized, interesting yet refined, and above all - tasty and homemade.
                </p>
                <p class="story-text">
                    In December 2021, we constructed our first mini cart, strategically positioned in front of our house in Angat Bulacan. What started as a small venture quickly became something special. The community embraced us with open arms, and we've been growing stronger as an integral part of the community ever since.
                </p>
                
                <div class="story-highlights">
                    <div class="highlight-item">
                        <div class="highlight-icon">
                            <i class="fas fa-calendar-alt"></i>
                        </div>
                        <div class="highlight-text">Established 2021</div>
                    </div>
                    <div class="highlight-item">
                        <div class="highlight-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="highlight-text">Angat, Bulacan</div>
                    </div>
                    <div class="highlight-item">
                        <div class="highlight-icon">
                            <i class="fas fa-ice-cream"></i>
                        </div>
                        <div class="highlight-text">Ice Scramble Specialty</div>
                    </div>
                    <div class="highlight-item">
                        <div class="highlight-icon">
                            <i class="fas fa-cookie-bite"></i>
                        </div>
                        <div class="highlight-text">Fresh Mini Donuts</div>
                    </div>
                </div>
            </div>
            
            <div class="story-image">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Story" class="main-image">
            </div>
        </div>
    </section>

    <!-- Gallery Section -->
    <section class="gallery-section">
        <div class="gallery-container">
            <h2 class="gallery-title">Our Journey in Pictures</h2>
            <p class="gallery-subtitle">
                Take a look at our evolution from a simple cart to a beloved community favorite
            </p>
            
            <div class="gallery-grid">
                <div class="gallery-item">
                    <img src="/assets/pic1.jpg" alt="Our Beginning" class="gallery-image">
                    <div class="gallery-overlay">
                        <i class="fas fa-search-plus"></i>
                    </div>
                    <div class="gallery-caption">
                        <h3>Our Beginning</h3>
                        <p>The first steps of our journey in 2021</p>
                    </div>
                </div>
                
                <div class="gallery-item">
                    <img src="/assets/pic 2.jpg" alt="Fresh Preparations" class="gallery-image">
                    <div class="gallery-overlay">
                        <i class="fas fa-search-plus"></i>
                    </div>
                    <div class="gallery-caption">
                        <h3>Fresh Preparations</h3>
                        <p>Making everything fresh daily</p>
                    </div>
                </div>
                
                <div class="gallery-item">
                    <img src="/assets/cart.jpg" alt="Our First Cart" class="gallery-image">
                    <div class="gallery-overlay">
                        <i class="fas fa-search-plus"></i>
                    </div>
                    <div class="gallery-caption">
                        <h3>Our First Cart</h3>
                        <p>The mini cart that started it all</p>
                    </div>
                </div>
                
                <div class="gallery-item">
                    <img src="/assets/pic4.jpg" alt="Community Love" class="gallery-image">
                    <div class="gallery-overlay">
                        <i class="fas fa-search-plus"></i>
                    </div>
                    <div class="gallery-caption">
                        <h3>Community Love</h3>
                        <p>Building relationships with our customers</p>
                    </div>
                </div>
                
                <div class="gallery-item">
                    <img src="/assets/Pic5.jpg" alt="Quality Products" class="gallery-image">
                    <div class="gallery-overlay">
                        <i class="fas fa-search-plus"></i>
                    </div>
                    <div class="gallery-caption">
                        <h3>Quality Products</h3>
                        <p>Always maintaining the highest standards</p>
                    </div>
                </div>
                
                <div class="gallery-item">
                    <img src="/assets/pic6.jpg" alt="Growing Success" class="gallery-image">
                    <div class="gallery-overlay">
                        <i class="fas fa-search-plus"></i>
                    </div>
                    <div class="gallery-caption">
                        <h3>Growing Success</h3>
                        <p>Expanding our reach and impact</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Timeline Section -->
    <section class="timeline-section">
        <div class="timeline-container">
            <h2 class="timeline-title">Our Timeline</h2>
            
            <div class="timeline">
                <div class="timeline-item">
                    <div class="timeline-marker"></div>
                    <div class="timeline-content">
                        <div class="timeline-date">2021 - Beginning</div>
                        <h3 class="timeline-title-item">The Idea is Born</h3>
                        <p class="timeline-description">
                            AIZCAmble was conceptualized with the vision of creating delicious Ice Scramble and Mini Donuts inspired by online creativity and personal passion.
                        </p>
                    </div>
                </div>
                
                <div class="timeline-item">
                    <div class="timeline-marker"></div>
                    <div class="timeline-content">
                        <div class="timeline-date">December 2021</div>
                        <h3 class="timeline-title-item">First Cart Launch</h3>
                        <p class="timeline-description">
                            We constructed our first mini cart and positioned it in front of our house in Angat Bulacan, marking the official start of our business.
                        </p>
                    </div>
                </div>
                
                <div class="timeline-item">
                    <div class="timeline-marker"></div>
                    <div class="timeline-content">
                        <div class="timeline-date">2022 - Growth</div>
                        <h3 class="timeline-title-item">Community Acceptance</h3>
                        <p class="timeline-description">
                            The local community embraced us with open arms, and we began building lasting relationships with our customers.
                        </p>
                    </div>
                </div>
                
                <div class="timeline-item">
                    <div class="timeline-marker"></div>
                    <div class="timeline-content">
                        <div class="timeline-date">Present</div>
                        <h3 class="timeline-title-item">Continuing Legacy</h3>
                        <p class="timeline-description">
                            Today, we continue to grow and look forward to becoming an even larger part of the community each year, maintaining our commitment to quality and taste.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Mobile menu toggle
        const mobileToggle = document.getElementById('mobileToggle');
        const navLinks = document.getElementById('navLinks');

        mobileToggle.addEventListener('click', function() {
            navLinks.classList.toggle('open');
            const icon = this.querySelector('i');
            if (navLinks.classList.contains('open')) {
                icon.className = 'fas fa-times';
            } else {
                icon.className = 'fas fa-bars';
            }
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!navLinks.contains(event.target) && !mobileToggle.contains(event.target)) {
                navLinks.classList.remove('open');
                mobileToggle.querySelector('i').className = 'fas fa-bars';
            }
        });

        // Parallax effect for floating elements
        document.addEventListener('mousemove', function(e) {
            const mouseX = e.clientX / window.innerWidth;
            const mouseY = e.clientY / window.innerHeight;
            
            // Move floating elements based on mouse position
            document.querySelectorAll('.floating-element').forEach((element, index) => {
                const speed = (index % 3 + 1) * 0.5;
                const x = (mouseX - 0.5) * speed * 20;
                const y = (mouseY - 0.5) * speed * 20;
                element.style.transform = `translate(${x}px, ${y}px)`;
            });
        });

        // Gallery image hover effects
        document.querySelectorAll('.gallery-item').forEach(item => {
            item.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-12px) scale(1.02)';
            });
            
            item.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(-8px) scale(1)';
            });
        });

        // Timeline animation on scroll
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        // Observe timeline items
        document.querySelectorAll('.timeline-item').forEach((item, index) => {
            item.style.opacity = '0';
            item.style.transform = 'translateY(30px)';
            item.style.transition = `all 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275) ${index * 0.1}s`;
            observer.observe(item);
        });

        // Observe gallery items
        document.querySelectorAll('.gallery-item').forEach((item, index) => {
            item.style.opacity = '0';
            item.style.transform = 'translateY(30px)';
            item.style.transition = `all 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275) ${index * 0.1}s`;
            observer.observe(item);
        });

        // Enhanced brand interaction
        document.querySelector('.nav-brand').addEventListener('mouseenter', function() {
            this.querySelector('.brand-name').style.transform = 'scale(1.05)';
            this.querySelector('.brand-tagline').style.color = 'var(--primary-pink)';
        });

        document.querySelector('.nav-brand').addEventListener('mouseleave', function() {
            this.querySelector('.brand-name').style.transform = 'scale(1)';
            this.querySelector('.brand-tagline').style.color = 'var(--text-light)';
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Loading animation
        window.addEventListener('load', function() {
            document.body.style.opacity = '0';
            document.body.style.transition = 'opacity 0.5s ease';
            
            setTimeout(() => {
                document.body.style.opacity = '1';
            }, 100);
        });

        // Dynamic background color shifts
        setInterval(() => {
            const hue = Math.random() * 30 + 320; // Pink to purple range
            document.documentElement.style.setProperty('--dynamic-bg', `hsl(${hue}, 70%, 15%)`);
        }, 5000);
    </script>
</body>
</html>
