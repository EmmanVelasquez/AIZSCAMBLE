<?php
function deductIngredientsForOrder($conn, $order_id) {
    $deducted = [];

    $item_stmt = $conn->prepare("SELECT product_id, quantity FROM order_items WHERE order_id = ?");
    $item_stmt->bind_param("i", $order_id);
    $item_stmt->execute();
    $items_result = $item_stmt->get_result();

    while ($item = $items_result->fetch_assoc()) {
        $product_id = $item['product_id'];
        $ordered_quantity = $item['quantity'];

        $ing_stmt = $conn->prepare("SELECT ingredient_id, quantity FROM product_ingredients WHERE product_id = ?");
        $ing_stmt->bind_param("i", $product_id);
        $ing_stmt->execute();
        $ingredients_result = $ing_stmt->get_result();

        while ($ingredient = $ingredients_result->fetch_assoc()) {
            $ingredient_id = $ingredient['ingredient_id'];
            $required_per_product = $ingredient['quantity'];
            $sales_quantity = $required_per_product * $ordered_quantity;

            // Get the latest stock (this is our quantity_on_hand)
            $stock_stmt = $conn->prepare("SELECT stock, unit, name FROM ingredients WHERE id = ?");
            $stock_stmt->bind_param("i", $ingredient_id);
            $stock_stmt->execute();
            $stock_result = $stock_stmt->get_result();

            if ($stock_result->num_rows === 0) {
                return ['success' => false, 'message' => "Ingredient ID $ingredient_id not found."];
            }

            $stock = $stock_result->fetch_assoc();
            $quantity_on_hand = $stock['stock']; // This will never change here
            $unit = $stock['unit'];
            $ingredient_name = $stock['name'];

            // Compute current stock
            $current_stock = $quantity_on_hand - $sales_quantity;
            if ($current_stock < 0) $current_stock = 0;

            // Update stock in ingredients table
            $update_stmt = $conn->prepare("UPDATE ingredients SET stock = ? WHERE id = ?");
            $update_stmt->bind_param("di", $current_stock, $ingredient_id);
            $update_stmt->execute();

            // Log movement - REMEMBER: quantity_on_hand remains as-is
            $movement_stmt = $conn->prepare("INSERT INTO ingredient_movements (
                ingredient_id, quantity_before, sales_quantity, current_stock, restock_quantity, movement_date
            ) VALUES (?, ?, ?, ?, 0, NOW())");

            $movement_stmt->bind_param("iddd", $ingredient_id, $quantity_on_hand, $sales_quantity, $current_stock);
            $movement_stmt->execute();

            $deducted[] = [
                'name' => $ingredient_name,
                'unit' => $unit,
                'used' => $sales_quantity,
                'before' => $quantity_on_hand,
                'after' => $current_stock
            ];
        }
    }

    return ['success' => true, 'deducted_ingredients' => $deducted];
}
?>
