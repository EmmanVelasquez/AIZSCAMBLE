<?php
session_start();
include('../includes/db.php');

if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    die("Unauthorized access");
}

$order_id = $_GET['id'] ?? 0;

// Get order info
$order_stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$order_stmt->bind_param("i", $order_id);
$order_stmt->execute();
$order = $order_stmt->get_result()->fetch_assoc();

// Get order items
$items_stmt = $conn->prepare("
    SELECT oi.*, p.name AS product_name 
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = ?
");
$items_stmt->bind_param("i", $order_id);
$items_stmt->execute();
$items = $items_stmt->get_result();
?>

<div class="order-details-container">
    <h2>Order #<?= $order_id ?> Details</h2>
    
    <div class="order-info-section">
        <div class="info-row">
            <span class="info-label">Status:</span>
            <span class="info-value status-<?= $order['status'] ?>">
                <?= ucfirst(str_replace('_', ' ', $order['status'])) ?>
            </span>
        </div>
        
        <div class="info-row">
            <span class="info-label">Date:</span>
            <span class="info-value"><?= date('M d, Y h:i A', strtotime($order['created_at'])) ?></span>
        </div>
        
        <div class="info-row">
            <span class="info-label">Payment Method:</span>
            <span class="info-value"><?= strtoupper($order['payment_method']) ?></span>
        </div>
        
        <div class="info-row">
            <span class="info-label">Delivery Area:</span>
            <span class="info-value"><?= $order['area'] ?></span>
        </div>
        
        <div class="info-row">
            <span class="info-label">Landmark:</span>
            <span class="info-value"><?= $order['landmark'] ?></span>
        </div>
        
        <div class="info-row">
            <span class="info-label">Total Amount:</span>
            <span class="info-value">₱<?= number_format($order['total_amount'], 2) ?></span>
        </div>
    </div>

    <?php if ($order['payment_method'] == 'gcash' && !empty($order['receipt_image'])): ?>
        <div class="receipt-section">
            <h3>GCASH Receipt</h3>
            <img src="<?= $order['receipt_image'] ?>" alt="GCASH Receipt" class="receipt-img">
            <?php if (!empty($order['transaction_id'])): ?>
                <div class="info-row">
                    <span class="info-label">Transaction ID:</span>
                    <span class="info-value"><?= $order['transaction_id'] ?></span>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div class="order-items-section">
        <h3>Order Items</h3>
        <table class="order-items-table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Subtotal</th>
                    <?php if ($_GET['show_customizations'] ?? false): ?>
                        <th>Customizations</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php while ($item = $items->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($item['product_name']) ?></td>
                        <td>₱<?= number_format($item['price'], 2) ?></td>
                        <td><?= $item['quantity'] ?></td>
                        <td>₱<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                        <?php if ($_GET['show_customizations'] ?? false): ?>
                            <td>
                                <?php if (!empty($item['customizations'])): ?>
                                    <?php 
                                    $customizations = json_decode($item['customizations'], true);
                                    if ($customizations): ?>
                                        <div class="customization-details">
                                            <?php foreach ($customizations as $option => $value): ?>
                                                <div class="customization-item">
                                                    <strong><?= htmlspecialchars($option) ?>:</strong>
                                                    <?php if (is_array($value)): ?>
                                                        <?= htmlspecialchars(implode(', ', $value)) ?>
                                                    <?php else: ?>
                                                        <?= htmlspecialchars($value) ?>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    None
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <div class="order-summary">
        <div class="summary-row">
            <span class="summary-label">Delivery Fee:</span>
            <span class="summary-value">₱<?= number_format($order['delivery_fee'], 2) ?></span>
        </div>
        <div class="summary-row total">
            <span class="summary-label">Grand Total:</span>
            <span class="summary-value">₱<?= number_format($order['total_amount'], 2) ?></span>
        </div>
    </div>
</div>

<style>
    .order-details-container {
        font-family: 'Roboto', sans-serif;
        max-width: 1000px;
        margin: 0 auto;
        padding: 20px;
        color: #333;
    }

    .order-info-section, .receipt-section, .order-items-section {
        margin-bottom: 30px;
        padding: 20px;
        background: white;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }

    .info-row {
        display: flex;
        margin-bottom: 10px;
        padding-bottom: 10px;
        border-bottom: 1px solid #f0f0f0;
    }

    .info-label {
        font-weight: bold;
        min-width: 150px;
        color: #555;
    }

    .info-value {
        flex: 1;
    }

    .receipt-img {
        max-width: 100%;
        height: auto;
        margin-top: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
    }

    .order-items-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
    }

    .order-items-table th {
        background: #f8f8f8;
        padding: 12px;
        text-align: left;
        font-weight: 500;
        color: #555;
    }

    .order-items-table td {
        padding: 12px;
        border-bottom: 1px solid #eee;
    }

    .order-items-table tr:hover {
        background-color: #f9f9f9;
    }

    .customization-details {
        font-size: 14px;
    }

    .customization-item {
        margin: 5px 0;
    }

    .customization-item strong {
        color: #666;
    }

    .order-summary {
        text-align: right;
        margin-top: 20px;
        padding: 20px;
        background: white;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }

    .summary-row {
        margin-bottom: 10px;
    }

    .summary-row.total {
        font-size: 18px;
        font-weight: bold;
        margin-top: 10px;
        padding-top: 10px;
        border-top: 1px solid #eee;
    }

    .summary-label {
        display: inline-block;
        min-width: 150px;
        text-align: right;
        margin-right: 20px;
    }

    .summary-value {
        display: inline-block;
        min-width: 100px;
        text-align: right;
    }

    /* Status colors to match main system */
    .status-pending { color: #FF9800; }
    .status-approved { color: #9C27B0; }
    .status-preparing { color: #FFC107; }
    .status-out_for_delivery { color: #00BCD4; }
    .status-delivered { color: #4CAF50; }
    .status-rejected { color: #F44336; }
    .status-canceled { color: #9E9E9E; }
</style>