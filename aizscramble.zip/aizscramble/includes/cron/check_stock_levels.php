<?php
// This script is meant to be run via cron job to check stock levels daily
// Example cron: 0 9 * * * php /path/to/check_stock_levels.php

// Include necessary files
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/notify_helper.php';

// Define stock thresholds
define('STOCK_LOW_THRESHOLD', 10);
define('STOCK_CRITICAL_THRESHOLD', 5);

// Check products with low stock
$low_stock_products = $conn->query("SELECT id, name, stock FROM products WHERE stock <= " . STOCK_LOW_THRESHOLD);
while ($product = $low_stock_products->fetch_assoc()) {
    if ($product['stock'] <= STOCK_CRITICAL_THRESHOLD) {
        $message = "CRITICAL: Product '{$product['name']}' stock is very low ({$product['stock']} units remaining)!";
        addAdminNotification($conn, $message, "Critical Stock Alert");
    } else {
        $message = "Product '{$product['name']}' stock is running low ({$product['stock']} units remaining).";
        addAdminNotification($conn, $message, "Low Stock Alert");
    }
}

// Check ingredients with low stock
$low_stock_ingredients = $conn->query("SELECT id, name, stock FROM ingredients WHERE stock <= " . STOCK_LOW_THRESHOLD);
while ($ingredient = $low_stock_ingredients->fetch_assoc()) {
    if ($ingredient['stock'] <= STOCK_CRITICAL_THRESHOLD) {
        $message = "CRITICAL: Ingredient '{$ingredient['name']}' stock is very low ({$ingredient['stock']} units remaining)!";
        addAdminNotification($conn, $message, "Critical Ingredient Alert");
    } else {
        $message = "Ingredient '{$ingredient['name']}' stock is running low ({$ingredient['stock']} units remaining).";
        addAdminNotification($conn, $message, "Low Ingredient Alert");
    }
}

// Check products that can't be made due to ingredient shortages
$product_availability = [];
$ingredient_result = $conn->query("
    SELECT p.id AS product_id, p.name AS product_name, i.id AS ingredient_id, 
           pi.quantity AS required, i.stock AS available, i.name AS ingredient_name
    FROM products p
    JOIN product_ingredients pi ON p.id = pi.product_id
    JOIN ingredients i ON pi.ingredient_id = i.id
");

while ($row = $ingredient_result->fetch_assoc()) {
    if (!isset($product_availability[$row['product_id']])) {
        $product_availability[$row['product_id']] = [
            'name' => $row['product_name'],
            'can_make' => PHP_INT_MAX,
            'limiting_ingredient' => null
        ];
    }
    
    $can_make = floor($row['available'] / $row['required']);
    if ($can_make < $product_availability[$row['product_id']]['can_make']) {
        $product_availability[$row['product_id']]['can_make'] = $can_make;
        $product_availability[$row['product_id']]['limiting_ingredient'] = $row['ingredient_name'];
    }
}

// Generate notifications for products that can't be made
foreach ($product_availability as $product_id => $data) {
    if ($data['can_make'] <= STOCK_CRITICAL_THRESHOLD) {
        $message = "CRITICAL: Cannot make enough '{$data['name']}' due to low '{$data['limiting_ingredient']}' stock. Can only make {$data['can_make']} units!";
        addAdminNotification($conn, $message, "Production Alert");
    }
}

echo "Stock check completed at " . date('Y-m-d H:i:s') . "\n";
?>