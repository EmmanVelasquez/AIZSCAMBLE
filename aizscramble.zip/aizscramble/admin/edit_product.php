<?php
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/log_activity.php';
require_once __DIR__ . '/../includes/notify_helper.php'; // Added notification helper

if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../user/login.php");
    exit;
}

// Fetch notifications for the dropdown
$notifQuery = $conn->query("SELECT * FROM AdminNotifications ORDER BY CreatedAt DESC LIMIT 5");
$unreadCount = $conn->query("SELECT COUNT(*) as total FROM AdminNotifications WHERE IsRead = 0")->fetch_assoc()['total'];

// Mark notifications as read if requested
if (isset($_GET['mark_read']) && $_GET['mark_read'] == 'all') {
    $conn->query("UPDATE AdminNotifications SET IsRead = 1 WHERE IsRead = 0");
    header("Location: edit_product.php?id=" . ($_GET['id'] ?? ''));
    exit;
}

$product_id = $_GET['id'] ?? null;
if (!$product_id) {
    header("Location: stock.php");
    exit;
}

$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    header("Location: stock.php");
    exit;
}

$original_data = $product;

// Fetch customizable options
$options = [];
$stmt = $conn->prepare("SELECT * FROM customizable_options WHERE product_id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $options[$row['option_name']][] = $row;
}

// Fetch ingredients
$ingredients = [];
$product_ingredients = [];
$result = $conn->query("SELECT id, name, unit FROM ingredients ORDER BY name");
if ($result) $ingredients = $result->fetch_all(MYSQLI_ASSOC);

$result = $conn->query("SELECT pi.ingredient_id, pi.quantity, i.name, i.unit FROM product_ingredients pi JOIN ingredients i ON pi.ingredient_id = i.id WHERE pi.product_id = $product_id");
if ($result) $product_ingredients = $result->fetch_all(MYSQLI_ASSOC);

// Handle stock adjustment
if (isset($_POST['adjust_stock'])) {
    $adjustment = intval($_POST['stock_adjustment']);
    $adjustment_type = $_POST['adjustment_type'];
    
    // Calculate new stock value
    $current_stock = $product['stock'];
    $new_stock = $current_stock;
    
    if ($adjustment_type === 'add') {
        $new_stock = $current_stock + $adjustment;
    } else if ($adjustment_type === 'remove') {
        $new_stock = max(0, $current_stock - $adjustment); // Ensure stock doesn't go below 0
    }
    
    // Update the stock in database
    $stmt = $conn->prepare("UPDATE products SET stock = ? WHERE id = ?");
    $stmt->bind_param("ii", $new_stock, $product_id);
    
    if ($stmt->execute()) {
        // Log the activity
        $user_id = $_SESSION['user_id'];
        $role = 'admin';
        $action = "";
        
        if ($adjustment_type === 'add') {
            $action = "Added $adjustment units to stock for product ID $product_id ({$product['name']}). Stock changed from $current_stock to $new_stock.";
        } else {
            $actual_adjustment = $current_stock - $new_stock; // In case it was limited by the zero floor
            $action = "Removed $actual_adjustment units from stock for product ID $product_id ({$product['name']}). Stock changed from $current_stock to $new_stock.";
        }
        
        $log_sql = "INSERT INTO ActivityLog (user_id, role, action) VALUES (?, ?, ?)";
        $log_stmt = $conn->prepare($log_sql);
        $log_stmt->bind_param("iss", $user_id, $role, $action);
        $log_stmt->execute();
        
        $_SESSION['message'] = "Stock successfully updated from $current_stock to $new_stock!";
        
        // Refresh the product data
        $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();
        $original_data = $product;
    } else {
        $_SESSION['error'] = "Failed to update stock.";
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['adjust_stock'])) {
    $name = $_POST['name'];
    $price = floatval($_POST['price']);
    $stock = intval($_POST['stock']);
    $is_customizable = isset($_POST['is_customizable']) ? 1 : 0;
    $description = $_POST['description'] ?? '';
    $remove_image = isset($_POST['remove_image']);
    $image_path = $product['image'];
    $update_successful = false;

    try {
        $conn->begin_transaction();

        if (!empty($_FILES['product_image']['name'])) {
            if ($image_path && file_exists($image_path)) unlink($image_path);
            $image_name = time() . "_" . basename($_FILES["product_image"]["name"]);
            $target_file = "../uploads/" . $image_name;
            if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
                $image_path = $target_file;
            }
        } elseif ($remove_image && $image_path) {
            if (file_exists($image_path)) unlink($image_path);
            $image_path = null;
        }

        $sql = "UPDATE products SET name=?, price=?, stock=?, is_customizable=?, description=?";
        $types = "sdiis";
        $params = [$name, $price, $stock, $is_customizable, $description];

        if ($image_path !== $product['image']) {
            $sql .= ", image=?";
            $types .= "s";
            $params[] = $image_path;
        }

        $sql .= " WHERE id=?";
        $types .= "i";
        $params[] = $product_id;

        $stmt = $conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();

        $stmt = $conn->prepare("DELETE FROM customizable_options WHERE product_id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();

        if ($is_customizable) {
            $customOptions = [
                'Size' => ['names' => $_POST['size_names'] ?? [], 'prices' => $_POST['size_prices'] ?? []],
                'Flavor' => ['names' => $_POST['flavor_names'] ?? [], 'prices' => $_POST['flavor_prices'] ?? []],
                'Add-on' => ['names' => $_POST['add_on_names'] ?? [], 'prices' => $_POST['add_on_prices'] ?? []]
            ];
            foreach ($customOptions as $type => $data) {
                $stmt = $conn->prepare("INSERT INTO customizable_options (product_id, option_name, option_value, price) VALUES (?, ?, ?, ?)");
                foreach ($data['names'] as $i => $val) {
                    if (!empty($val) && isset($data['prices'][$i])) {
                        $stmt->bind_param("issd", $product_id, $type, $val, $data['prices'][$i]);
                        $stmt->execute();
                    }
                }
            }
        }

        $stmt = $conn->prepare("DELETE FROM product_ingredients WHERE product_id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();

        if (!empty($_POST['ingredient_id'])) {
            foreach ($_POST['ingredient_id'] as $i => $ingredient_id) {
                $quantity = floatval($_POST['ingredient_quantity'][$i]);
                if ($ingredient_id && $quantity > 0) {
                    $stmt = $conn->prepare("INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES (?, ?, ?)");
                    $stmt->bind_param("iid", $product_id, $ingredient_id, $quantity);
                    $stmt->execute();
                }
            }
        }

        $conn->commit();
        $update_successful = true;

    } catch (Exception $e) {
        $conn->rollback();
        $error = "Error: " . $e->getMessage();
    }

    if ($update_successful) {
        try {
            $user_id = $_SESSION['user_id'];
            $role = 'admin';

            $changes = [];
            if ($original_data['name'] !== $name) $changes[] = "Name: '{$original_data['name']}' → '$name'";
            if ($original_data['price'] != $price) $changes[] = "Price: ₱{$original_data['price']} → ₱$price";
            if ($original_data['stock'] != $stock) $changes[] = "Stock: {$original_data['stock']} → $stock";
            if ($original_data['is_customizable'] != $is_customizable) $changes[] = "Customizable: {$original_data['is_customizable']} → $is_customizable";
            if ($original_data['description'] !== $description) $changes[] = "Description updated";
            if ($image_path !== $original_data['image']) $changes[] = "Image updated";

            $changes_str = implode("; ", $changes);
            $action = "Edited product ID $product_id ($name). Changes: $changes_str";

            $log_sql = "INSERT INTO ActivityLog (user_id, role, action) VALUES (?, ?, ?)";
            $log_stmt = $conn->prepare($log_sql);
            $log_stmt->bind_param("iss", $user_id, $role, $action);
            $log_stmt->execute();

            $_SESSION['message'] = "Product updated successfully!";
        } catch (Exception $e) {
            error_log("Log failed: " . $e->getMessage());
            $_SESSION['message'] = "Product updated successfully, but activity log failed.";
        }

        header("Location: edit_product.php?id=$product_id");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - AIZCAmble | Admin Dashboard</title>
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    
    <!-- Meta Tags -->
    <meta name="description" content="Edit product details, manage stock, and update customizations in AIZCAmble admin dashboard.">
    <meta name="keywords" content="AIZCAmble admin, edit product, stock management, product customization">
    <meta name="author" content="AIZCAmble Team">
    
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --accent-gold: #F59E0B;
            --accent-gold-light: #FCD34D;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --background-deep-start: #831843;
            --background-deep-end: #BE185D;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --error-color: #EF4444;
            --shadow-pink: rgba(236, 72, 153, 0.3);
            --shadow-strong: rgba(0, 0, 0, 0.25);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-deep-start) 0%, var(--background-deep-end) 50%, var(--primary-pink-dark) 100%);
            color: var(--text-primary);
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .left-nav {
            width: 280px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            padding: 24px;
            box-shadow: 4px 0 20px var(--shadow-pink);
            border-right: 1px solid var(--border-light);
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
        }

        .nav-logo {
            text-align: center;
            margin-bottom: 32px;
        }

        .nav-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid var(--primary-pink);
            object-fit: cover;
        }

        .nav-title {
            color: var(--text-primary);
            text-align: center;
            margin-bottom: 32px;
            font-size: 20px;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 16px 20px;
            margin-bottom: 8px;
            background: rgba(236, 72, 153, 0.05);
            color: var(--text-primary);
            text-decoration: none;
            border-radius: 12px;
            font-weight: 500;
            transition: all 0.3s ease;
            border: 1px solid transparent;
        }

        .nav-link:hover {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            transform: translateX(4px);
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        .nav-link.active {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 40px;
            min-height: 100vh;
        }

        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            padding: 24px 32px;
            border-radius: 16px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
        }

        .page-title {
            font-size: 32px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        /* Notification Bell */
        .notification-bell {
            position: relative;
            display: inline-block;
        }

        .notification-bell button {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: white;
            width: 48px;
            height: 48px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 15px var(--shadow-pink);
            transition: all 0.3s ease;
        }

        .notification-bell button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px var(--shadow-pink);
        }

        .notification-badge {
            position: absolute;
            top: -6px;
            right: -6px;
            background: var(--error-color);
            color: white;
            border-radius: 50%;
            padding: 4px 8px;
            font-size: 12px;
            font-weight: 700;
            min-width: 20px;
            text-align: center;
        }

        .notification-dropdown {
            display: none;
            position: absolute;
            right: 0;
            top: 60px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            width: 350px;
            box-shadow: 0 16px 48px var(--shadow-pink);
            border-radius: 16px;
            z-index: 1000;
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid var(--border-light);
        }

        .notification-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 20px;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            color: white;
            border-top-left-radius: 16px;
            border-top-right-radius: 16px;
            font-weight: 600;
        }

        .notification-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .notification-dropdown li {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border-light);
            transition: background 0.2s ease;
        }

        .notification-dropdown li:hover {
            background: rgba(236, 72, 153, 0.05);
        }

        .notification-footer {
            padding: 16px 20px;
            text-align: center;
            border-top: 1px solid var(--border-light);
        }

        .notification-footer a {
            color: var(--primary-pink);
            text-decoration: none;
            font-weight: 600;
        }

        /* Cards */
        .data-card {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 16px;
            padding: 32px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            margin-bottom: 24px;
            border: 1px solid var(--border-light);
            position: relative;
            overflow: hidden;
        }

        .data-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .card-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 24px;
            padding-bottom: 12px;
            border-bottom: 2px solid var(--border-light);
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* Alerts */
        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.5s ease;
        }

        .alert-success {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(5, 150, 105, 0.1));
            color: var(--success-color);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .alert-danger {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(220, 38, 38, 0.1));
            color: var(--error-color);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        @keyframes slideIn {
            0% { transform: translateY(-20px); opacity: 0; }
            100% { transform: translateY(0); opacity: 1; }
        }

        /* Stock Management */
        .stock-display {
            background: linear-gradient(135deg, rgba(236, 72, 153, 0.05), rgba(139, 92, 246, 0.05));
            padding: 24px;
            border-radius: 12px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 20px;
            border: 1px solid var(--border-light);
        }

        .stock-value {
            font-size: 36px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .stock-label {
            font-size: 14px;
            color: var(--text-secondary);
            font-weight: 500;
        }

        .stock-controls {
            display: flex;
            gap: 20px;
            margin-bottom: 24px;
            align-items: flex-end;
        }

        .stock-input {
            flex: 1;
            max-width: 200px;
        }

        .stock-actions {
            display: flex;
            gap: 12px;
        }

        /* Form Elements */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            font-size: 15px;
            color: var(--text-primary);
        }

        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--border-light);
            border-radius: 12px;
            font-size: 15px;
            font-family: 'Poppins', sans-serif;
            transition: all 0.3s ease;
            background: white;
        }

        .form-control:focus {
            border-color: var(--primary-pink);
            outline: none;
            box-shadow: 0 0 0 3px rgba(236, 72, 153, 0.1);
        }

        .grid-2 {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 24px;
        }

        /* Option Containers */
        .option-container {
            border: 2px solid var(--border-light);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 24px;
            background: rgba(255, 255, 255, 0.5);
        }

        .option-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .option-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-primary);
        }

        .option-group, .ingredient-row {
            display: flex;
            gap: 12px;
            margin-bottom: 12px;
            align-items: center;
        }

        .option-input, .ingredient-select {
            flex: 2;
        }

        .option-price, .ingredient-quantity {
            flex: 1;
        }

        .option-action, .ingredient-action {
            flex-shrink: 0;
        }

        /* Image Preview */
        .image-preview {
            margin-top: 12px;
            margin-bottom: 20px;
        }

        .preview-img {
            max-width: 200px;
            max-height: 200px;
            border: 2px solid var(--border-light);
            border-radius: 12px;
            margin-bottom: 12px;
            object-fit: cover;
        }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 12px 24px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border: none;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            font-family: 'Poppins', sans-serif;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px var(--shadow-pink);
        }

        .btn-danger {
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
            box-shadow: 0 4px 15px rgba(239, 68, 68, 0.3);
        }

        .btn-danger:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(239, 68, 68, 0.4);
        }

        .btn-secondary {
            background: linear-gradient(135deg, var(--text-light), var(--text-secondary));
            color: white;
            box-shadow: 0 4px 15px rgba(107, 114, 128, 0.3);
        }

        .btn-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(107, 114, 128, 0.4);
        }

        /* Mobile Responsive */
        @media (max-width: 1024px) {
            .left-nav {
                width: 240px;
            }
            
            .main-content {
                margin-left: 240px;
                padding: 24px;
            }
        }

        @media (max-width: 768px) {
            .left-nav {
                position: fixed;
                transform: translateX(-100%);
                transition: transform 0.3s ease;
                z-index: 2000;
            }
            
            .left-nav.open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
            
            .grid-2 {
                grid-template-columns: 1fr;
            }
            
            .header-container {
                flex-direction: column;
                gap: 16px;
                text-align: center;
            }
            
            .stock-controls {
                flex-direction: column;
                align-items: stretch;
            }
            
            .stock-actions {
                justify-content: center;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(236, 72, 153, 0.1);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--primary-pink-dark), var(--primary-pink));
        }
    </style>
</head>
<body>
    <div class="left-nav">
        <div class="nav-logo">
            <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo">
        </div>

        <h3 class="nav-title">Admin Panel</h3>
        
        <a href="dashboard.php" class="nav-link">
            <i class="fas fa-chart-line"></i>
            Dashboard
        </a>
        <a href="orders.php" class="nav-link">
            <i class="fas fa-shopping-bag"></i>
            Manage Orders
        </a>
        <a href="add_product.php" class="nav-link">
            <i class="fas fa-plus-circle"></i>
            Add Product
        </a>
        <a href="stock.php" class="nav-link active">
            <i class="fas fa-boxes"></i>
            Stock Management
        </a>
        <a href="sales_analytics.php" class="nav-link">
            <i class="fas fa-chart-bar"></i>
            Sales Analytics
        </a>
        <a href="users.php" class="nav-link">
            <i class="fas fa-users"></i>
            Customers
        </a>
        <a href="ingredients.php" class="nav-link">
            <i class="fas fa-flask"></i>
            Ingredients
        </a>
        <a href="admins.php" class="nav-link">
            <i class="fas fa-user-shield"></i>
            Admins
        </a>
        <a href="shutdown.php" class="nav-link">
            <i class="fas fa-power-off"></i>
            Shutdown Shop
        </a>
        <a href="activity_log.php" class="nav-link">
            <i class="fas fa-history"></i>
            Activity History
        </a>
        <a href="notifications.php" class="nav-link">
            <i class="fas fa-bell"></i>
            Notifications
        </a>
        <a href="../logout.php" class="nav-link">
            <i class="fas fa-sign-out-alt"></i>
            Logout
        </a>
    </div>

    <div class="main-content">
        <div class="header-container">
            <h1 class="page-title">
                <i class="fas fa-edit"></i>
                Edit Product: <?= htmlspecialchars($product['name']) ?>
            </h1>
            
            <!-- Notification Bell -->
            <div class="notification-bell">
                <button onclick="toggleDropdown()">
                    <i class="fas fa-bell"></i>
                    <?php if ($unreadCount > 0): ?>
                        <span class="notification-badge">
                            <?= $unreadCount ?>
                        </span>
                    <?php endif; ?>
                </button>
                <div id="notifDropdown" class="notification-dropdown">
                    <div class="notification-header">
                        <span>Notifications</span>
                        <?php if ($unreadCount > 0): ?>
                            <a href="edit_product.php?id=<?= $product_id ?>&mark_read=all" style="color: white; font-size: 12px;">Mark all as read</a>
                        <?php endif; ?>
                    </div>
                    <ul>
                        <?php if ($notifQuery->num_rows > 0): ?>
                            <?php while ($notif = $notifQuery->fetch_assoc()): ?>
                                <li style="<?= $notif['IsRead'] ? '' : 'background-color: rgba(236, 72, 153, 0.05);' ?>">
                                    <strong><?= htmlspecialchars($notif['Title']) ?></strong><br>
                                    <small><?= htmlspecialchars($notif['message']) ?></small><br>
                                    <small style="color: #888;"><?= date('M d, Y h:i A', strtotime($notif['CreatedAt'])) ?></small>
                                </li>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <li>No notifications yet</li>
                        <?php endif; ?>
                    </ul>
                    <div class="notification-footer">
                        <a href="notifications.php">View All Notifications</a>
                    </div>
                </div>
            </div>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle"></i>
                <?= $error ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?= $_SESSION['message'] ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle"></i>
                <?= $_SESSION['error'] ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <!-- Stock Adjustment Card -->
        <div class="data-card">
            <h3 class="card-title">
                <i class="fas fa-warehouse"></i>
                Stock Management
            </h3>
            <div class="stock-display">
                <div>
                    <div class="stock-label">Current Stock</div>
                    <div class="stock-value"><?= $product['stock'] ?></div>
                </div>
                <div>
                    <div class="stock-label">units available</div>
                </div>
            </div>
            
            <form method="POST">
                <div class="stock-controls">
                    <div class="stock-input">
                        <label for="stock_adjustment">
                            <i class="fas fa-calculator"></i>
                            Adjustment Quantity
                        </label>
                        <input type="number" id="stock_adjustment" name="stock_adjustment" class="form-control" min="1" value="1" required>
                        <input type="hidden" name="adjustment_type" id="adjustment_type" value="add">
                    </div>
                    
                    <div class="stock-actions">
                        <button type="submit" name="adjust_stock" class="btn btn-primary" onclick="document.getElementById('adjustment_type').value='add'">
                            <i class="fas fa-plus"></i>
                            Add Stock
                        </button>
                        <button type="submit" name="adjust_stock" class="btn btn-danger" onclick="document.getElementById('adjustment_type').value='remove'">
                            <i class="fas fa-minus"></i>
                            Remove Stock
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Product Edit Form -->
        <div class="data-card">
            <h3 class="card-title">
                <i class="fas fa-edit"></i>
                Product Details
            </h3>
            <form method="POST" enctype="multipart/form-data">
                <div class="grid-2">
                    <div class="form-group">
                        <label for="name">
                            <i class="fas fa-tag"></i>
                            Product Name
                        </label>
                        <input type="text" id="name" name="name" class="form-control" value="<?= htmlspecialchars($product['name']) ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="price">
                            <i class="fas fa-peso-sign"></i>
                            Price (₱)
                        </label>
                        <input type="number" id="price" name="price" class="form-control" step="0.01" value="<?= $product['price'] ?>" required>
                    </div>
                </div>
                
                <div class="grid-2">
                    <div class="form-group">
                        <label for="stock">
                            <i class="fas fa-boxes"></i>
                            Stock
                        </label>
                        <input type="number" id="stock" name="stock" class="form-control" value="<?= $product['stock'] ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
                            <input type="checkbox" id="toggleCustom" name="is_customizable" <?= $product['is_customizable'] ? 'checked' : '' ?> style="width: auto;">
                            <label for="toggleCustom" style="margin: 0;">
                                <i class="fas fa-cogs"></i>
                                Customizable Product
                            </label>
                        </div>
                        <small style="color: var(--text-secondary);">Enable this if the product has customizable options like sizes, flavors, or add-ons</small>
                    </div>
                </div>
                
                <div id="customOptions" style="display:<?= $product['is_customizable'] ? 'block' : 'none' ?>;">
                    <!-- Sizes Options -->
                    <div class="option-container">
                        <div class="option-header">
                            <h4 class="option-title">
                                <i class="fas fa-expand-arrows-alt"></i>
                                Sizes
                            </h4>
                            <button type="button" class="btn btn-primary" onclick="addSize()">
                                <i class="fas fa-plus"></i>
                                Add Size
                            </button>
                        </div>
                        
                        <div id="sizes-container">
                            <?php if (isset($options['Size'])): ?>
                                <?php foreach ($options['Size'] as $opt): ?>
                                    <div class="option-group">
                                        <div class="option-input">
                                            <input type="text" name="size_names[]" class="form-control" value="<?= htmlspecialchars($opt['option_value']) ?>" placeholder="Size Name">
                                        </div>
                                        <div class="option-price">
                                            <input type="number" step="0.01" name="size_prices[]" class="form-control" value="<?= $opt['price'] ?>" placeholder="Price">
                                        </div>
                                        <div class="option-action">
                                            <button type="button" class="btn btn-danger" onclick="this.parentNode.parentNode.remove()">
                                                <i class="fas fa-trash"></i>
                                                Remove
                                            </button>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Flavors Options -->
                    <div class="option-container">
                        <div class="option-header">
                            <h4 class="option-title">
                                <i class="fas fa-ice-cream"></i>
                                Flavors
                            </h4>
                            <button type="button" class="btn btn-primary" onclick="addFlavor()">
                                <i class="fas fa-plus"></i>
                                Add Flavor
                            </button>
                        </div>
                        
                        <div id="flavors-container">
                            <?php if (isset($options['Flavor'])): ?>
                                <?php foreach ($options['Flavor'] as $opt): ?>
                                    <div class="option-group">
                                        <div class="option-input">
                                            <input type="text" name="flavor_names[]" class="form-control" value="<?= htmlspecialchars($opt['option_value']) ?>" placeholder="Flavor">
                                        </div>
                                        <div class="option-price">
                                            <input type="number" step="0.01" name="flavor_prices[]" class="form-control" value="<?= $opt['price'] ?>" placeholder="Price">
                                        </div>
                                        <div class="option-action">
                                            <button type="button" class="btn btn-danger" onclick="this.parentNode.parentNode.remove()">
                                                <i class="fas fa-trash"></i>
                                                Remove
                                            </button>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Add-ons Options -->
                    <div class="option-container">
                        <div class="option-header">
                            <h4 class="option-title">
                                <i class="fas fa-plus-circle"></i>
                                Add-ons
                            </h4>
                            <button type="button" class="btn btn-primary" onclick="addAddOn()">
                                <i class="fas fa-plus"></i>
                                Add Add-on
                            </button>
                        </div>
                        
                        <div id="addons-container">
                            <?php if (isset($options['Add-on'])): ?>
                                <?php foreach ($options['Add-on'] as $opt): ?>
                                    <div class="option-group">
                                        <div class="option-input">
                                            <input type="text" name="add_on_names[]" class="form-control" value="<?= htmlspecialchars($opt['option_value']) ?>" placeholder="Add-on">
                                        </div>
                                        <div class="option-price">
                                            <input type="number" step="0.01" name="add_on_prices[]" class="form-control" value="<?= $opt['price'] ?>" placeholder="Price">
                                        </div>
                                        <div class="option-action">
                                            <button type="button" class="btn btn-danger" onclick="this.parentNode.parentNode.remove()">
                                                <i class="fas fa-trash"></i>
                                                Remove
                                            </button>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Ingredients Section -->
                <div class="option-container">
                    <div class="option-header">
                        <h4 class="option-title">
                            <i class="fas fa-flask"></i>
                            Ingredients
                        </h4>
                        <button type="button" class="btn btn-primary" onclick="addIngredient()">
                            <i class="fas fa-plus"></i>
                            Add Ingredient
                        </button>
                    </div>
                    
                    <div id="ingredients-container">
                        <?php foreach ($product_ingredients as $pi): ?>
                            <div class="ingredient-row">
                                <div class="ingredient-select">
                                    <select name="ingredient_id[]" class="form-control">
                                        <option value="">Select Ingredient</option>
                                        <?php foreach ($ingredients as $ing): ?>
                                            <option value="<?= $ing['id'] ?>" <?= $pi['ingredient_id'] == $ing['id'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($ing['name']) ?> (<?= htmlspecialchars($ing['unit']) ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="ingredient-quantity">
                                    <input type="number" step="0.01" name="ingredient_quantity[]" class="form-control" value="<?= $pi['quantity'] ?>" placeholder="Quantity">
                                </div>
                                <div class="ingredient-action">
                                    <button type="button" class="btn btn-danger" onclick="this.parentNode.parentNode.remove()">
                                        <i class="fas fa-trash"></i>
                                        Remove
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <?php if (empty($product_ingredients)): ?>
                            <div class="ingredient-row">
                                <div class="ingredient-select">
                                    <select name="ingredient_id[]" class="form-control">
                                        <option value="">Select Ingredient</option>
                                        <?php foreach ($ingredients as $ing): ?>
                                            <option value="<?= $ing['id'] ?>"><?= htmlspecialchars($ing['name']) ?> (<?= htmlspecialchars($ing['unit']) ?>)</option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="ingredient-quantity">
                                    <input type="number" step="0.01" name="ingredient_quantity[]" class="form-control" placeholder="Quantity">
                                </div>
                                <div class="ingredient-action">
                                    <button type="button" class="btn btn-danger" onclick="this.parentNode.parentNode.remove()">
                                        <i class="fas fa-trash"></i>
                                        Remove
                                    </button>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="description">
                        <i class="fas fa-align-left"></i>
                        Description
                    </label>
                    <textarea id="description" name="description" class="form-control" rows="4" placeholder="Enter product description..."><?= htmlspecialchars($product['description']) ?></textarea>
                </div>
                
                <div class="form-group">
                    <label>
                        <i class="fas fa-image"></i>
                        Product Image
                    </label>
                    <?php if ($product['image']): ?>
                        <div class="image-preview">
                            <img src="<?= $product['image'] ?>" class="preview-img" alt="<?= htmlspecialchars($product['name']) ?>">
                            <div style="display: flex; align-items: center; gap: 8px; margin-top: 8px;">
                                <input type="checkbox" id="remove_image" name="remove_image" style="width: auto;">
                                <label for="remove_image" style="margin: 0;">Remove current image</label>
                            </div>
                        </div>
                    <?php endif; ?>
                    <input type="file" id="product_image" name="product_image" class="form-control" accept="image/*">
                    <small style="color: var(--text-secondary); margin-top: 8px; display: block;">Upload a new image to replace the current one. Recommended size: 800x600 pixels.</small>
                </div>
                
                <div class="form-group" style="display: flex; gap: 16px; justify-content: center; margin-top: 32px;">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i>
                        Update Product
                    </button>
                    <a href="stock.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i>
                        Back to Stock
                    </a>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Toggle customizable options
        document.getElementById('toggleCustom').addEventListener('change', function() {
            document.getElementById('customOptions').style.display = this.checked ? 'block' : 'none';
        });

        // Add size option
        function addSize() {
            const div = document.createElement('div');
            div.className = 'option-group';
            div.innerHTML = `
                <div class="option-input">
                    <input type="text" name="size_names[]" class="form-control" placeholder="Size Name">
                </div>
                <div class="option-price">
                    <input type="number" step="0.01" name="size_prices[]" class="form-control" placeholder="Price">
                </div>
                <div class="option-action">
                    <button type="button" class="btn btn-danger" onclick="this.parentNode.parentNode.remove()">
                        <i class="fas fa-trash"></i>
                        Remove
                    </button>
                </div>
            `;
            document.getElementById('sizes-container').appendChild(div);
        }

        // Add flavor option
        function addFlavor() {
            const div = document.createElement('div');
            div.className = 'option-group';
            div.innerHTML = `
                <div class="option-input">
                    <input type="text" name="flavor_names[]" class="form-control" placeholder="Flavor">
                </div>
                <div class="option-price">
                    <input type="number" step="0.01" name="flavor_prices[]" class="form-control" placeholder="Price">
                </div>
                <div class="option-action">
                    <button type="button" class="btn btn-danger" onclick="this.parentNode.parentNode.remove()">
                        <i class="fas fa-trash"></i>
                        Remove
                    </button>
                </div>
            `;
            document.getElementById('flavors-container').appendChild(div);
        }

        // Add add-on option
        function addAddOn() {
            const div = document.createElement('div');
            div.className = 'option-group';
            div.innerHTML = `
                <div class="option-input">
                    <input type="text" name="add_on_names[]" class="form-control" placeholder="Add-on">
                </div>
                <div class="option-price">
                    <input type="number" step="0.01" name="add_on_prices[]" class="form-control" placeholder="Price">
                </div>
                <div class="option-action">
                    <button type="button" class="btn btn-danger" onclick="this.parentNode.parentNode.remove()">
                        <i class="fas fa-trash"></i>
                        Remove
                    </button>
                </div>
            `;
            document.getElementById('addons-container').appendChild(div);
        }

        // Add ingredient
        function addIngredient() {
            const div = document.createElement('div');
            div.className = 'ingredient-row';
            div.innerHTML = `
                <div class="ingredient-select">
                    <select name="ingredient_id[]" class="form-control">
                        <option value="">Select Ingredient</option>
                        <?php foreach ($ingredients as $ing): ?>
                            <option value="<?= $ing['id'] ?>"><?= htmlspecialchars($ing['name']) ?> (<?= htmlspecialchars($ing['unit']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="ingredient-quantity">
                    <input type="number" step="0.01" name="ingredient_quantity[]" class="form-control" placeholder="Quantity">
                </div>
                <div class="ingredient-action">
                    <button type="button" class="btn btn-danger" onclick="this.parentNode.parentNode.remove()">
                        <i class="fas fa-trash"></i>
                        Remove
                    </button>
                </div>
            `;
            document.getElementById('ingredients-container').appendChild(div);
        }
        
        // Notification dropdown toggle
        function toggleDropdown() {
            const dropdown = document.getElementById('notifDropdown');
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        }

        // Close dropdown when clicking outside
        window.addEventListener('click', function(event) {
            const dropdown = document.getElementById('notifDropdown');
            const bell = document.querySelector('.notification-bell button');
            if (!bell.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = 'none';
            }
        });

        // Enhanced button interactions
        document.querySelectorAll('.btn:not(:disabled)').forEach(btn => {
            btn.addEventListener('click', function(e) {
                // Add ripple effect
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.cssText = `
                    width: ${size}px;
                    height: ${size}px;
                    left: ${x}px;
                    top: ${y}px;
                    position: absolute;
                    border-radius: 50%;
                    background: rgba(255, 255, 255, 0.4);
                    transform: scale(0);
                    animation: rippleEffect 0.6s ease-out;
                    pointer-events: none;
                `;
                
                this.style.position = 'relative';
                this.style.overflow = 'hidden';
                this.appendChild(ripple);
                
                setTimeout(() => ripple.remove(), 600);
            });
        });

        // Add ripple animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes rippleEffect {
                0% {
                    transform: scale(0);
                    opacity: 1;
                }
                100% {
                    transform: scale(4);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>
