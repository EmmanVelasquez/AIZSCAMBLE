<?php
// Prevent any output before JSON response
ob_start();
error_reporting(0); // Suppress PHP warnings in production
ini_set('display_errors', 0);

session_start();
require('../includes/db.php');

// Include optional files only if they exist
if (file_exists('../includes/log_activity.php')) {
    require_once('../includes/log_activity.php');
}

// Set JSON content type
header('Content-Type: application/json');

// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    ob_clean();
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Check if required parameters are provided
if (!isset($_POST['order_id']) || !isset($_POST['status'])) {
    ob_clean();
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Order ID and status are required']);
    exit;
}

$order_id = intval($_POST['order_id']);
$new_status = trim($_POST['status']);

// Validate status
$valid_statuses = ['pending', 'approved', 'preparing', 'out_for_delivery', 'delivered', 'rejected', 'canceled'];
if (!in_array($new_status, $valid_statuses)) {
    ob_clean();
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid status']);
    exit;
}

// Helper function to create admin notifications
function createAdminNotification($conn, $title, $message) {
    try {
        $stmt = $conn->prepare("INSERT INTO adminnotifications (Title, message) VALUES (?, ?)");
        if ($stmt) {
            $stmt->bind_param("ss", $title, $message);
            $stmt->execute();
            $stmt->close();
            return true;
        }
        return false;
    } catch (Exception $e) {
        error_log("Failed to create admin notification: " . $e->getMessage());
        return false;
    }
}

try {
    $conn->autocommit(false); // Start transaction
    
    // Get current order details
    $stmt = $conn->prepare("
        SELECT o.*, u.name as customer_name, u.email as customer_email 
        FROM orders o
        JOIN users u ON o.user_id = u.id
        WHERE o.id = ?
    ");
    
    if (!$stmt) {
        throw new Exception('Database prepare failed: ' . $conn->error);
    }
    
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception('Order not found');
    }
    
    $order = $result->fetch_assoc();
    $old_status = $order['status'];
    $stmt->close();
    
    // Check if status change is valid
    if ($old_status === $new_status) {
        throw new Exception('Order is already in this status');
    }
    
    // Handle inventory restoration if order is being rejected/canceled
    if (($new_status === 'rejected' || $new_status === 'canceled') && 
        ($old_status === 'approved' || $old_status === 'preparing' || $old_status === 'out_for_delivery')) {
        
        // Get order items to restore inventory
        $items_stmt = $conn->prepare("
            SELECT oi.product_id, oi.quantity, p.name as product_name
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            WHERE oi.order_id = ?
        ");
        
        if (!$items_stmt) {
            throw new Exception('Failed to prepare items query: ' . $conn->error);
        }
        
        $items_stmt->bind_param("i", $order_id);
        $items_stmt->execute();
        $items_result = $items_stmt->get_result();
        
        while ($item = $items_result->fetch_assoc()) {
            $product_id = $item['product_id'];
            $quantity = $item['quantity'];
            $product_name = $item['product_name'];
            
            // Check if product_ingredients table exists
            $pi_table_check = $conn->query("SHOW TABLES LIKE 'product_ingredients'");
            if (!$pi_table_check || $pi_table_check->num_rows === 0) {
                // Skip ingredient processing if table doesn't exist
                continue;
            }
            
            // Check if product uses ingredients
            $ingredient_check = $conn->prepare("
                SELECT COUNT(*) as count FROM product_ingredients WHERE product_id = ?
            ");
            
            if (!$ingredient_check) {
                continue; // Skip this item if query fails
            }
            
            $ingredient_check->bind_param("i", $product_id);
            $ingredient_check->execute();
            $ingredient_check->bind_result($has_ingredients);
            $ingredient_check->fetch();
            $ingredient_check->close();
            
            if ($has_ingredients > 0) {
                // Restore ingredients by adding back the quantities
                $ingredient_stmt = $conn->prepare("
                    SELECT pi.ingredient_id, pi.quantity as required_per_unit, i.name as ingredient_name
                    FROM product_ingredients pi
                    JOIN ingredients i ON pi.ingredient_id = i.id
                    WHERE pi.product_id = ?
                ");
                
                if (!$ingredient_stmt) {
                    continue; // Skip if query fails
                }
                
                $ingredient_stmt->bind_param("i", $product_id);
                $ingredient_stmt->execute();
                $ingredient_result = $ingredient_stmt->get_result();
                
                while ($ingredient_row = $ingredient_result->fetch_assoc()) {
                    $ingredient_id = $ingredient_row['ingredient_id'];
                    $required_per_unit = floatval($ingredient_row['required_per_unit']);
                    $total_to_restore = $required_per_unit * $quantity;
                    $ingredient_name = $ingredient_row['ingredient_name'];
                    
                    // Check if ingredient_movements table exists
                    $im_table_check = $conn->query("SHOW TABLES LIKE 'ingredient_movements'");
                    if ($im_table_check && $im_table_check->num_rows > 0) {
                        // Get current QOH before restoration
                        $qoh_stmt = $conn->prepare("
                            SELECT 
                                GREATEST(0, COALESCE(SUM(restock_quantity), 0) - COALESCE(SUM(sales_quantity), 0)) as current_qoh
                            FROM ingredient_movements 
                            WHERE ingredient_id = ?
                        ");
                        
                        if ($qoh_stmt) {
                            $qoh_stmt->bind_param("i", $ingredient_id);
                            $qoh_stmt->execute();
                            $qoh_result = $qoh_stmt->get_result();
                            
                            if ($qoh_result && $qoh_result->num_rows > 0) {
                                $qoh_row = $qoh_result->fetch_assoc();
                                $quantity_before = floatval($qoh_row['current_qoh'] ?? 0);
                            } else {
                                $quantity_before = 0;
                            }
                            $qoh_stmt->close();
                            
                            $current_stock = $quantity_before + $total_to_restore;
                            
                            // Record the restoration movement
                            $movement_stmt = $conn->prepare("
                                INSERT INTO ingredient_movements 
                                (ingredient_id, quantity_before, sales_quantity, current_stock, restock_quantity, notes, created_by)
                                VALUES (?, ?, 0, ?, ?, ?, ?)
                            ");
                            
                            if ($movement_stmt) {
                                $notes = "Inventory restored - Order #$order_id $new_status ($product_name)";
                                $movement_stmt->bind_param("idddsi", 
                                    $ingredient_id, 
                                    $quantity_before, 
                                    $current_stock, 
                                    $total_to_restore, 
                                    $notes, 
                                    $_SESSION['user_id']
                                );
                                $movement_stmt->execute();
                                $movement_stmt->close();
                            }
                        }
                    }
                    
                    // Update ingredient quantity for consistency
                    $update_stmt = $conn->prepare("UPDATE ingredients SET quantity = quantity + ? WHERE id = ?");
                    if ($update_stmt) {
                        $update_stmt->bind_param("di", $total_to_restore, $ingredient_id);
                        $update_stmt->execute();
                        $update_stmt->close();
                    }
                }
                $ingredient_stmt->close();
            } else {
                // Check if products table has stock column
                $stock_column_check = $conn->query("SHOW COLUMNS FROM products LIKE 'stock'");
                if ($stock_column_check && $stock_column_check->num_rows > 0) {
                    // Restore product stock directly
                    $stock_stmt = $conn->prepare("
                        UPDATE products 
                        SET stock = stock + ? 
                        WHERE id = ?
                    ");
                    if ($stock_stmt) {
                        $stock_stmt->bind_param("ii", $quantity, $product_id);
                        $stock_stmt->execute();
                        $stock_stmt->close();
                    }
                }
            }
        }
        $items_stmt->close();
    }
    
    // Update order status
    $update_stmt = $conn->prepare("
        UPDATE orders 
        SET status = ?, status_updated_at = NOW() 
        WHERE id = ?
    ");
    
    if (!$update_stmt) {
        throw new Exception('Failed to prepare status update: ' . $conn->error);
    }
    
    $update_stmt->bind_param("si", $new_status, $order_id);
    $update_stmt->execute();
    $update_stmt->close();
    
    // Log the activity if function exists
    if (function_exists('logActivity')) {
        try {
            logActivity(
                $conn, 
                $_SESSION['user_id'], 
                'admin', 
                "Updated Order #$order_id status from '$old_status' to '$new_status' for customer '{$order['customer_name']}'"
            );
        } catch (Exception $e) {
            // Log activity failed, but don't break the main operation
            error_log("Failed to log activity: " . $e->getMessage());
        }
    }
    
    // Create notification
    try {
        $notification_title = "Order #$order_id Status Updated";
        
        switch ($new_status) {
            case 'approved':
                $notification_message = "Order #$order_id has been approved and is ready for preparation";
                break;
            case 'preparing':
                $notification_message = "Order #$order_id is now being prepared in the kitchen";
                break;
            case 'out_for_delivery':
                $notification_message = "Order #$order_id is out for delivery to {$order['customer_name']}";
                break;
            case 'delivered':
                $notification_message = "Order #$order_id has been successfully delivered to {$order['customer_name']}";
                break;
            case 'rejected':
                $notification_message = "Order #$order_id has been rejected. Inventory has been restored.";
                break;
            case 'canceled':
                $notification_message = "Order #$order_id has been canceled. Inventory has been restored.";
                break;
            default:
                $status_display = ucfirst(str_replace('_', ' ', $new_status));
                $notification_message = "Order #$order_id status changed to '$status_display' for customer {$order['customer_name']}";
        }
        
        createAdminNotification($conn, $notification_title, $notification_message);
    } catch (Exception $e) {
        // Notification failed, but don't break the main operation
        error_log("Failed to create notification: " . $e->getMessage());
    }
    
    $conn->commit();
    
    // Clean output buffer and send JSON
    ob_clean();
    echo json_encode([
        'success' => true, 
        'message' => "Order status updated successfully",
        'old_status' => $old_status,
        'new_status' => $new_status
    ]);
    
} catch (Exception $e) {
    $conn->rollback();
    ob_clean();
    error_log("Error updating order status: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} finally {
    $conn->autocommit(true);
}
?>