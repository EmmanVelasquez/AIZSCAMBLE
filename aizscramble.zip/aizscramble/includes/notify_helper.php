<?php
/**
 * Helper function to add admin notifications
 * 
 * @param mysqli $conn Database connection
 * @param string $message Notification message
 * @param string $type Notification type/title
 * @return bool Success status
 */
function addAdminNotification($conn, $message, $type = 'Info') {
    if (!$conn || !$message) return false;

    $stmt = $conn->prepare("INSERT INTO AdminNotifications (Title, message) VALUES (?, ?)");
    return $stmt->bind_param("ss", $type, $message) && $stmt->execute();
}

/**
 * Helper function to mark a notification as read
 * 
 * @param mysqli $conn Database connection
 * @param int $notificationId Notification ID
 * @return bool Success status
 */
function markNotificationAsRead($conn, $notificationId) {
    if (!$conn || !$notificationId) return false;
    
    $stmt = $conn->prepare("UPDATE AdminNotifications SET IsRead = 1 WHERE id = ?");
    return $stmt->bind_param("i", $notificationId) && $stmt->execute();
}

/**
 * Helper function to get unread notification count
 * 
 * @param mysqli $conn Database connection
 * @return int Unread notification count
 */
function getUnreadNotificationCount($conn) {
    if (!$conn) return 0;
    
    $result = $conn->query("SELECT COUNT(*) as total FROM AdminNotifications WHERE IsRead = 0");
    if ($result) {
        return $result->fetch_assoc()['total'];
    }
    return 0;
}

/**
 * Helper function to get recent notifications
 * 
 * @param mysqli $conn Database connection
 * @param int $limit Number of notifications to retrieve
 * @return array Notifications
 */
function getRecentNotifications($conn, $limit = 5) {
    if (!$conn) return [];
    
    $result = $conn->query("SELECT * FROM AdminNotifications ORDER BY CreatedAt DESC LIMIT $limit");
    if ($result) {
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    return [];
}

/**
 * Helper function to check if a similar notification exists within a time period
 * Prevents duplicate notifications for the same issue
 * 
 * @param mysqli $conn Database connection
 * @param string $title Notification title to check
 * @param string $message_contains Text that should be in the message
 * @param int $hours Time window in hours
 * @return bool Whether a similar notification exists
 */
function similarNotificationExists($conn, $title, $message_contains, $hours = 24) {
    if (!$conn) return false;
    
    $title = $conn->real_escape_string($title);
    $message_contains = $conn->real_escape_string($message_contains);
    
    $sql = "SELECT COUNT(*) as count FROM AdminNotifications 
            WHERE Title LIKE '%$title%' 
            AND message LIKE '%$message_contains%' 
            AND CreatedAt > DATE_SUB(NOW(), INTERVAL $hours HOUR)";
    
    $result = $conn->query($sql);
    if ($result) {
        return $result->fetch_assoc()['count'] > 0;
    }
    return false;
}

/**
 * Helper function to add a stock alert notification
 * Only adds if a similar notification doesn't exist in the last 24 hours
 * 
 * @param mysqli $conn Database connection
 * @param string $item_name Name of the product or ingredient
 * @param int $stock Current stock level
 * @param string $type Either 'product' or 'ingredient'
 * @return bool Success status
 */
function addStockAlertNotification($conn, $item_name, $stock, $type = 'product') {
    if (!$conn || !$item_name) return false;
    
    // Define thresholds
    $critical_threshold = 2;
    $low_threshold = 5;
    
    // Skip if stock is adequate
    if ($stock > $low_threshold) return true;
    
    // Determine notification type and message
    if ($stock <= $critical_threshold) {
        $title = "Critical " . ucfirst($type) . " Alert";
        $message = "CRITICAL: " . ucfirst($type) . " '$item_name' stock is very low ($stock units remaining)!";
    } else {
        $title = "Low " . ucfirst($type) . " Alert";
        $message = ucfirst($type) . " '$item_name' stock is running low ($stock units remaining).";
    }
    
    // Check if a similar notification already exists
    if (similarNotificationExists($conn, $title, $item_name)) {
        return true; // Skip creating duplicate notification
    }
    
    // Add the notification
    return addAdminNotification($conn, $message, $title);
}

/**
 * Helper function to add a stock update notification
 * 
 * @param mysqli $conn Database connection
 * @param string $item_name Name of the product or ingredient
 * @param float $old_stock Previous stock level
 * @param float $new_stock New stock level
 * @param string $type Either 'product' or 'ingredient'
 * @return bool Success status
 */
function addStockUpdateNotification($conn, $item_name, $old_stock, $new_stock, $type = 'product') {
    if (!$conn || !$item_name || $old_stock == $new_stock) return false;
    
    $action = ($old_stock < $new_stock) ? "increased" : "decreased";
    $message = ucfirst($type) . " '$item_name' stock $action from $old_stock to $new_stock by admin.";
    $title = ucfirst($type) . " Update";
    
    return addAdminNotification($conn, $message, $title);
}
?>
