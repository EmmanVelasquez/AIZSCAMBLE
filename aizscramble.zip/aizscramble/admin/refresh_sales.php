<?php
include('../includes/db.php');


error_log("Sales data refresh triggered");

$today = date('Y-m-d');
$week_start = date('Y-m-d', strtotime('last Sunday'));
$month_start = date('Y-m-01');
$year_start = date('Y-01-01');

$daily_sql = "SELECT SUM(total_amount) as daily_total FROM orders WHERE DATE(created_at) = ? AND status = 'approve'";
$stmt = $conn->prepare($daily_sql);
$stmt->bind_param("s", $today);
$stmt->execute();
$daily_result = $stmt->get_result()->fetch_assoc();
$daily_total = $daily_result['daily_total'] ?? 0;

$weekly_sql = "SELECT SUM(total_amount) as weekly_total FROM orders WHERE DATE(created_at) >= ? AND status = 'approve'";
$stmt = $conn->prepare($weekly_sql);
$stmt->bind_param("s", $week_start);
$stmt->execute();
$weekly_result = $stmt->get_result()->fetch_assoc();
$weekly_total = $weekly_result['weekly_total'] ?? 0;

$monthly_sql = "SELECT SUM(total_amount) as monthly_total FROM orders WHERE DATE(created_at) >= ? AND status = 'approve'";
$stmt = $conn->prepare($monthly_sql);
$stmt->bind_param("s", $month_start);
$stmt->execute();
$monthly_result = $stmt->get_result()->fetch_assoc();
$monthly_total = $monthly_result['monthly_total'] ?? 0;

$yearly_sql = "SELECT SUM(total_amount) as yearly_total FROM orders WHERE DATE(created_at) >= ? AND status = 'approve'";
$stmt = $conn->prepare($yearly_sql);
$stmt->bind_param("s", $year_start);
$stmt->execute();
$yearly_result = $stmt->get_result()->fetch_assoc();
$yearly_total = $yearly_result['yearly_total'] ?? 0;


error_log("Sales Data: Daily: $daily_total, Weekly: $weekly_total, Monthly: $monthly_total, Yearly: $yearly_total");


echo json_encode([
    'daily_total' => $daily_total,
    'weekly_total' => $weekly_total,
    'monthly_total' => $monthly_total,
    'yearly_total' => $yearly_total
]);
?>
