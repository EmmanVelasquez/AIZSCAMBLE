<?php
session_start();
require('../includes/db.php');

// Check if admin is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../user/login.php");
    exit;
}

// Check if product ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['message'] = 'Invalid product ID';
    header("Location: stock.php");
    exit;
}

$product_id = (int)$_GET['id'];

try {
    // Start transaction
    $conn->begin_transaction();
    
    // First delete from product_ingredients to avoid foreign key constraint errors
    $stmt = $conn->prepare("DELETE FROM product_ingredients WHERE product_id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    
    // Then delete the product
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    
    // Commit transaction
    $conn->commit();
    
    $_SESSION['message'] = 'Product deleted successfully!';
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    $_SESSION['message'] = 'Error deleting product: ' . $e->getMessage();
}

header("Location: stock.php");
exit;
?>
