<?php
session_start();
require '../includes/db.php';

$cart = $_SESSION['cart'] ?? [];
$user_id = $_SESSION['user_id'] ?? null;

if (empty($cart) || !$user_id) {
    header('Location: cart.php');
    exit;
}

// Check ingredient availability before allowing checkout
$canCheckout = true;
$outOfStockItems = [];
foreach ($cart as $item) {
    $productId = $item['id'];
    
    // Get all ingredients needed for this product
    $stmt = $conn->prepare("
        SELECT i.id, i.name, i.quantity as available, pi.quantity as required 
        FROM product_ingredients pi
        JOIN ingredients i ON pi.ingredient_id = i.id
        WHERE pi.product_id = ?
    ");
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // If no ingredients defined, check product stock directly
    if ($result->num_rows === 0) {
        $stmt = $conn->prepare("SELECT stock FROM products WHERE id = ?");
        $stmt->bind_param("i", $productId);
        $stmt->execute();
        $stmt->bind_result($stock);
        $stmt->fetch();
        $stmt->close();
        
        if ($item['quantity'] > $stock) {
            $canCheckout = false;
            $outOfStockItems[] = [
                'product' => $item['name'],
                'issue' => "Product stock: Needs {$item['quantity']} (only $stock available)"
            ];
        }
        continue;
    }
    
    // Check each ingredient with dynamic QOH calculation
    while ($ingredient = $result->fetch_assoc()) {
        // Calculate dynamic QOH for this ingredient
        $qoh_stmt = $conn->prepare("
            SELECT 
                GREATEST(0, COALESCE(SUM(restock_quantity), 0) - COALESCE(SUM(sales_quantity), 0)) as current_qoh
            FROM ingredient_movements 
            WHERE ingredient_id = ?
        ");
        $qoh_stmt->bind_param("i", $ingredient['id']);
        $qoh_stmt->execute();
        $qoh_result = $qoh_stmt->get_result();
        $qoh_row = $qoh_result->fetch_assoc();
        $current_qoh = $qoh_row['current_qoh'] ?? 0;
        $qoh_stmt->close();
        
        $needed = $ingredient['required'] * $item['quantity'];
        if ($needed > $current_qoh) {
            $canCheckout = false;
            $outOfStockItems[] = [
                'product' => $item['name'],
                'issue' => "Ingredient '{$ingredient['name']}': Needs $needed (only {$current_qoh} available)"
            ];
            break;
        }
    }
    $stmt->close();
}

// Redirect back to cart if items are out of stock
if (!$canCheckout) {
    $_SESSION['checkout_error'] = $outOfStockItems;
    header('Location: cart.php');
    exit;
}

// Calculate total with customizations
$total = 0;
foreach ($cart as $item) {
    $total += $item['price'] * $item['quantity'];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $payment_method = $_POST['payment_method'] ?? '';
    $area = $_POST['area'] ?? '';
    $landmark = $_POST['landmark'] ?? '';
    $transaction_id = $_POST['transaction_id'] ?? null;
    $receipt_image = null;

    // Handle file upload
    if ($payment_method === 'gcash' && isset($_FILES['receipt_image'])) {
        // Check for upload errors
        if ($_FILES['receipt_image']['error'] !== UPLOAD_ERR_OK) {
            $_SESSION['checkout_error'] = "File upload error. Please try again.";
            header("Location: checkout.php");
            exit;
        }
        
        // Check file type
        $allowed = ['image/jpeg', 'image/png', 'image/gif'];
        if (!in_array($_FILES['receipt_image']['type'], $allowed)) {
            $_SESSION['checkout_error'] = "Only JPG, PNG, and GIF images are allowed";
            header("Location: checkout.php");
            exit;
        }
        
        $target_dir = "../uploads/receipts/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0755, true);
        }
        
        $unique_name = time() . '_' . basename($_FILES["receipt_image"]["name"]);
        $target_file = $target_dir . $unique_name;
        
        if (move_uploaded_file($_FILES["receipt_image"]["tmp_name"], $target_file)) {
            $receipt_image = $target_file;
        } else {
            $_SESSION['checkout_error'] = "Failed to upload receipt image";
            header("Location: checkout.php");
            exit;
        }
    }

    try {
        $conn->autocommit(false); // Start transaction

        // 1. Create order with 'area' instead of 'place'
        $stmt = $conn->prepare("
            INSERT INTO orders 
            (user_id, total_amount, payment_method, area, landmark, transaction_id, receipt_image, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
        ");
        $stmt->bind_param(
            "idsssss", 
            $user_id, 
            $total, 
            $payment_method, 
            $area, 
            $landmark, 
            $transaction_id, 
            $receipt_image
        );
        $stmt->execute();
        $order_id = $stmt->insert_id;
        $stmt->close();

        // 2. Add order items and deduct inventory
        foreach ($cart as $item) {
            // Add to order items
            $stmt = $conn->prepare("
                INSERT INTO order_items 
                (order_id, product_id, quantity, price, customizations)
                VALUES (?, ?, ?, ?, ?)
            ");
            $customizations = json_encode($item['customizations'] ?? []);
            $stmt->bind_param(
                "iiids", 
                $order_id, 
                $item['id'], 
                $item['quantity'], 
                $item['price'], 
                $customizations
            );
            $stmt->execute();
            $stmt->close();

            // Check if product uses ingredients
            $stmt = $conn->prepare("
                SELECT COUNT(*) FROM product_ingredients WHERE product_id = ?
            ");
            $stmt->bind_param("i", $item['id']);
            $stmt->execute();
            $stmt->bind_result($has_ingredients);
            $stmt->fetch();
            $stmt->close();

            if ($has_ingredients) {
                // Record ingredient movements for sales
                $ingredient_stmt = $conn->prepare("
                    SELECT pi.ingredient_id, pi.quantity as required_per_unit
                    FROM product_ingredients pi
                    WHERE pi.product_id = ?
                ");
                $ingredient_stmt->bind_param("i", $item['id']);
                $ingredient_stmt->execute();
                $ingredient_result = $ingredient_stmt->get_result();
                
                while ($ingredient_row = $ingredient_result->fetch_assoc()) {
                    $ingredient_id = $ingredient_row['ingredient_id'];
                    $required_per_unit = $ingredient_row['required_per_unit'];
                    $total_used = $required_per_unit * $item['quantity'];
                    
                    // Get current QOH before deduction
                    $qoh_stmt = $conn->prepare("
                        SELECT 
                            GREATEST(0, COALESCE(SUM(restock_quantity), 0) - COALESCE(SUM(sales_quantity), 0)) as current_qoh
                        FROM ingredient_movements 
                        WHERE ingredient_id = ?
                    ");
                    $qoh_stmt->bind_param("i", $ingredient_id);
                    $qoh_stmt->execute();
                    $qoh_result = $qoh_stmt->get_result();
                    $qoh_row = $qoh_result->fetch_assoc();
                    $quantity_before = $qoh_row['current_qoh'] ?? 0;
                    $qoh_stmt->close();
                    
                    $current_stock = $quantity_before - $total_used;
                    
                    // Record the sales movement
                    $movement_stmt = $conn->prepare("
                        INSERT INTO ingredient_movements 
                        (ingredient_id, quantity_before, sales_quantity, current_stock, restock_quantity, notes, created_by)
                        VALUES (?, ?, ?, ?, 0, ?, ?)
                    ");
                    $notes = "Sales - Order #$order_id ({$item['name']})";
                    $movement_stmt->bind_param("idddsi", $ingredient_id, $quantity_before, $total_used, $current_stock, $notes, $user_id);
                    $movement_stmt->execute();
                    $movement_stmt->close();
                    
                    // Update ingredient quantity for consistency
                    $update_stmt = $conn->prepare("UPDATE ingredients SET quantity = ? WHERE id = ?");
                    $update_stmt->bind_param("di", $current_stock, $ingredient_id);
                    $update_stmt->execute();
                    $update_stmt->close();
                }
                $ingredient_stmt->close();
            } else {
                // Deduct from product stock directly
                $stmt = $conn->prepare("
                    UPDATE products 
                    SET stock = stock - ? 
                    WHERE id = ?
                ");
                $stmt->bind_param("ii", $item['quantity'], $item['id']);
                $stmt->execute();
                $stmt->close();
            }
        }

        $conn->commit();
        
        // Clear cart after successful order
        unset($_SESSION['cart']);
        
        // Show confirmation
        $_SESSION['order_confirmation'] = [
            'order_id' => $order_id,
            'total' => $total,
            'payment_method' => $payment_method
        ];
        
        header("Location: order_confirmation.php");
        exit;
    } catch (Exception $e) {
        $conn->rollback();
        error_log("Checkout error: " . $e->getMessage());
        $_SESSION['checkout_error'] = "Error processing your order: " . $e->getMessage();
        header("Location: checkout.php");
        exit;
    } finally {
        $conn->autocommit(true);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - AIZCAmble | Complete Your Order</title>
    
    <!-- Meta Tags -->
    <meta name="description" content="Complete your AIZCAmble order. Choose delivery area and payment method for fresh ice scramble and mini donuts.">
    <meta name="keywords" content="AIZCAmble checkout, order completion, delivery, payment, ice scramble order">
    <meta name="author" content="AIZCAmble Team">
    
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --accent-gold: #F59E0B;
            --accent-gold-light: #FCD34D;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --background-deep-start: #831843;
            --background-deep-end: #BE185D;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --error-color: #EF4444;
            --shadow-pink: rgba(236, 72, 153, 0.3);
            --shadow-strong: rgba(0, 0, 0, 0.25);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-deep-start) 0%, var(--background-deep-end) 50%, var(--primary-pink-dark) 100%);
            color: var(--text-primary);
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: fixed;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, var(--primary-pink) 1px, transparent 1px);
            background-size: 50px 50px;
            animation: backgroundMove 20s linear infinite;
            opacity: 0.1;
            z-index: -2;
        }

        body::after {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(circle at 20% 80%, var(--primary-pink) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, var(--accent-purple) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, var(--secondary-pink) 0%, transparent 50%);
            opacity: 0.15;
            animation: gradientShift 15s ease-in-out infinite;
            z-index: -1;
        }

        @keyframes backgroundMove {
            0% { transform: translate(0, 0) rotate(0deg); }
            100% { transform: translate(50px, 50px) rotate(360deg); }
        }

        @keyframes gradientShift {
            0%, 100% { opacity: 0.15; }
            50% { opacity: 0.25; }
        }

        /* Navigation */
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: var(--surface-white);
            backdrop-filter: blur(25px);
            border-bottom: 1px solid var(--border-light);
            box-shadow: 0 8px 32px var(--shadow-pink);
            z-index: 1000;
            padding: 0;
            transition: all 0.3s ease;
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 32px;
        }

        .nav-brand {
            display: flex;
            align-items: center;
            gap: 16px;
            text-decoration: none;
            color: var(--text-primary);
        }

        .nav-logo {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            border: 3px solid var(--primary-pink);
            object-fit: cover;
            transition: all 0.3s ease;
        }

        .brand-text {
            display: flex;
            flex-direction: column;
        }

        .brand-name {
            font-size: 28px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            line-height: 1;
        }

        .brand-tagline {
            font-size: 12px;
            color: var(--text-light);
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 24px;
        }

        .nav-link {
            text-decoration: none;
            color: var(--text-secondary);
            font-weight: 600;
            font-size: 16px;
            padding: 12px 20px;
            border-radius: 12px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-link:hover {
            color: var(--primary-pink);
            background: rgba(236, 72, 153, 0.1);
            transform: translateY(-2px);
        }

        /* Main Container */
        .main-container {
            padding: 120px 32px 80px;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Page Header */
        .page-header {
            text-align: center;
            margin-bottom: 48px;
        }

        .page-title {
            font-size: 48px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 16px;
            line-height: 1.1;
        }

        .page-subtitle {
            font-size: 20px;
            color: rgba(255, 255, 255, 0.9);
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        /* Checkout Container */
        .checkout-container {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            box-shadow: 0 16px 48px var(--shadow-pink);
            border: 1px solid var(--border-light);
            overflow: hidden;
            position: relative;
        }

        .checkout-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .checkout-content {
            padding: 40px;
        }

        .section-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 24px;
            padding-bottom: 12px;
            border-bottom: 2px solid var(--border-light);
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        /* Alerts */
        .alert {
            padding: 20px 24px;
            border-radius: 16px;
            margin-bottom: 32px;
            font-weight: 500;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            animation: slideIn 0.5s ease;
        }

        .alert-danger {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(220, 38, 38, 0.1));
            color: var(--error-color);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        @keyframes slideIn {
            0% { transform: translateY(-20px); opacity: 0; }
            100% { transform: translateY(0); opacity: 1; }
        }

        /* Order Summary Table */
        .order-summary {
            margin-bottom: 40px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 24px;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        }

        th, td {
            padding: 16px;
            text-align: left;
            border-bottom: 1px solid var(--border-light);
        }

        th {
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            color: white;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        td {
            font-size: 15px;
            color: var(--text-primary);
        }

        .customization-details {
            font-size: 13px;
            color: var(--text-secondary);
            background: rgba(236, 72, 153, 0.05);
            padding: 8px 12px;
            border-radius: 8px;
            margin-top: 4px;
        }

        /* Totals */
        .totals {
            text-align: right;
            margin: 24px 0;
            padding: 20px;
            background: linear-gradient(135deg, rgba(236, 72, 153, 0.05), rgba(139, 92, 246, 0.05));
            border-radius: 16px;
            border: 1px solid var(--border-light);
        }

        .totals div {
            margin: 8px 0;
            font-size: 16px;
            font-weight: 500;
        }

        .grand-total {
            font-size: 24px !important;
            font-weight: 800 !important;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-top: 16px !important;
            padding-top: 16px;
            border-top: 2px solid var(--border-light);
        }

        /* Form Sections */
        .form-section {
            margin-bottom: 40px;
            padding: 24px;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 16px;
            border: 1px solid var(--border-light);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            font-size: 15px;
            color: var(--text-primary);
        }

        .form-group select,
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--border-light);
            border-radius: 12px;
            font-size: 15px;
            font-family: 'Poppins', sans-serif;
            transition: all 0.3s ease;
            background: white;
        }

        .form-group select:focus,
        .form-group input:focus,
        .form-group textarea:focus {
            border-color: var(--primary-pink);
            outline: none;
            box-shadow: 0 0 0 3px rgba(236, 72, 153, 0.1);
        }

        /* GCash Section */
        .gcash-section {
            display: none;
            margin-top: 24px;
            padding: 24px;
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.05), rgba(5, 150, 105, 0.05));
            border-radius: 16px;
            border: 2px solid rgba(16, 185, 129, 0.2);
        }

        .gcash-info {
            text-align: center;
            margin-bottom: 24px;
        }

        .gcash-info p {
            margin: 8px 0;
            font-size: 16px;
            font-weight: 500;
        }

        .gcash-info img {
            max-width: 200px;
            margin: 20px auto;
            display: block;
            border: 2px solid var(--border-light);
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 16px 32px;
            border-radius: 16px;
            text-decoration: none;
            font-weight: 700;
            font-size: 16px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border: none;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            font-family: 'Poppins', sans-serif;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px var(--shadow-pink);
        }

        .btn-secondary {
            background: linear-gradient(135deg, var(--text-light), var(--text-secondary));
            color: white;
            box-shadow: 0 4px 15px rgba(107, 114, 128, 0.3);
        }

        .btn-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(107, 114, 128, 0.4);
        }

        .btn:disabled {
            background: linear-gradient(135deg, #9CA3AF, #6B7280);
            color: white;
            cursor: not-allowed;
            transform: none !important;
            box-shadow: none !important;
        }

        /* Form Actions */
        .form-actions {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 40px;
            padding-top: 32px;
            border-top: 2px solid var(--border-light);
        }

        /* Loading */
        .loading {
            display: none;
            text-align: center;
            margin: 32px 0;
            padding: 24px;
            background: rgba(236, 72, 153, 0.05);
            border-radius: 16px;
            border: 1px solid var(--border-light);
        }

        .loading-spinner {
            border: 3px solid var(--border-light);
            border-top: 3px solid var(--primary-pink);
            border-radius: 50%;
            width: 32px;
            height: 32px;
            animation: spin 1s linear infinite;
            margin: 0 auto 16px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .error-message {
            color: var(--error-color);
            font-size: 14px;
            margin-top: 8px;
            display: none;
            font-weight: 500;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .main-container {
                padding: 100px 20px 60px;
            }
            
            .page-title {
                font-size: 36px;
            }
            
            .checkout-content {
                padding: 24px;
            }
            
            table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }
            
            th, td {
                padding: 12px 8px;
                font-size: 14px;
            }
            
            .form-actions {
                flex-direction: column;
                align-items: center;
            }
            
            .btn {
                width: 100%;
                max-width: 300px;
            }
        }

        @media (max-width: 480px) {
            .nav-container {
                padding: 12px 20px;
            }
            
            .page-title {
                font-size: 28px;
            }
            
            .checkout-content {
                padding: 20px;
            }
            
            .form-section {
                padding: 16px;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(236, 72, 153, 0.1);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--primary-pink-dark), var(--primary-pink));
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <a href="../index.php" class="nav-brand">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo" class="nav-logo">
                <div class="brand-text">
                    <div class="brand-name">AIZCAmble</div>
                    <div class="brand-tagline">Checkout</div>
                </div>
            </a>
            
            <div class="nav-links">
                <a href="../index.php" class="nav-link">
                    <i class="fas fa-home"></i>
                    Home
                </a>
                <a href="../Home.php" class="nav-link">
                    <i class="fas fa-store"></i>
                    Shop
                </a>
                <a href="cart.php" class="nav-link">
                    <i class="fas fa-shopping-cart"></i>
                    Cart
                </a>
                <a href="orders.php" class="nav-link">
                    <i class="fas fa-receipt"></i>
                    My Orders
                </a>
                <a href="../logout.php" class="nav-link">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
        </div>
    </nav>

    <!-- Main Container -->
    <div class="main-container">
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-title">Checkout</h1>
            <p class="page-subtitle">Complete your order and enjoy your treats!</p>
        </div>
        
        <div class="checkout-container">
            <div class="checkout-content">
                <?php if (isset($_SESSION['checkout_error'])): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i>
                        <div>
                            <?= is_array($_SESSION['checkout_error']) ? 
                                "Some items are out of stock. Please check your cart." : 
                                $_SESSION['checkout_error'] ?>
                        </div>
                    </div>
                    <?php unset($_SESSION['checkout_error']); ?>
                <?php endif; ?>
                
                <div class="order-summary">
                    <h2 class="section-title">
                        <i class="fas fa-receipt"></i>
                        Order Summary
                    </h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Customization</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($cart as $item): ?>
                                <tr>
                                    <td><?= htmlspecialchars($item['name']) ?></td>
                                    <td>
                                        <?php if (!empty($item['customizations'])): ?>
                                            <div class="customization-details">
                                                <?php 
                                                $customizations = is_array($item['customizations']) ? 
                                                    $item['customizations'] : 
                                                    json_decode($item['customizations'], true);
                                                
                                                foreach ($customizations as $option => $value): ?>
                                                    <div>
                                                        <strong><?= htmlspecialchars($option) ?>:</strong> 
                                                        <?php if (is_array($value)): ?>
                                                            <?= htmlspecialchars(implode(', ', $value)) ?>
                                                        <?php else: ?>
                                                            <?= htmlspecialchars($value) ?>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php else: ?>
                                            <span class="customization-details">Standard</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= $item['quantity'] ?></td>
                                    <td>₱<?= number_format($item['price'], 2) ?></td>
                                    <td>₱<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <div class="totals">
                        <div id="subtotal">Subtotal: ₱<?= number_format($total, 2) ?></div>
                        <div id="delivery-fee">Delivery Fee: ₱0.00</div>
                        <div id="total-amount" class="grand-total">Grand Total: ₱<?= number_format($total, 2) ?></div>
                    </div>
                </div>

                <form id="checkout-form" method="POST" enctype="multipart/form-data">
                    <div class="form-section">
                        <h2 class="section-title">
                            <i class="fas fa-map-marker-alt"></i>
                            Delivery Information
                        </h2>
                        
                        <div class="form-group">
                            <label for="area">
                                <i class="fas fa-location-dot"></i>
                                Delivery Area
                            </label>
                            <select name="area" id="area" required>
                                <option value="">Select Delivery Area</option>
                                <option value="Sta. Cruz">Sta. Cruz</option>
                                <option value="Sto Cristo">Sto Cristo</option>
                                <option value="San Roque">San Roque</option>
                                <option value="Encanto">Encanto</option>
                                <option value="Encanto Dulo">Encanto Dulo</option>
                                <option value="Sta. Lucia">Sta. Lucia</option>
                                <option value="Binagbag">Binagbag</option>
                                <option value="Banaban">Banaban</option>
                                <option value="Sulucan">Sulucan</option>
                                <option value="Marungko">Marungko</option>
                                <option value="Taboc">Taboc</option>
                                <option value="Donacion">Donacion</option>
                                <option value="Donacion Dulo">Donacion Dulo</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="landmark">
                                <i class="fas fa-map-pin"></i>
                                Landmark/Additional Instructions
                            </label>
                            <textarea name="landmark" id="landmark" rows="3" required placeholder="e.g. Near the church, blue gate, contact upon arrival"></textarea>
                        </div>
                    </div>
                    
                    <div class="form-section">
                        <h2 class="section-title">
                            <i class="fas fa-credit-card"></i>
                            Payment Method
                        </h2>
                        
                        <div class="form-group">
                            <label for="payment_method">Select Payment Method</label>
                            <select name="payment_method" id="payment_method" required>
                                <option value="">Choose payment method</option>
                                <option value="cod">💵 Cash on Delivery</option>
                                <option value="gcash">📱 GCash</option>
                            </select>
                        </div>
                        
                        <div id="gcash-section" class="gcash-section">
                            <div class="gcash-info">
                                <p><i class="fas fa-mobile-alt"></i> Please send your payment to:</p>
                                <p><strong>GCash Number: 09171234567</strong></p>
                                <p><strong>Amount: ₱<span id="gcash-amount"><?= number_format($total, 2) ?></span></strong></p>
                                <img src="../assets/gcash_qr_owner.jpg" alt="GCash QR Code">
                                <p>After payment, please provide the details below</p>
                            </div>
                            
                            <div class="form-group">
                                <label for="transaction_id">
                                    <i class="fas fa-hashtag"></i>
                                    GCash Reference Number
                                </label>
                                <input type="text" name="transaction_id" id="transaction_id" placeholder="Enter your GCash reference number">
                                <div id="transaction-error" class="error-message">Please enter your GCash reference number</div>
                            </div>
                            
                            <div class="form-group">
                                <label for="receipt_image">
                                    <i class="fas fa-image"></i>
                                    Upload Payment Receipt (Optional)
                                </label>
                                <input type="file" name="receipt_image" id="receipt_image" accept="image/*">
                            </div>
                        </div>
                    </div>
                    
                    <div id="loading" class="loading">
                        <div class="loading-spinner"></div>
                        <p><strong>Processing your order...</strong></p>
                        <p>Please wait while we prepare your delicious treats!</p>
                    </div>
                    
                    <div class="form-actions">
                        <a href="cart.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i>
                            Back to Cart
                        </a>
                        <button type="submit" id="place-order-btn" class="btn btn-primary">
                            <i class="fas fa-check-circle"></i>
                            Place Order
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        const deliveryFees = {
            "Sta. Cruz": 30,
            "Sto Cristo": 30,
            "San Roque": 30,
            "Encanto": 40,
            "Encanto Dulo": 50,
            "Sta. Lucia": 50,
            "Binagbag": 50,
            "Banaban": 50,
            "Sulucan": 50,
            "Marungko": 50,
            "Taboc": 60,
            "Donacion": 70,
            "Donacion Dulo": 80
        };

        document.addEventListener('DOMContentLoaded', function() {
            const paymentMethodSelect = document.getElementById('payment_method');
            const areaSelect = document.getElementById('area');
            const deliveryFeeElem = document.getElementById('delivery-fee');
            const totalAmountElem = document.getElementById('total-amount');
            const gcashAmountElem = document.getElementById('gcash-amount');
            const gcashSection = document.getElementById('gcash-section');
            const checkoutForm = document.getElementById('checkout-form');
            const loadingDiv = document.getElementById('loading');
            const transactionIdInput = document.getElementById('transaction_id');
            const transactionError = document.getElementById('transaction-error');
            const placeOrderBtn = document.getElementById('place-order-btn');
            
            const baseTotal = <?= $total ?>;
            
            // Update totals when delivery area changes
            function updateTotals() {
                const area = areaSelect.value;
                const deliveryFee = deliveryFees[area] || 0;
                const grandTotal = baseTotal + deliveryFee;
                
                deliveryFeeElem.textContent = `Delivery Fee: ₱${deliveryFee.toFixed(2)}`;
                totalAmountElem.textContent = `Grand Total: ₱${grandTotal.toFixed(2)}`;
                gcashAmountElem.textContent = grandTotal.toFixed(2);
            }
            
            // Toggle GCash fields based on payment method
            function toggleGcashFields() {
                if (paymentMethodSelect.value === 'gcash') {
                    gcashSection.style.display = 'block';
                } else {
                    gcashSection.style.display = 'none';
                }
            }
            
            // Form validation
            function validateForm(e) {
                let isValid = true;
                
                // Reset error messages
                transactionError.style.display = 'none';
                
                // Validate GCash transaction ID if GCash is selected
                if (paymentMethodSelect.value === 'gcash' && !transactionIdInput.value.trim()) {
                    transactionError.style.display = 'block';
                    isValid = false;
                }
                
                if (!isValid) {
                    e.preventDefault();
                    return false;
                }
                
                // Show loading state
                loadingDiv.style.display = 'block';
                placeOrderBtn.disabled = true;
                placeOrderBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
                return true;
            }
            
            // Event listeners
            areaSelect.addEventListener('change', updateTotals);
            paymentMethodSelect.addEventListener('change', toggleGcashFields);
            checkoutForm.addEventListener('submit', validateForm);
            
            // Initialize
            updateTotals();
            toggleGcashFields();
        });

        // Enhanced button interactions
        document.querySelectorAll('.btn:not(:disabled)').forEach(btn => {
            btn.addEventListener('click', function(e) {
                // Add ripple effect
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.cssText = `
                    width: ${size}px;
                    height: ${size}px;
                    left: ${x}px;
                    top: ${y}px;
                    position: absolute;
                    border-radius: 50%;
                    background: rgba(255, 255, 255, 0.4);
                    transform: scale(0);
                    animation: rippleEffect 0.6s ease-out;
                    pointer-events: none;
                `;
                
                this.style.position = 'relative';
                this.style.overflow = 'hidden';
                this.appendChild(ripple);
                
                setTimeout(() => ripple.remove(), 600);
            });
        });

        // Add ripple animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes rippleEffect {
                0% {
                    transform: scale(0);
                    opacity: 1;
                }
                100% {
                    transform: scale(4);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>
