<?php
session_start();
require '../includes/db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}


$user_id = $_SESSION['user_id'];
$cart = json_decode($_POST['cart'], true);
$payment_method = $_POST['payment_method'] ?? '';
$place = $_POST['place'] ?? '';
$landmark = $_POST['landmark'] ?? '';
$transaction_id = $_POST['transaction_id'] ?? null;
$receipt_image = null;

// Handle file upload
if ($payment_method === 'gcash' && isset($_FILES['receipt_image'])) {
    $target_dir = "../uploads/receipts/";
    $unique_name = time() . '_' . basename($_FILES["receipt_image"]["name"]);
    $target_file = $target_dir . $unique_name;
    
    if (move_uploaded_file($_FILES["receipt_image"]["tmp_name"], $target_file)) {
        $receipt_image = $target_file;
    }
}

try {
    $conn->autocommit(false); // Start transaction

    // 1. Calculate total
    $total = 0;
    foreach ($cart as $item) {
        $total += $item['price'] * $item['quantity'];
    }

    // 2. Create order
    $stmt = $conn->prepare("
        INSERT INTO orders 
        (user_id, total_amount, payment_method, delivery_place, landmark, transaction_id, receipt_image, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
    ");
    $stmt->bind_param(
        "idsssss", 
        $user_id, 
        $total, 
        $payment_method, 
        $place, 
        $landmark, 
        $transaction_id, 
        $receipt_image
    );
    $stmt->execute();
    $order_id = $stmt->insert_id;
    $stmt->close();

    // 3. Add order items and deduct inventory
    foreach ($cart as $item) {
        // Add to order items
        $stmt = $conn->prepare("
            INSERT INTO order_items 
            (order_id, product_id, quantity, price, customizations)
            VALUES (?, ?, ?, ?, ?)
        ");
        $customizations = json_encode($item['customizations'] ?? []);
        $stmt->bind_param(
            "iiids", 
            $order_id, 
            $item['id'], 
            $item['quantity'], 
            $item['price'], 
            $customizations
        );
        $stmt->execute();
        $stmt->close();

        // Check if product uses ingredients
        $stmt = $conn->prepare("
            SELECT COUNT(*) FROM product_ingredients WHERE product_id = ?
        ");
        $stmt->bind_param("i", $item['id']);
        $stmt->execute();
        $stmt->bind_result($has_ingredients);
        $stmt->fetch();
        $stmt->close();

        if ($has_ingredients) {
            // Deduct ingredients
            $stmt = $conn->prepare("
                UPDATE ingredients i
                JOIN product_ingredients pi ON i.id = pi.ingredient_id
                SET i.stock = i.stock - (pi.quantity * ?)
                WHERE pi.product_id = ?
            ");
            $stmt->bind_param("ii", $item['quantity'], $item['id']);
            $stmt->execute();
            $stmt->close();
        } else {
            // Deduct from product stock directly
            $stmt = $conn->prepare("
                UPDATE products 
                SET stock = stock - ? 
                WHERE id = ?
            ");
            $stmt->bind_param("ii", $item['quantity'], $item['id']);
            $stmt->execute();
            $stmt->close();
        }
    }

    $conn->commit();
    echo json_encode(['success' => true, 'order_id' => $order_id]);
    
    // Clear cart after successful order
    unset($_SESSION['cart']);
} catch (Exception $e) {
    $conn->rollback();
    error_log("Checkout error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error processing order']);
} finally {
    $conn->autocommit(true);
}
?>