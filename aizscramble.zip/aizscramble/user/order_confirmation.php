<?php
session_start();
require '../includes/db.php';

// Check if there's an order confirmation in the session
if (!isset($_SESSION['order_confirmation'])) {
    header('Location: ../index.php');
    exit;
}

$confirmation = $_SESSION['order_confirmation'];
unset($_SESSION['order_confirmation']); // Clear it so it only shows once

// Get order details from database
$stmt = $conn->prepare("
    SELECT o.*, u.name as user_name
    FROM orders o
    JOIN users u ON o.user_id = u.id
    WHERE o.id = ?
");
$stmt->bind_param("i", $confirmation['order_id']);
$stmt->execute();
$result = $stmt->get_result();
$order = $result->fetch_assoc();
$stmt->close();

// Get order items
$stmt = $conn->prepare("
    SELECT oi.*, p.name as product_name 
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = ?
");
$stmt->bind_param("i", $confirmation['order_id']);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation - AIZCAmble | Thank You!</title>
    
    <!-- Meta Tags -->
    <meta name="description" content="Your AIZCAmble order has been confirmed! View your order details and track your delicious ice scramble and mini donuts.">
    <meta name="keywords" content="AIZCAmble order confirmation, order success, ice scramble order, mini donuts delivery">
    <meta name="author" content="AIZCAmble Team">
    
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --accent-gold: #F59E0B;
            --accent-gold-light: #FCD34D;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --background-deep-start: #831843;
            --background-deep-end: #BE185D;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --error-color: #EF4444;
            --shadow-pink: rgba(236, 72, 153, 0.3);
            --shadow-strong: rgba(0, 0, 0, 0.25);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-deep-start) 0%, var(--background-deep-end) 50%, var(--primary-pink-dark) 100%);
            color: var(--text-primary);
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: fixed;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, var(--primary-pink) 1px, transparent 1px);
            background-size: 50px 50px;
            animation: backgroundMove 20s linear infinite;
            opacity: 0.1;
            z-index: -2;
        }

        body::after {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(circle at 20% 80%, var(--primary-pink) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, var(--accent-purple) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, var(--secondary-pink) 0%, transparent 50%);
            opacity: 0.15;
            animation: gradientShift 15s ease-in-out infinite;
            z-index: -1;
        }

        @keyframes backgroundMove {
            0% { transform: translate(0, 0) rotate(0deg); }
            100% { transform: translate(50px, 50px) rotate(360deg); }
        }

        @keyframes gradientShift {
            0%, 100% { opacity: 0.15; }
            50% { opacity: 0.25; }
        }

        /* Navigation */
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: var(--surface-white);
            backdrop-filter: blur(25px);
            border-bottom: 1px solid var(--border-light);
            box-shadow: 0 8px 32px var(--shadow-pink);
            z-index: 1000;
            padding: 0;
            transition: all 0.3s ease;
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 32px;
        }

        .nav-brand {
            display: flex;
            align-items: center;
            gap: 16px;
            text-decoration: none;
            color: var(--text-primary);
        }

        .nav-logo {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            border: 3px solid var(--primary-pink);
            object-fit: cover;
            transition: all 0.3s ease;
        }

        .brand-text {
            display: flex;
            flex-direction: column;
        }

        .brand-name {
            font-size: 28px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            line-height: 1;
        }

        .brand-tagline {
            font-size: 12px;
            color: var(--text-light);
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 24px;
        }

        .nav-link {
            text-decoration: none;
            color: var(--text-secondary);
            font-weight: 600;
            font-size: 16px;
            padding: 12px 20px;
            border-radius: 12px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-link:hover {
            color: var(--primary-pink);
            background: rgba(236, 72, 153, 0.1);
            transform: translateY(-2px);
        }

        /* Main Container */
        .main-container {
            padding: 120px 32px 80px;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Success Animation */
        .success-animation {
            text-align: center;
            margin-bottom: 48px;
            animation: successPulse 2s ease-in-out;
        }

        @keyframes successPulse {
            0% { transform: scale(0.8); opacity: 0; }
            50% { transform: scale(1.1); opacity: 1; }
            100% { transform: scale(1); opacity: 1; }
        }

        .success-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 120px;
            height: 120px;
            background: linear-gradient(135deg, var(--success-color), #059669);
            color: white;
            font-size: 60px;
            border-radius: 50%;
            margin-bottom: 24px;
            box-shadow: 0 16px 48px rgba(16, 185, 129, 0.4);
            animation: iconBounce 1s ease-in-out 0.5s both;
        }

        @keyframes iconBounce {
            0% { transform: scale(0) rotate(-180deg); }
            50% { transform: scale(1.2) rotate(0deg); }
            100% { transform: scale(1) rotate(0deg); }
        }

        .success-title {
            font-size: 48px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--success-color), #059669);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 16px;
            line-height: 1.1;
        }

        .success-subtitle {
            font-size: 20px;
            color: rgba(255, 255, 255, 0.9);
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        /* Confirmation Container */
        .confirmation-container {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            box-shadow: 0 16px 48px var(--shadow-pink);
            border: 1px solid var(--border-light);
            overflow: hidden;
            position: relative;
        }

        .confirmation-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--success-color), #059669, var(--success-color));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .confirmation-content {
            padding: 40px;
        }

        .section-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 24px;
            padding-bottom: 12px;
            border-bottom: 2px solid var(--border-light);
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* Order Details */
        .order-details {
            background: linear-gradient(135deg, rgba(236, 72, 153, 0.05), rgba(139, 92, 246, 0.05));
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 32px;
            border: 1px solid var(--border-light);
        }

        .detail-row {
            display: flex;
            margin-bottom: 16px;
            align-items: flex-start;
        }

        .detail-label {
            font-weight: 600;
            width: 200px;
            color: var(--text-secondary);
            font-size: 15px;
        }

        .detail-value {
            flex: 1;
            color: var(--text-primary);
            font-weight: 500;
        }

        .order-number {
            font-size: 20px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            text-transform: capitalize;
            background: linear-gradient(135deg, var(--warning-color), var(--accent-gold-light));
            color: white;
        }

        /* Order Items Table */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 24px;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        }

        th, td {
            padding: 16px;
            text-align: left;
            border-bottom: 1px solid var(--border-light);
        }

        th {
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            color: white;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        td {
            font-size: 15px;
            color: var(--text-primary);
        }

        .customization-details {
            font-size: 13px;
            color: var(--text-secondary);
            background: rgba(236, 72, 153, 0.05);
            padding: 8px 12px;
            border-radius: 8px;
            margin-top: 4px;
        }

        /* Totals */
        .totals {
            text-align: right;
            margin: 24px 0;
            padding: 20px;
            background: linear-gradient(135deg, rgba(236, 72, 153, 0.05), rgba(139, 92, 246, 0.05));
            border-radius: 16px;
            border: 1px solid var(--border-light);
        }

        .totals div {
            margin: 8px 0;
            font-size: 16px;
            font-weight: 500;
        }

        .grand-total {
            font-size: 24px !important;
            font-weight: 800 !important;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-top: 16px !important;
            padding-top: 16px;
            border-top: 2px solid var(--border-light);
        }

        /* Payment Instructions */
        .payment-instructions {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.05), rgba(5, 150, 105, 0.05));
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 32px;
            border: 2px solid rgba(16, 185, 129, 0.2);
        }

        .payment-instructions h3 {
            color: var(--success-color);
            margin-bottom: 16px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .payment-instructions p {
            margin: 8px 0;
            font-size: 16px;
            font-weight: 500;
        }

        .receipt-image {
            max-width: 250px;
            border-radius: 12px;
            border: 2px solid var(--border-light);
            margin-top: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        /* Action Buttons */
        .actions {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 40px;
            padding-top: 32px;
            border-top: 2px solid var(--border-light);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 16px 32px;
            border-radius: 16px;
            text-decoration: none;
            font-weight: 700;
            font-size: 16px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border: none;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            font-family: 'Poppins', sans-serif;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px var(--shadow-pink);
        }

        .btn-secondary {
            background: linear-gradient(135deg, var(--text-light), var(--text-secondary));
            color: white;
            box-shadow: 0 4px 15px rgba(107, 114, 128, 0.3);
        }

        .btn-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(107, 114, 128, 0.4);
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .main-container {
                padding: 100px 20px 60px;
            }
            
            .success-title {
                font-size: 36px;
            }
            
            .confirmation-content {
                padding: 24px;
            }
            
            .detail-row {
                flex-direction: column;
                gap: 4px;
            }
            
            .detail-label {
                width: 100%;
                margin-bottom: 4px;
            }
            
            table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }
            
            th, td {
                padding: 12px 8px;
                font-size: 14px;
            }
            
            .actions {
                flex-direction: column;
                align-items: center;
            }
            
            .btn {
                width: 100%;
                max-width: 300px;
            }
        }

        @media (max-width: 480px) {
            .nav-container {
                padding: 12px 20px;
            }
            
            .success-title {
                font-size: 28px;
            }
            
            .confirmation-content {
                padding: 20px;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(236, 72, 153, 0.1);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--primary-pink-dark), var(--primary-pink));
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <a href="../index.php" class="nav-brand">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo" class="nav-logo">
                <div class="brand-text">
                    <div class="brand-name">AIZCAmble</div>
                    <div class="brand-tagline">Order Confirmed</div>
                </div>
            </a>
            
            <div class="nav-links">
                <a href="../index.php" class="nav-link">
                    <i class="fas fa-home"></i>
                    Home
                </a>
                <a href="../Home.php" class="nav-link">
                    <i class="fas fa-store"></i>
                    Shop
                </a>
                <a href="cart.php" class="nav-link">
                    <i class="fas fa-shopping-cart"></i>
                    Cart
                </a>
                <a href="orders.php" class="nav-link">
                    <i class="fas fa-receipt"></i>
                    My Orders
                </a>
                <a href="../logout.php" class="nav-link">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
        </div>
    </nav>

    <!-- Main Container -->
    <div class="main-container">
        <!-- Success Animation -->
        <div class="success-animation">
            <div class="success-icon">
                <i class="fas fa-check"></i>
            </div>
            <h1 class="success-title">Order Confirmed!</h1>
            <p class="success-subtitle">Thank you for your order. We've received it and will process it shortly.</p>
        </div>
        
        <div class="confirmation-container">
            <div class="confirmation-content">
                <h2 class="section-title">
                    <i class="fas fa-receipt"></i>
                    Order Details
                </h2>
                
                <div class="order-details">
                    <div class="detail-row">
                        <div class="detail-label">Order Number:</div>
                        <div class="detail-value order-number">#<?= $order['id'] ?></div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Customer Name:</div>
                        <div class="detail-value"><?= htmlspecialchars($order['user_name']) ?></div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Order Date:</div>
                        <div class="detail-value"><?= date('F j, Y g:i A', strtotime($order['created_at'])) ?></div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Delivery Area:</div>
                        <div class="detail-value">
                            <i class="fas fa-map-marker-alt"></i>
                            <?= htmlspecialchars($order['area']) ?>
                        </div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Landmark:</div>
                        <div class="detail-value"><?= htmlspecialchars($order['landmark']) ?></div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Payment Method:</div>
                        <div class="detail-value">
                            <?php if ($order['payment_method'] === 'gcash'): ?>
                                <i class="fas fa-mobile-alt"></i> GCash
                            <?php else: ?>
                                <i class="fas fa-money-bill-wave"></i> Cash on Delivery
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if ($order['payment_method'] === 'gcash'): ?>
                        <div class="detail-row">
                            <div class="detail-label">GCash Transaction ID:</div>
                            <div class="detail-value"><?= htmlspecialchars($order['transaction_id']) ?></div>
                        </div>
                    <?php endif; ?>
                    <div class="detail-row">
                        <div class="detail-label">Status:</div>
                        <div class="detail-value">
                            <span class="status-badge">
                                <i class="fas fa-clock"></i>
                                <?= $order['status'] ?>
                            </span>
                        </div>
                    </div>
                    
                    <?php if ($order['payment_method'] === 'gcash' && !empty($order['receipt_image'])): ?>
                        <div class="detail-row">
                            <div class="detail-label">Payment Receipt:</div>
                            <div class="detail-value">
                                <img src="<?= $order['receipt_image'] ?>" alt="Payment Receipt" class="receipt-image">
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                
                <h2 class="section-title">
                    <i class="fas fa-shopping-bag"></i>
                    Order Items
                </h2>
                
                <table>
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Customization</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $item): ?>
                            <tr>
                                <td><?= htmlspecialchars($item['product_name']) ?></td>
                                <td>
                                    <div class="customization-details">
                                        <?php if (!empty($item['customizations'])): ?>
                                            <?php 
                                            $customizations = json_decode($item['customizations'], true);
                                            foreach ($customizations as $option => $value): ?>
                                                <div>
                                                    <strong><?= htmlspecialchars($option) ?>:</strong> 
                                                    <?php if (is_array($value)): ?>
                                                        <?= htmlspecialchars(implode(', ', $value)) ?>
                                                    <?php else: ?>
                                                        <?= htmlspecialchars($value) ?>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <div>Standard</div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td><?= $item['quantity'] ?></td>
                                <td>₱<?= number_format($item['price'], 2) ?></td>
                                <td>₱<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <div class="totals">
                    <div>Subtotal: ₱<?= number_format($order['total_amount'], 2) ?></div>
                    <div>Delivery Fee: ₱0.00</div>
                    <div class="grand-total">Total: ₱<?= number_format($order['total_amount'], 2) ?></div>
                </div>

                <?php if ($order['payment_method'] === 'gcash' && $order['status'] === 'pending'): ?>
                    <div class="payment-instructions">
                        <h3>
                            <i class="fas fa-mobile-alt"></i>
                            Payment Instructions
                        </h3>
                        <p>Please complete your payment via GCash to:</p>
                        <p><strong>GCash Number: 09171234567</strong></p>
                        <p><strong>Amount: ₱<?= number_format($order['total_amount'], 2) ?></strong></p>
                        <p>If you haven't already uploaded your receipt, you may send it to our Facebook page.</p>
                    </div>
                <?php endif; ?>

                <div class="actions">
                    <a href="../index.php" class="btn btn-secondary">
                        <i class="fas fa-shopping-cart"></i>
                        Continue Shopping
                    </a>
                    <a href="orders.php" class="btn btn-primary">
                        <i class="fas fa-receipt"></i>
                        View My Orders
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Add confetti effect on page load
        document.addEventListener('DOMContentLoaded', function() {
            // Simple confetti effect
            function createConfetti() {
                const colors = ['#EC4899', '#8B5CF6', '#F9A8D4', '#10B981', '#F59E0B'];
                
                for (let i = 0; i < 50; i++) {
                    setTimeout(() => {
                        const confetti = document.createElement('div');
                        confetti.style.cssText = `
                            position: fixed;
                            top: -10px;
                            left: ${Math.random() * 100}vw;
                            width: 10px;
                            height: 10px;
                            background: ${colors[Math.floor(Math.random() * colors.length)]};
                            border-radius: 50%;
                            pointer-events: none;
                            z-index: 9999;
                            animation: confettiFall 3s linear forwards;
                        `;
                        
                        document.body.appendChild(confetti);
                        
                        setTimeout(() => confetti.remove(), 3000);
                    }, i * 100);
                }
            }
            
            // Add confetti animation
            const style = document.createElement('style');
            style.textContent = `
                @keyframes confettiFall {
                    0% {
                        transform: translateY(-10px) rotate(0deg);
                        opacity: 1;
                    }
                    100% {
                        transform: translateY(100vh) rotate(360deg);
                        opacity: 0;
                    }
                }
            `;
            document.head.appendChild(style);
            
            // Trigger confetti after a short delay
            setTimeout(createConfetti, 500);
        });

        // Enhanced button interactions
        document.querySelectorAll('.btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                // Add ripple effect
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.cssText = `
                    width: ${size}px;
                    height: ${size}px;
                    left: ${x}px;
                    top: ${y}px;
                    position: absolute;
                    border-radius: 50%;
                    background: rgba(255, 255, 255, 0.4);
                    transform: scale(0);
                    animation: rippleEffect 0.6s ease-out;
                    pointer-events: none;
                `;
                
                this.style.position = 'relative';
                this.style.overflow = 'hidden';
                this.appendChild(ripple);
                
                setTimeout(() => ripple.remove(), 600);
            });
        });

        // Add ripple animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes rippleEffect {
                0% {
                    transform: scale(0);
                    opacity: 1;
                }
                100% {
                    transform: scale(4);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>
