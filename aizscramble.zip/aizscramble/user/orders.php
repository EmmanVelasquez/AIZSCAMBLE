<?php
session_start();
include('../includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: ../user/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT *, TIMESTAMPDIFF(SECOND, status_updated_at, NOW()) as status_duration 
        FROM orders WHERE user_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$orders = $stmt->get_result();

// Get order statistics
$stats_sql = "SELECT 
    COUNT(*) as total_orders,
    SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END) as delivered_orders,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
    SUM(total_amount) as total_spent
    FROM orders WHERE user_id = ?";
$stats_stmt = $conn->prepare($stats_sql);
$stats_stmt->bind_param("i", $user_id);
$stats_stmt->execute();
$stats = $stats_stmt->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <title>My Orders - AIZCAmble | Order History & Tracking</title>
    
    <!-- Meta Tags -->
    <meta name="description" content="Track your AIZCAmble orders. View order history, status updates, and manage your delicious ice scramble and mini donut orders.">
    <meta name="keywords" content="AIZCAmble orders, order tracking, order history, ice scramble orders, mini donuts delivery">
    <meta name="author" content="AIZCAmble Team">
    
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --accent-gold: #F59E0B;
            --accent-gold-light: #FCD34D;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --background-deep-start: #831843;
            --background-deep-end: #BE185D;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --error-color: #EF4444;
            --info-color: #3B82F6;
            --shadow-pink: rgba(236, 72, 153, 0.3);
            --shadow-strong: rgba(0, 0, 0, 0.25);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-deep-start) 0%, var(--background-deep-end) 50%, var(--primary-pink-dark) 100%);
            color: var(--text-primary);
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: fixed;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, var(--primary-pink) 1px, transparent 1px);
            background-size: 50px 50px;
            animation: backgroundMove 20s linear infinite;
            opacity: 0.1;
            z-index: -2;
        }

        body::after {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(circle at 20% 80%, var(--primary-pink) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, var(--accent-purple) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, var(--secondary-pink) 0%, transparent 50%);
            opacity: 0.15;
            animation: gradientShift 15s ease-in-out infinite;
            z-index: -1;
        }

        @keyframes backgroundMove {
            0% { transform: translate(0, 0) rotate(0deg); }
            100% { transform: translate(50px, 50px) rotate(360deg); }
        }

        @keyframes gradientShift {
            0%, 100% { opacity: 0.15; }
            50% { opacity: 0.25; }
        }

        /* Navigation */
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: var(--surface-white);
            backdrop-filter: blur(25px);
            border-bottom: 1px solid var(--border-light);
            box-shadow: 0 8px 32px var(--shadow-pink);
            z-index: 1000;
            padding: 0;
            transition: all 0.3s ease;
        }

        .navbar.scrolled {
            background: rgba(255, 255, 255, 0.98);
            box-shadow: 0 12px 48px var(--shadow-pink);
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 32px;
        }

        .nav-brand {
            display: flex;
            align-items: center;
            gap: 16px;
            text-decoration: none;
            color: var(--text-primary);
        }

        .nav-logo {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            border: 3px solid var(--primary-pink);
            object-fit: cover;
            transition: all 0.3s ease;
            position: relative;
        }

        .nav-logo::before {
            content: '';
            position: absolute;
            top: -6px;
            left: -6px;
            right: -6px;
            bottom: -6px;
            background: linear-gradient(45deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            border-radius: 50%;
            z-index: -1;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .nav-brand:hover .nav-logo::before {
            opacity: 1;
        }

        .nav-brand:hover .nav-logo {
            transform: scale(1.1) rotate(5deg);
        }

        .brand-text {
            display: flex;
            flex-direction: column;
        }

        .brand-name {
            font-size: 28px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            line-height: 1;
        }

        .brand-tagline {
            font-size: 12px;
            color: var(--text-light);
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 24px;
        }

        .nav-link {
            text-decoration: none;
            color: var(--text-secondary);
            font-weight: 600;
            font-size: 16px;
            padding: 12px 20px;
            border-radius: 12px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-link::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(236, 72, 153, 0.1), transparent);
            transition: left 0.5s ease;
        }

        .nav-link:hover::before {
            left: 100%;
        }

        .nav-link:hover {
            color: var(--primary-pink);
            background: rgba(236, 72, 153, 0.1);
            transform: translateY(-2px);
        }

        .nav-link.active {
            color: var(--primary-pink);
            background: rgba(236, 72, 153, 0.1);
        }

        /* Mobile Menu Toggle */
        .mobile-toggle {
            display: none;
            background: none;
            border: none;
            font-size: 24px;
            color: var(--primary-pink);
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .mobile-toggle:hover {
            background: rgba(236, 72, 153, 0.1);
        }

        /* Main Container */
        .main-container {
            padding: 120px 32px 80px;
            max-width: 1400px;
            margin: 0 auto;
        }

        /* Page Header */
        .page-header {
            text-align: center;
            margin-bottom: 48px;
        }

        .page-title {
            font-size: 48px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 16px;
            line-height: 1.1;
        }

        .page-subtitle {
            font-size: 20px;
            color: rgba(255, 255, 255, 0.9);
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        /* Order Stats */
        .order-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 24px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 24px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            text-align: center;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 16px 48px var(--shadow-pink);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            margin: 0 auto 16px;
        }

        .stat-icon.total { background: linear-gradient(135deg, var(--info-color), #2563EB); }
        .stat-icon.delivered { background: linear-gradient(135deg, var(--success-color), #059669); }
        .stat-icon.pending { background: linear-gradient(135deg, var(--warning-color), #D97706); }
        .stat-icon.spent { background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple)); }

        .stat-value {
            font-size: 32px;
            font-weight: 800;
            color: var(--text-primary);
            margin-bottom: 8px;
        }

        .stat-label {
            font-size: 14px;
            color: var(--text-secondary);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Orders Container */
        .orders-container {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            box-shadow: 0 16px 48px var(--shadow-pink);
            border: 1px solid var(--border-light);
            overflow: hidden;
            position: relative;
        }

        .orders-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        .orders-header {
            padding: 32px;
            border-bottom: 1px solid var(--border-light);
            background: linear-gradient(135deg, rgba(236, 72, 153, 0.05), rgba(139, 92, 246, 0.05));
        }

        .orders-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* Order Card */
        .order-card {
            padding: 32px;
            border-bottom: 1px solid var(--border-light);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .order-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(236, 72, 153, 0.05), transparent);
            transition: left 0.5s ease;
        }

        .order-card:hover::before {
            left: 100%;
        }

        .order-card:hover {
            background: rgba(236, 72, 153, 0.02);
            transform: translateX(4px);
        }

        .order-card:last-child {
            border-bottom: none;
        }

        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--border-light);
        }

        .order-id {
            font-size: 20px;
            font-weight: 700;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .order-status {
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            display: flex;
            align-items: center;
            gap: 6px;
            position: relative;
            overflow: hidden;
        }

        .order-status::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .order-status:hover::before {
            left: 100%;
        }

        .status-pending {
            background: linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(217, 119, 6, 0.1));
            color: var(--warning-color);
            border: 1px solid rgba(245, 158, 11, 0.2);
        }

        .status-approved {
            background: linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(124, 58, 237, 0.1));
            color: var(--accent-purple);
            border: 1px solid rgba(139, 92, 246, 0.2);
        }

        .status-preparing {
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(37, 99, 235, 0.1));
            color: var(--info-color);
            border: 1px solid rgba(59, 130, 246, 0.2);
        }

        .status-out_for_delivery {
            background: linear-gradient(135deg, rgba(6, 182, 212, 0.1), rgba(8, 145, 178, 0.1));
            color: #06B6D4;
            border: 1px solid rgba(6, 182, 212, 0.2);
        }

        .status-delivered {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(5, 150, 105, 0.1));
            color: var(--success-color);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .status-rejected {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(220, 38, 38, 0.1));
            color: var(--error-color);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .status-canceled {
            background: linear-gradient(135deg, rgba(107, 114, 128, 0.1), rgba(75, 85, 99, 0.1));
            color: var(--text-secondary);
            border: 1px solid rgba(107, 114, 128, 0.2);
        }

        .order-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 24px;
            margin-bottom: 24px;
        }

        .info-group {
            background: rgba(236, 72, 153, 0.05);
            padding: 16px;
            border-radius: 12px;
            border: 1px solid var(--border-light);
        }

        .info-group h4 {
            font-size: 14px;
            font-weight: 700;
            color: var(--primary-pink);
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .info-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .info-item:last-child {
            margin-bottom: 0;
        }

        .info-label {
            color: var(--text-secondary);
            font-weight: 500;
        }

        .info-value {
            color: var(--text-primary);
            font-weight: 600;
        }

        /* Order Items */
        .order-items {
            margin-bottom: 24px;
        }

        .items-header {
            font-size: 18px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .items-list {
            background: rgba(236, 72, 153, 0.05);
            border-radius: 12px;
            border: 1px solid var(--border-light);
            overflow: hidden;
        }

        .item {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            padding: 16px;
            border-bottom: 1px solid var(--border-light);
            transition: all 0.3s ease;
        }

        .item:hover {
            background: rgba(236, 72, 153, 0.08);
        }

        .item:last-child {
            border-bottom: none;
        }

        .item-details {
            flex: 1;
        }

        .item-name {
            font-size: 16px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 4px;
        }

        .item-quantity {
            font-size: 14px;
            color: var(--text-secondary);
            margin-bottom: 8px;
        }

        .item-customizations {
            font-size: 12px;
            color: var(--text-light);
            background: rgba(255, 255, 255, 0.5);
            padding: 6px 10px;
            border-radius: 6px;
            border: 1px solid rgba(236, 72, 153, 0.1);
        }

        .item-price {
            font-size: 18px;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        /* Receipt Section */
        .receipt-section {
            background: rgba(236, 72, 153, 0.05);
            padding: 20px;
            border-radius: 12px;
            border: 1px solid var(--border-light);
            margin-bottom: 24px;
        }

        .receipt-header {
            font-size: 16px;
            font-weight: 700;
            color: var(--primary-pink);
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .transaction-id {
            font-size: 14px;
            color: var(--text-secondary);
            margin-bottom: 12px;
            font-family: 'Courier New', monospace;
            background: rgba(255, 255, 255, 0.5);
            padding: 8px 12px;
            border-radius: 6px;
            border: 1px solid var(--border-light);
        }

        .receipt-image {
            max-width: 200px;
            border-radius: 12px;
            border: 2px solid var(--border-light);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .receipt-image:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 25px var(--shadow-pink);
        }

        /* Order Actions */
        .order-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 12px 20px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border: none;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            text-decoration: none;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-cancel {
            background: linear-gradient(135deg, var(--warning-color), #D97706);
            color: white;
            box-shadow: 0 4px 15px rgba(245, 158, 11, 0.3);
        }

        .btn-cancel:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(245, 158, 11, 0.4);
        }

        .btn-received {
            background: linear-gradient(135deg, var(--success-color), #059669);
            color: white;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
        }

        .btn-received:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.4);
        }

        /* Empty State */
        .empty-orders {
            text-align: center;
            padding: 80px 32px;
            color: var(--text-secondary);
        }

        .empty-orders-icon {
            font-size: 80px;
            color: var(--text-light);
            margin-bottom: 24px;
            opacity: 0.5;
        }

        .empty-orders h3 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 16px;
            color: var(--text-primary);
        }

        .empty-orders p {
            font-size: 18px;
            line-height: 1.6;
            margin-bottom: 32px;
        }

        .empty-orders .btn {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            box-shadow: 0 4px 15px var(--shadow-pink);
            padding: 16px 32px;
            font-size: 16px;
        }

        .empty-orders .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px var(--shadow-pink);
        }

        /* Floating particles */
        .floating-element {
            position: absolute;
            border-radius: 50%;
            background: linear-gradient(45deg, var(--primary-pink), var(--secondary-pink));
            animation: float 20s infinite linear;
            pointer-events: none;
            opacity: 0.6;
        }

        .floating-element.pink {
            background: linear-gradient(45deg, var(--secondary-pink), var(--primary-pink-light));
            animation: floatPink 25s infinite linear;
            opacity: 0.4;
        }

        @keyframes float {
            0% {
                transform: translateY(100vh) rotate(0deg) scale(0);
                opacity: 0;
            }
            10% {
                opacity: 0.6;
                transform: translateY(90vh) rotate(36deg) scale(1);
            }
            90% {
                opacity: 0.6;
                transform: translateY(-10vh) rotate(324deg) scale(1);
            }
            100% {
                transform: translateY(-100vh) rotate(360deg) scale(0);
                opacity: 0;
            }
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .order-info {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .mobile-toggle {
                display: block;
            }
            
            .nav-links {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: var(--surface-white);
                backdrop-filter: blur(25px);
                flex-direction: column;
                padding: 20px;
                box-shadow: 0 8px 32px var(--shadow-pink);
                border-top: 1px solid var(--border-light);
                gap: 8px;
            }
            
            .nav-links.open {
                display: flex;
            }
            
            .main-container {
                padding: 100px 20px 60px;
            }
            
            .page-title {
                font-size: 36px;
            }
            
            .order-header {
                flex-direction: column;
                gap: 16px;
                text-align: center;
            }
            
            .order-actions {
                justify-content: center;
            }
            
            .btn {
                flex: 1;
                min-width: 120px;
            }
        }

        @media (max-width: 480px) {
            .nav-container {
                padding: 12px 20px;
            }
            
            .page-title {
                font-size: 28px;
            }
            
            .order-stats {
                grid-template-columns: 1fr;
                gap: 16px;
            }
            
            .orders-header,
            .order-card {
                padding: 20px;
            }
            
            .item {
                flex-direction: column;
                gap: 12px;
                text-align: left;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(236, 72, 153, 0.1);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--primary-pink-dark), var(--primary-pink));
        }

        /* Loading Animation */
        .loading {
            opacity: 0;
            animation: fadeIn 0.6s ease forwards;
        }

        @keyframes fadeIn {
            to { opacity: 1; }
        }
    </style>
</head>
<body>
    <!-- Floating Elements -->
    <div class="floating-element" style="left: 5%; width: 6px; height: 6px; animation-delay: 0s;"></div>
    <div class="floating-element pink" style="left: 15%; width: 4px; height: 4px; animation-delay: 3s;"></div>
    <div class="floating-element" style="left: 25%; width: 8px; height: 8px; animation-delay: 6s;"></div>
    <div class="floating-element pink" style="left: 35%; width: 5px; height: 5px; animation-delay: 9s;"></div>
    <div class="floating-element" style="left: 45%; width: 7px; height: 7px; animation-delay: 12s;"></div>
    <div class="floating-element pink" style="left: 55%; width: 4px; height: 4px; animation-delay: 15s;"></div>
    <div class="floating-element" style="left: 65%; width: 6px; height: 6px; animation-delay: 18s;"></div>
    <div class="floating-element pink" style="left: 75%; width: 5px; height: 5px; animation-delay: 21s;"></div>
    <div class="floating-element" style="left: 85%; width: 7px; height: 7px; animation-delay: 24s;"></div>
    <div class="floating-element pink" style="left: 95%; width: 4px; height: 4px; animation-delay: 27s;"></div>

    <!-- Navigation -->
    <nav class="navbar" id="navbar">
        <div class="nav-container">
            <a href="../index.php" class="nav-brand">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo" class="nav-logo">
                <div class="brand-text">
                    <div class="brand-name">AIZCAmble</div>
                    <div class="brand-tagline">My Orders</div>
                </div>
            </a>
            
            <div class="nav-links" id="navLinks">
                <a href="../index.php" class="nav-link">
                    <i class="fas fa-home"></i>
                    Home
                </a>
                <a href="../Home.php" class="nav-link">
                    <i class="fas fa-store"></i>
                    Shop
                </a>
                <a href="cart.php" class="nav-link">
                    <i class="fas fa-shopping-cart"></i>
                    Cart
                </a>
                <a href="orders.php" class="nav-link active">
                    <i class="fas fa-receipt"></i>
                    My Orders
                </a>
                <a href="../logout.php" class="nav-link">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
            
            <button class="mobile-toggle" id="mobileToggle">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </nav>

    <!-- Main Container -->
    <div class="main-container">
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-title">My Orders</h1>
            <p class="page-subtitle">Track your delicious treats and order history</p>
        </div>

        <!-- Order Statistics -->
        <div class="order-stats">
            <div class="stat-card">
                <div class="stat-icon total">
                    <i class="fas fa-receipt"></i>
                </div>
                <div class="stat-value"><?= number_format($stats['total_orders']) ?></div>
                <div class="stat-label">Total Orders</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon delivered">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-value"><?= number_format($stats['delivered_orders']) ?></div>
                <div class="stat-label">Delivered</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon pending">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-value"><?= number_format($stats['pending_orders']) ?></div>
                <div class="stat-label">Pending</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon spent">
                    <i class="fas fa-peso-sign"></i>
                </div>
                <div class="stat-value">₱<?= number_format($stats['total_spent'], 2) ?></div>
                <div class="stat-label">Total Spent</div>
            </div>
        </div>

        <!-- Orders Container -->
        <div class="orders-container">
            <div class="orders-header">
                <h2 class="orders-title">
                    <i class="fas fa-list"></i>
                    Order History
                </h2>
            </div>
            
            <?php if ($orders->num_rows > 0): ?>
                <?php while ($order = $orders->fetch_assoc()): ?>
                    <div class="order-card loading" id="order-<?= $order['id'] ?>">
                        <div class="order-header">
                            <div class="order-id">
                                <i class="fas fa-hashtag"></i>
                                Order #<?= $order['id'] ?>
                            </div>
                            <div class="order-status status-<?= $order['status'] ?>">
                                <?php
                                $statusIcons = [
                                    'pending' => 'fas fa-clock',
                                    'approved' => 'fas fa-check',
                                    'preparing' => 'fas fa-utensils',
                                    'out_for_delivery' => 'fas fa-truck',
                                    'delivered' => 'fas fa-check-circle',
                                    'rejected' => 'fas fa-times-circle',
                                    'canceled' => 'fas fa-ban'
                                ];
                                ?>
                                <i class="<?= $statusIcons[$order['status']] ?? 'fas fa-info-circle' ?>"></i>
                                <?= ucfirst(str_replace('_', ' ', $order['status'])) ?>
                            </div>
                        </div>
                        
                        <div class="order-info">
                            <div class="info-group">
                                <h4><i class="fas fa-calendar"></i> Order Details</h4>
                                <div class="info-item">
                                    <span class="info-label">Date:</span>
                                    <span class="info-value"><?= date('M d, Y h:i A', strtotime($order['created_at'])) ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Total:</span>
                                    <span class="info-value">₱<?= number_format($order['total_amount'], 2) ?></span>
                                </div>
                            </div>
                            
                            <div class="info-group">
                                <h4><i class="fas fa-credit-card"></i> Payment & Delivery</h4>
                                <div class="info-item">
                                    <span class="info-label">Payment:</span>
                                    <span class="info-value"><?= strtoupper($order['payment_method']) ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Delivery to:</span>
                                    <span class="info-value"><?= htmlspecialchars($order['area']) ?></span>
                                </div>
                                <?php if (!empty($order['landmark'])): ?>
                                    <div class="info-item">
                                        <span class="info-label">Landmark:</span>
                                        <span class="info-value"><?= htmlspecialchars($order['landmark']) ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="order-items">
                            <h3 class="items-header">
                                <i class="fas fa-shopping-bag"></i>
                                Order Items
                            </h3>
                            <div class="items-list">
                                <?php
                                $stmt2 = $conn->prepare("SELECT oi.*, p.name, p.price FROM order_items oi 
                                                        JOIN products p ON oi.product_id = p.id 
                                                        WHERE oi.order_id = ?");
                                $stmt2->bind_param("i", $order['id']);
                                $stmt2->execute();
                                $items = $stmt2->get_result();
                                ?>
                                <?php while ($item = $items->fetch_assoc()): ?>
                                    <div class="item">
                                        <div class="item-details">
                                            <div class="item-name"><?= htmlspecialchars($item['name']) ?></div>
                                            <div class="item-quantity">Quantity: <?= $item['quantity'] ?></div>
                                            <?php if (!empty($item['customizations'])): ?>
                                                <?php 
                                                $customizations = json_decode($item['customizations'], true);
                                                if ($customizations): ?>
                                                    <div class="item-customizations">
                                                        <?= implode(', ', array_map(
                                                            fn($k, $v) => htmlspecialchars("$k: " . (is_array($v) ? implode('/', $v) : $v)), 
                                                            array_keys($customizations), 
                                                            array_values($customizations)
                                                        )) ?>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                        <div class="item-price">
                                            ₱<?= number_format($item['price'] * $item['quantity'], 2) ?>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        </div>
                        
                        <?php if ($order['payment_method'] === 'gcash'): ?>
                            <div class="receipt-section">
                                <h4 class="receipt-header">
                                    <i class="fas fa-receipt"></i>
                                    Payment Receipt
                                </h4>
                                <?php if (!empty($order['transaction_id'])): ?>
                                    <div class="transaction-id">
                                        <strong>Transaction ID:</strong> <?= htmlspecialchars($order['transaction_id']) ?>
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($order['receipt_image'])): ?>
                                    <img src="<?= htmlspecialchars($order['receipt_image']) ?>" 
                                         alt="GCASH Receipt" 
                                         class="receipt-image"
                                         onclick="window.open(this.src, '_blank')">
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($order['status'] === 'pending' || $order['status'] === 'approved'): ?>
                            <div class="order-actions">
                                <button onclick="cancelOrder(<?= $order['id'] ?>)" class="btn btn-cancel">
                                    <i class="fas fa-times"></i>
                                    Cancel Order
                                </button>
                            </div>
                        <?php elseif ($order['status'] === 'out_for_delivery'): ?>
                            <div class="order-actions">
                                <button onclick="markAsReceived(<?= $order['id'] ?>)" class="btn btn-received">
                                    <i class="fas fa-check"></i>
                                    Mark as Received
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty-orders">
                    <div class="empty-orders-icon">
                        <i class="fas fa-receipt"></i>
                    </div>
                    <h3>No Orders Yet</h3>
                    <p>You haven't placed any orders yet.<br>
                    Visit our shop to place your first order and enjoy our delicious treats!</p>
                    <a href="../Home.php" class="btn">
                        <i class="fas fa-store"></i>
                        Start Shopping
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Mobile menu toggle
        const mobileToggle = document.getElementById('mobileToggle');
        const navLinks = document.getElementById('navLinks');

        mobileToggle.addEventListener('click', function() {
            navLinks.classList.toggle('open');
            const icon = this.querySelector('i');
            if (navLinks.classList.contains('open')) {
                icon.className = 'fas fa-times';
            } else {
                icon.className = 'fas fa-bars';
            }
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!navLinks.contains(event.target) && !mobileToggle.contains(event.target)) {
                navLinks.classList.remove('open');
                mobileToggle.querySelector('i').className = 'fas fa-bars';
            }
        });

        // Parallax effect for floating elements
        document.addEventListener('mousemove', function(e) {
            const mouseX = e.clientX / window.innerWidth;
            const mouseY = e.clientY / window.innerHeight;
            
            // Move floating elements based on mouse position
            document.querySelectorAll('.floating-element').forEach((element, index) => {
                const speed = (index % 3 + 1) * 0.5;
                const x = (mouseX - 0.5) * speed * 20;
                const y = (mouseY - 0.5) * speed * 20;
                element.style.transform = `translate(${x}px, ${y}px)`;
            });
        });

        // Loading animations
        window.addEventListener('load', function() {
            document.querySelectorAll('.order-card.loading').forEach((card, index) => {
                setTimeout(() => {
                    card.classList.remove('loading');
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 100);
            });
        });

        // Enhanced brand interaction
        document.querySelector('.nav-brand').addEventListener('mouseenter', function() {
            this.querySelector('.brand-name').style.transform = 'scale(1.05)';
            this.querySelector('.brand-tagline').style.color = 'var(--primary-pink)';
        });

        document.querySelector('.nav-brand').addEventListener('mouseleave', function() {
            this.querySelector('.brand-name').style.transform = 'scale(1)';
            this.querySelector('.brand-tagline').style.color = 'var(--text-light)';
        });

        // Order action functions
        function cancelOrder(orderId) {
            if (!confirm('Are you sure you want to cancel this order?')) return;
            
            const orderCard = document.getElementById(`order-${orderId}`);
            const statusDiv = orderCard.querySelector('.order-status');
            const actionsDiv = orderCard.querySelector('.order-actions');
            
            // Show loading state
            if (actionsDiv) {
                actionsDiv.innerHTML = '<span style="color: var(--text-secondary);"><i class="fas fa-spinner fa-spin"></i> Processing...</span>';
            }
            
            fetch('../admin/update_order_status.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `order_id=${orderId}&status=canceled`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    statusDiv.className = 'order-status status-canceled';
                    statusDiv.innerHTML = '<i class="fas fa-ban"></i> Canceled';
                    if (actionsDiv) actionsDiv.remove();
                    
                    // Show success message
                    showNotification('Order has been canceled successfully!', 'success');
                } else {
                    throw new Error(data.message || 'Failed to cancel order');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                if (actionsDiv) {
                    actionsDiv.innerHTML = '<button onclick="cancelOrder(' + orderId + ')" class="btn btn-cancel"><i class="fas fa-times"></i> Cancel Order</button>';
                }
                showNotification(`Error: ${error.message || 'Something went wrong'}`, 'error');
            });
        }

        function markAsReceived(orderId) {
            if (!confirm('Confirm you have received this order?')) return;
            
            const orderCard = document.getElementById(`order-${orderId}`);
            const statusDiv = orderCard.querySelector('.order-status');
            const actionsDiv = orderCard.querySelector('.order-actions');
            
            // Show loading state
            if (actionsDiv) {
                actionsDiv.innerHTML = '<span style="color: var(--text-secondary);"><i class="fas fa-spinner fa-spin"></i> Processing...</span>';
            }
            
            fetch('../admin/update_order_status.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `order_id=${orderId}&status=delivered`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    statusDiv.className = 'order-status status-delivered';
                    statusDiv.innerHTML = '<i class="fas fa-check-circle"></i> Delivered';
                    if (actionsDiv) actionsDiv.remove();
                    
                    // Show success message
                    showNotification('Thank you for confirming your order!', 'success');
                } else {
                    throw new Error(data.message || 'Failed to update status');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                if (actionsDiv) {
                    actionsDiv.innerHTML = '<button onclick="markAsReceived(' + orderId + ')" class="btn btn-received"><i class="fas fa-check"></i> Mark as Received</button>';
                }
                showNotification(`Error: ${error.message || 'Something went wrong'}`, 'error');
            });
        }

        // Notification system
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = `alert alert-${type}`;
            notification.style.cssText = `
                position: fixed;
                top: 100px;
                right: 32px;
                z-index: 10000;
                max-width: 400px;
                animation: slideInRight 0.5s ease;
            `;
            
            const icon = type === 'success' ? 'fas fa-check-circle' : 
                        type === 'error' ? 'fas fa-exclamation-circle' : 
                        'fas fa-info-circle';
            
            notification.innerHTML = `
                <i class="${icon}"></i>
                <div>${message}</div>
            `;
            
            document.body.appendChild(notification);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                notification.style.animation = 'slideOutRight 0.5s ease';
                setTimeout(() => notification.remove(), 500);
            }, 5000);
        }

        // Add slide animations
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInRight {
                0% { transform: translateX(100%); opacity: 0; }
                100% { transform: translateX(0); opacity: 1; }
            }
            
            @keyframes slideOutRight {
                0% { transform: translateX(0); opacity: 1; }
                100% { transform: translateX(100%); opacity: 0; }
            }
        `;
        document.head.appendChild(style);

        // Enhanced button interactions
        document.querySelectorAll('.btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                // Add ripple effect
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.cssText = `
                    width: ${size}px;
                    height: ${size}px;
                    left: ${x}px;
                    top: ${y}px;
                    position: absolute;
                    border-radius: 50%;
                    background: rgba(255, 255, 255, 0.4);
                    transform: scale(0);
                    animation: rippleEffect 0.6s ease-out;
                    pointer-events: none;
                `;
                
                this.style.position = 'relative';
                this.style.overflow = 'hidden';
                this.appendChild(ripple);
                
                setTimeout(() => ripple.remove(), 600);
            });
        });

        // Add ripple animation
        const rippleStyle = document.createElement('style');
        rippleStyle.textContent = `
            @keyframes rippleEffect {
                0% {
                    transform: scale(0);
                    opacity: 1;
                }
                100% {
                    transform: scale(4);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(rippleStyle);

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Dynamic background color shifts
        setInterval(() => {
            const hue = Math.random() * 30 + 320; // Pink to purple range
            document.documentElement.style.setProperty('--dynamic-bg', `hsl(${hue}, 70%, 15%)`);
        }, 5000);

        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            // 'r' to refresh
            if (e.key === 'r' && !e.ctrlKey && !e.metaKey) {
                const activeElement = document.activeElement;
                if (activeElement.tagName !== 'INPUT' && activeElement.tagName !== 'TEXTAREA') {
                    e.preventDefault();
                    location.reload();
                }
            }
        });

        // Order card animations
        document.querySelectorAll('.order-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateX(8px) scale(1.01)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateX(4px) scale(1)';
            });
        });

        // Stat card animations
        document.querySelectorAll('.stat-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-8px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(-5px) scale(1)';
            });
        });
    </script>
</body>
</html>
