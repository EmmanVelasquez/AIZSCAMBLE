<?php
session_start();
include('../includes/db.php');
require_once('../includes/notify_helper.php');

if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../user/login.php");
    exit;
}

// Handle Excel Export
if (isset($_GET['export']) && $_GET['export'] == 'excel') {
    $start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-7 days'));
    $end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
    
    // Set headers for Excel download
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Sales_Report_' . date('Y-m-d') . '.xls"');
    header('Cache-Control: max-age=0');
    
    // Output the Excel file header
    echo '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <style>
            table {
                border-collapse: collapse;
                width: 100%;
            }
            th, td {
                border: 1px solid #ddd;
                padding: 8px;
                text-align: left;
            }
            th {
                background-color: #f2f2f2;
                font-weight: bold;
            }
        </style>
    </head>
    <body>
    ';
    
    // Daily Sales Analytics Query
    $sales_query = "
    SELECT 
        p.id AS product_id,
        p.name AS product_name,
        DATE(o.created_at) AS sale_date,
        SUM(oi.quantity) AS total_quantity,
        COUNT(DISTINCT o.id) AS transaction_count,
        SUM(oi.quantity * oi.price) AS total_sales,
        o.status
    FROM 
        products p
    JOIN 
        order_items oi ON p.id = oi.product_id
    JOIN 
        orders o ON oi.order_id = o.id
    WHERE 
        DATE(o.created_at) BETWEEN ? AND ?
    GROUP BY 
        p.id, p.name, DATE(o.created_at), o.status
    ORDER BY 
        sale_date DESC, p.name ASC
";

    $stmt = $conn->prepare($sales_query);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Calculate total sales for the period
    $total_sales_query = "
    SELECT 
        SUM(oi.quantity * oi.price) AS period_total
    FROM 
        order_items oi
    JOIN 
        orders o ON oi.order_id = o.id
    WHERE 
        DATE(o.created_at) BETWEEN ? AND ?
";

    $stmt = $conn->prepare($total_sales_query);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $total_result = $stmt->get_result();
    $total_row = $total_result->fetch_assoc();
    $period_total = $total_row['period_total'] ?? 0;
    
    // Output the report title and summary
    echo '
    <h1>Sales Analytics Report</h1>
    <p>Period: ' . date('M d, Y', strtotime($start_date)) . ' to ' . date('M d, Y', strtotime($end_date)) . '</p>
    <p>Total Sales for Period: ₱' . number_format($period_total, 2) . '</p>
    
    <table>
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Date of Sale</th>
                <th>Total Quantity Sold</th>
                <th>Number of Transactions</th>
                <th>Total Sales Amount</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
    ';
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<tr>
                <td>' . htmlspecialchars($row['product_name']) . '</td>
                <td>' . date('Y-m-d', strtotime($row['sale_date'])) . '</td>
                <td>' . $row['total_quantity'] . '</td>
                <td>' . $row['transaction_count'] . '</td>
                <td>₱' . number_format($row['total_sales'], 2) . '</td>
                <td>' . ucfirst(str_replace('_', ' ', $row['status'])) . '</td>
            </tr>';
        }
    } else {
        echo '<tr><td colspan="5" style="text-align: center;">No sales data found for the selected period.</td></tr>';
    }
    
    echo '</tbody></table>';
    
    // Close the HTML document
    echo '
    </body>
    </html>
    ';
    
    exit;
}

// Get unread notification count for the bell icon
$unreadCount = $conn->query("SELECT COUNT(*) as total FROM AdminNotifications WHERE IsRead = 0")->fetch_assoc()['total'];

// Fetch notifications for the dropdown
$notifQuery = $conn->query("SELECT * FROM AdminNotifications ORDER BY CreatedAt DESC LIMIT 5");

// Set default date range for sales analytics (last 7 days)
$end_date = date('Y-m-d');
$start_date = date('Y-m-d', strtotime('-7 days'));

// Handle date filter for sales analytics
if (isset($_GET['start_date']) && isset($_GET['end_date'])) {
    $start_date = $_GET['start_date'];
    $end_date = $_GET['end_date'];
}

// Daily Sales Analytics Query
$sales_query = "
    SELECT 
        p.id AS product_id,
        p.name AS product_name,
        DATE(o.created_at) AS sale_date,
        SUM(oi.quantity) AS total_quantity,
        COUNT(DISTINCT o.id) AS transaction_count,
        SUM(oi.quantity * oi.price) AS total_sales,
        o.status
    FROM 
        products p
    JOIN 
        order_items oi ON p.id = oi.product_id
    JOIN 
        orders o ON oi.order_id = o.id
    WHERE 
        DATE(o.created_at) BETWEEN ? AND ?
    GROUP BY 
        p.id, p.name, DATE(o.created_at), o.status
    ORDER BY 
        sale_date DESC, p.name ASC
";

$stmt = $conn->prepare($sales_query);
$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$sales_result = $stmt->get_result();

// Calculate total sales for the selected period
$total_sales_query = "
    SELECT 
        SUM(oi.quantity * oi.price) AS period_total
    FROM 
        order_items oi
    JOIN 
        orders o ON oi.order_id = o.id
    WHERE 
        DATE(o.created_at) BETWEEN ? AND ?
";

$stmt = $conn->prepare($total_sales_query);
$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$total_result = $stmt->get_result();
$total_row = $total_result->fetch_assoc();
$period_total = $total_row['period_total'] ?? 0;

// Get top selling products for the period
$top_products_query = "
    SELECT 
        p.id AS product_id,
        p.name AS product_name,
        SUM(oi.quantity) AS total_quantity
    FROM 
        products p
    JOIN 
        order_items oi ON p.id = oi.product_id
    JOIN 
        orders o ON oi.order_id = o.id
    WHERE 
        DATE(o.created_at) BETWEEN ? AND ?
    GROUP BY 
        p.id, p.name
    ORDER BY 
        total_quantity DESC
    LIMIT 5
";

$stmt = $conn->prepare($top_products_query);
$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$top_products_result = $stmt->get_result();

// Get sales by day for the period
$daily_sales_query = "
    SELECT 
        DATE(o.created_at) AS sale_date,
        SUM(oi.quantity * oi.price) AS daily_total
    FROM 
        order_items oi
    JOIN 
        orders o ON oi.order_id = o.id
    WHERE 
        DATE(o.created_at) BETWEEN ? AND ?
    GROUP BY 
        DATE(o.created_at)
    ORDER BY 
        sale_date ASC
";

$stmt = $conn->prepare($daily_sales_query);
$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$daily_sales_result = $stmt->get_result();

// Calculate average daily sales
$avg_daily_sales = 0;
if ($daily_sales_result->num_rows > 0) {
    $total_days = $daily_sales_result->num_rows;
    $avg_daily_sales = $period_total / $total_days;
}

// Get total number of transactions
$transactions_query = "
    SELECT 
        COUNT(DISTINCT o.id) AS total_transactions
    FROM 
        orders o
    JOIN 
        order_items oi ON o.id = oi.order_id
    WHERE 
        DATE(o.created_at) BETWEEN ? AND ?
";

$stmt = $conn->prepare($transactions_query);
$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$transactions_result = $stmt->get_result();
$transactions_row = $transactions_result->fetch_assoc();
$total_transactions = $transactions_row['total_transactions'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Analytics - AIZCAmble</title>
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --error-color: #EF4444;
            --info-color: #3B82F6;
            --shadow-pink: rgba(236, 72, 153, 0.2);
            --shadow-strong: rgba(0, 0, 0, 0.1);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-gradient-start) 0%, var(--background-gradient-end) 100%);
            min-height: 100vh;
            display: flex;
            color: var(--text-primary);
            position: relative;
            overflow-x: hidden;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, var(--primary-pink) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, var(--accent-purple) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, var(--secondary-pink) 0%, transparent 50%);
            opacity: 0.05;
            z-index: -1;
            animation: backgroundFloat 20s ease-in-out infinite;
        }

        @keyframes backgroundFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(-20px, -20px) scale(1.05); }
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary-pink) 0%, var(--primary-pink-dark) 100%);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--border-light);
            box-shadow: 4px 0 20px var(--shadow-pink);
            padding: 0;
            min-height: 100vh;
            position: relative;
            overflow: hidden;
        }

        .sidebar::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.1) 50%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
        }

        @keyframes shimmer {
            0%, 100% { transform: translateX(-100%); }
            50% { transform: translateX(100%); }
        }

        .logo-section {
            text-align: center;
            padding: 32px 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            position: relative;
            z-index: 2;
        }

        .logo-container {
            position: relative;
            display: inline-block;
            margin-bottom: 16px;
        }

        .logo-container::before {
            content: '';
            position: absolute;
            top: -8px;
            left: -8px;
            right: -8px;
            bottom: -8px;
            background: linear-gradient(45deg, rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0.1));
            border-radius: 50%;
            animation: logoGlow 2s ease-in-out infinite;
        }

        @keyframes logoGlow {
            0%, 100% { transform: scale(1); opacity: 0.7; }
            50% { transform: scale(1.05); opacity: 1; }
        }

        .logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(255, 255, 255, 0.9);
            object-fit: cover;
            position: relative;
            z-index: 2;
            transition: all 0.3s ease;
        }

        .logo:hover {
            transform: scale(1.1) rotate(5deg);
        }

        .brand-name {
            color: white;
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 8px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .admin-title {
            color: rgba(255, 255, 255, 0.9);
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-menu {
            padding: 24px 0;
            position: relative;
            z-index: 2;
        }

        .nav-item {
            display: block;
            padding: 16px 24px;
            margin: 8px 16px;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            border-radius: 16px;
            font-weight: 500;
            font-size: 15px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
        }

        .nav-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .nav-item:hover::before {
            left: 100%;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(8px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item.active {
            background: rgba(255, 255, 255, 0.25);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        .main-content {
            flex: 1;
            padding: 32px;
            overflow-y: auto;
            position: relative;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            padding: 24px 32px;
            border-radius: 20px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            position: relative;
            overflow: hidden;
        }

        .header-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .page-title {
            font-size: 32px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* Notification Bell */
        .notification-bell {
            position: relative;
            display: inline-block;
        }

        .notification-bell button {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border: none;
            border-radius: 50%;
            width: 48px;
            height: 48px;
            color: white;
            font-size: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        .notification-bell button:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 20px var(--shadow-pink);
        }

        .notification-badge {
            position: absolute;
            top: -6px;
            right: -6px;
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
            border-radius: 50%;
            padding: 4px 8px;
            font-size: 12px;
            font-weight: 700;
            min-width: 20px;
            text-align: center;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }

        .notification-dropdown {
            display: none;
            position: absolute;
            right: 0;
            top: 60px;
            background: white;
            width: 350px;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            max-height: 400px;
            overflow: hidden;
            border: 1px solid var(--border-light);
        }

        .notification-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 20px;
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            font-weight: 600;
        }

        .notification-header a {
            color: white;
            font-size: 12px;
            text-decoration: none;
            opacity: 0.9;
            transition: opacity 0.2s;
        }

        .notification-header a:hover {
            opacity: 1;
        }

        .notification-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            max-height: 300px;
            overflow-y: auto;
        }

        .notification-dropdown li {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border-light);
            transition: background-color 0.2s;
        }

        .notification-dropdown li:last-child {
            border-bottom: none;
        }

        .notification-dropdown li:hover {
            background-color: rgba(236, 72, 153, 0.05);
        }

        .notification-footer {
            padding: 16px 20px;
            text-align: center;
            border-top: 1px solid var(--border-light);
            background: rgba(236, 72, 153, 0.05);
        }

        .notification-footer a {
            color: var(--primary-pink);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.2s;
        }

        .notification-footer a:hover {
            color: var(--primary-pink-dark);
        }

        /* Alert Messages */
        .message, .error {
            padding: 16px 20px;
            margin-bottom: 24px;
            border-radius: 12px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .message {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(5, 150, 105, 0.1));
            color: var(--success-color);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .error {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(220, 38, 38, 0.1));
            color: var(--error-color);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        /* Analytics Container */
        .analytics-container {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 32px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            position: relative;
            overflow: hidden;
        }

        .analytics-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        .analytics-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 32px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .analytics-title i {
            color: var(--primary-pink);
            font-size: 20px;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 24px;
            margin-bottom: 32px;
        }

        .stat-card {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            padding: 24px;
            border-radius: 16px;
            box-shadow: 0 8px 25px var(--shadow-pink);
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.1) 50%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
        }

        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 35px var(--shadow-pink);
        }

        .stat-card.purple {
            background: linear-gradient(135deg, var(--accent-purple), var(--accent-purple-light));
        }

        .stat-card.success {
            background: linear-gradient(135deg, var(--success-color), #059669);
        }

        .stat-card.info {
            background: linear-gradient(135deg, var(--info-color), #2563EB);
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            position: relative;
            z-index: 2;
        }

        .stat-title {
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            opacity: 0.9;
        }

        .stat-icon {
            font-size: 24px;
            opacity: 0.8;
        }

        .stat-value {
            font-size: 32px;
            font-weight: 800;
            margin-bottom: 8px;
            position: relative;
            z-index: 2;
        }

        .stat-subtitle {
            font-size: 14px;
            opacity: 0.8;
            position: relative;
            z-index: 2;
        }

        /* Top Products Card */
        .top-products-card {
            background: linear-gradient(135deg, var(--secondary-pink), var(--primary-pink-light));
            color: white;
            padding: 24px;
            border-radius: 16px;
            box-shadow: 0 8px 25px var(--shadow-pink);
            position: relative;
            overflow: hidden;
            grid-column: span 2;
        }

        .top-products-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.1) 50%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
        }

        .top-products-list {
            list-style: none;
            padding: 0;
            margin: 16px 0 0 0;
            position: relative;
            z-index: 2;
        }

        .top-products-list li {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.2s ease;
        }

        .top-products-list li:last-child {
            border-bottom: none;
        }

        .top-products-list li:hover {
            background: rgba(255, 255, 255, 0.1);
            padding-left: 8px;
            border-radius: 8px;
        }

        .product-name {
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .product-sales {
            font-weight: 700;
            background: rgba(255, 255, 255, 0.2);
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 14px;
        }

        /* Filter Section */
        .filter-section {
            background: linear-gradient(135deg, rgba(236, 72, 153, 0.05), rgba(139, 92, 246, 0.05));
            padding: 24px;
            border-radius: 16px;
            margin-bottom: 32px;
            border: 1px solid var(--border-light);
        }

        .filter-form {
            display: flex;
            gap: 20px;
            align-items: end;
            flex-wrap: wrap;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .filter-group label {
            font-weight: 600;
            color: var(--text-primary);
            font-size: 14px;
        }

        .filter-group input[type="date"] {
            padding: 12px 16px;
            border: 2px solid var(--border-light);
            border-radius: 12px;
            font-size: 14px;
            font-weight: 500;
            background: white;
            transition: all 0.3s ease;
            outline: none;
        }

        .filter-group input[type="date"]:focus {
            border-color: var(--primary-pink);
            box-shadow: 0 0 0 4px rgba(236, 72, 153, 0.1);
        }

        .filter-actions {
            display: flex;
            gap: 12px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 20px;
            border: none;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
        }

        .btn-success {
            background: linear-gradient(135deg, var(--success-color), #059669);
            color: white;
        }

        /* Table Container */
        .table-container {
            background: white;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--border-light);
            max-height: 600px;
            overflow-y: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            padding: 16px 20px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        td {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border-light);
            font-size: 14px;
            font-weight: 500;
        }

        tr:hover {
            background: rgba(236, 72, 153, 0.02);
        }

        tr:last-child td {
            border-bottom: none;
        }

        /* Status Badges */
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-pending {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning-color);
        }

        .status-approved {
            background: rgba(139, 92, 246, 0.1);
            color: var(--accent-purple);
        }

        .status-preparing {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning-color);
        }

        .status-out_for_delivery {
            background: rgba(59, 130, 246, 0.1);
            color: var(--info-color);
        }

        .status-delivered {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success-color);
        }

        .status-rejected {
            background: rgba(239, 68, 68, 0.1);
            color: var(--error-color);
        }

        .status-canceled {
            background: rgba(156, 163, 175, 0.1);
            color: var(--text-light);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-light);
        }

        .empty-state i {
            font-size: 64px;
            margin-bottom: 20px;
            color: var(--primary-pink);
            opacity: 0.5;
        }

        .empty-state h3 {
            font-size: 20px;
            margin-bottom: 12px;
            color: var(--text-secondary);
        }

        .empty-state p {
            font-size: 16px;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .sidebar {
                width: 240px;
            }
            
            .top-products-card {
                grid-column: span 1;
            }
        }

        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                min-height: auto;
                position: fixed;
                top: 0;
                left: -100%;
                z-index: 1000;
                transition: left 0.3s ease;
            }
            
            .sidebar.open {
                left: 0;
            }
            
            .main-content {
                padding: 20px;
                margin-top: 0;
            }
            
            .header-section {
                flex-direction: column;
                gap: 16px;
                text-align: center;
            }
            
            .page-title {
                font-size: 24px;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .filter-form {
                flex-direction: column;
                align-items: stretch;
            }
            
            .filter-actions {
                justify-content: center;
            }
            
            .table-container {
                overflow-x: auto;
            }
            
            table {
                min-width: 600px;
            }
            
            .notification-dropdown {
                width: 300px;
                right: -50px;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(236, 72, 153, 0.1);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--primary-pink-dark), var(--primary-pink));
        }

        /* Loading Animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <div class="logo-container">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo" class="logo">
            </div>
            <div class="brand-name">AIZCAmble</div>
            <div class="admin-title">Admin Panel</div>
        </div>

        <nav class="nav-menu">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                Dashboard
            </a>
            <a href="orders.php" class="nav-item">
                <i class="fas fa-shopping-bag"></i>
                Manage Orders
            </a>
            <a href="add_product.php" class="nav-item">
                <i class="fas fa-plus-circle"></i>
                Add Product
            </a>
            <a href="stock.php" class="nav-item">
                <i class="fas fa-boxes"></i>
                Stock Management
            </a>
            <a href="sales_analytics.php" class="nav-item active">
                <i class="fas fa-chart-bar"></i>
                Sales Analytics
            </a>
            <a href="users.php" class="nav-item">
                <i class="fas fa-users"></i>
                Customers
            </a>
            <a href="ingredients.php" class="nav-item">
                <i class="fas fa-flask"></i>
                Ingredients
            </a>
            <a href="admins.php" class="nav-item">
                <i class="fas fa-user-shield"></i>
                Admins
            </a>
            <a href="shutdown.php" class="nav-item">
                <i class="fas fa-power-off"></i>
                Shutdown Shop
            </a>
            <a href="activity_log.php" class="nav-item">
                <i class="fas fa-history"></i>
                Activity History
            </a>
            <a href="notifications.php" class="nav-item">
                <i class="fas fa-bell"></i>
                Notifications
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header-section">
            <h1 class="page-title">
                <i class="fas fa-chart-bar"></i>
                Sales Analytics
            </h1>
            
            <!-- Notification Bell -->
            <div class="notification-bell">
                <button onclick="toggleDropdown()">
                    <i class="fas fa-bell"></i>
                    <?php if ($unreadCount > 0): ?>
                        <span class="notification-badge">
                            <?= $unreadCount ?>
                        </span>
                    <?php endif; ?>
                </button>
                <div id="notifDropdown" class="notification-dropdown">
                    <div class="notification-header">
                        <span>Notifications</span>
                        <?php if ($unreadCount > 0): ?>
                            <a href="sales_analytics.php?mark_read=all">Mark all as read</a>
                        <?php endif; ?>
                    </div>
                    <ul>
                        <?php if ($notifQuery->num_rows > 0): ?>
                            <?php while ($notif = $notifQuery->fetch_assoc()): ?>
                                <li style="<?= $notif['IsRead'] ? '' : 'background-color: rgba(236, 72, 153, 0.05);' ?>">
                                    <strong><?= htmlspecialchars($notif['Title']) ?></strong><br>
                                    <small><?= htmlspecialchars($notif['message']) ?></small><br>
                                    <small style="color: #888;"><?= date('M d, Y h:i A', strtotime($notif['CreatedAt'])) ?></small>
                                </li>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <li>No notifications yet</li>
                        <?php endif; ?>
                    </ul>
                    <div class="notification-footer">
                        <a href="notifications.php">View All Notifications</a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Alert Messages -->
        <?php if (isset($_SESSION['message'])): ?>
            <div class="message">
                <i class="fas fa-check-circle"></i>
                <?= $_SESSION['message'] ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error">
                <i class="fas fa-exclamation-circle"></i>
                <?= $_SESSION['error'] ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <!-- Analytics Container -->
        <div class="analytics-container">
            <h3 class="analytics-title">
                <i class="fas fa-chart-line"></i>
                Sales Performance Dashboard
            </h3>
            
            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-header">
                        <div class="stat-title">Total Revenue</div>
                        <div class="stat-icon">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                    </div>
                    <div class="stat-value">₱<?= number_format($period_total, 2) ?></div>
                    <div class="stat-subtitle">
                        <?= date('M d, Y', strtotime($start_date)) ?> - <?= date('M d, Y', strtotime($end_date)) ?>
                    </div>
                </div>
                
                <div class="stat-card purple">
                    <div class="stat-header">
                        <div class="stat-title">Average Daily Sales</div>
                        <div class="stat-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                    </div>
                    <div class="stat-value">₱<?= number_format($avg_daily_sales, 2) ?></div>
                    <div class="stat-subtitle">Per Day Average</div>
                </div>
                
                <div class="stat-card success">
                    <div class="stat-header">
                        <div class="stat-title">Total Transactions</div>
                        <div class="stat-icon">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                    </div>
                    <div class="stat-value"><?= $total_transactions ?></div>
                    <div class="stat-subtitle">Completed Orders</div>
                </div>
                
                <div class="top-products-card">
                    <div class="stat-header">
                        <div class="stat-title">Top Selling Products</div>
                        <div class="stat-icon">
                            <i class="fas fa-trophy"></i>
                        </div>
                    </div>
                    <ul class="top-products-list">
                        <?php if ($top_products_result->num_rows > 0): ?>
                            <?php $rank = 1; ?>
                            <?php while ($row = $top_products_result->fetch_assoc()): ?>
                                <li>
                                    <div class="product-name">
                                        <span style="background: rgba(255, 255, 255, 0.2); padding: 4px 8px; border-radius: 50%; font-size: 12px; font-weight: 700; min-width: 24px; text-align: center;">
                                            <?= $rank ?>
                                        </span>
                                        <?= htmlspecialchars($row['product_name']) ?>
                                    </div>
                                    <div class="product-sales">
                                        <?= $row['total_quantity'] ?> sold
                                    </div>
                                </li>
                                <?php $rank++; ?>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <li>
                                <div class="empty-state" style="padding: 20px 0; color: rgba(255, 255, 255, 0.7);">
                                    <i class="fas fa-chart-bar" style="font-size: 32px; margin-bottom: 8px; display: block;"></i>
                                    No sales data available for this period
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            
            <!-- Filter Section -->
            <div class="filter-section">
                <form class="filter-form" method="GET">
                    <div class="filter-group">
                        <label for="start_date">
                            <i class="fas fa-calendar-alt"></i>
                            Start Date
                        </label>
                        <input type="date" id="start_date" name="start_date" value="<?= $start_date ?>" required>
                    </div>
                    <div class="filter-group">
                        <label for="end_date">
                            <i class="fas fa-calendar-alt"></i>
                            End Date
                        </label>
                        <input type="date" id="end_date" name="end_date" value="<?= $end_date ?>" required>
                    </div>
                    <div class="filter-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-filter"></i>
                            Apply Filter
                        </button>
                        <a href="sales_analytics.php?export=excel&start_date=<?= $start_date ?>&end_date=<?= $end_date ?>" class="btn btn-success" id="exportBtn">
                            <i class="fas fa-file-excel"></i>
                            Export to Excel
                        </a>
                    </div>
                </form>
            </div>
            
            <!-- Sales Table -->
            <div class="table-container">
                <table id="sales-table">
                    <thead>
                        <tr>
                            <th><i class="fas fa-box"></i> Product Name</th>
                            <th><i class="fas fa-calendar"></i> Date of Sale</th>
                            <th><i class="fas fa-sort-numeric-up"></i> Quantity Sold</th>
                            <th><i class="fas fa-receipt"></i> Transactions</th>
                            <th><i class="fas fa-money-bill"></i> Sales Amount</th>
                            <th><i class="fas fa-info-circle"></i> Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($sales_result->num_rows > 0): ?>
                            <?php while ($row = $sales_result->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <strong><?= htmlspecialchars($row['product_name']) ?></strong>
                                    </td>
                                    <td>
                                        <span style="color: var(--text-secondary); font-weight: 500;">
                                            <?= date('M d, Y', strtotime($row['sale_date'])) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span style="font-weight: 600; color: var(--primary-pink);">
                                            <?= $row['total_quantity'] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span style="font-weight: 600; color: var(--accent-purple);">
                                            <?= $row['transaction_count'] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span style="font-weight: 700; color: var(--success-color);">
                                            ₱<?= number_format($row['total_sales'], 2) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="status-badge status-<?= $row['status'] ?>">
                                            <?php
                                            $status_icons = [
                                                'pending' => 'fas fa-clock',
                                                'approved' => 'fas fa-check',
                                                'preparing' => 'fas fa-utensils',
                                                'out_for_delivery' => 'fas fa-truck',
                                                'delivered' => 'fas fa-check-circle',
                                                'rejected' => 'fas fa-times-circle',
                                                'canceled' => 'fas fa-ban'
                                            ];
                                            $icon = $status_icons[$row['status']] ?? 'fas fa-info-circle';
                                            ?>
                                            <i class="<?= $icon ?>"></i>
                                            <?= ucfirst(str_replace('_', ' ', $row['status'])) ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6">
                                    <div class="empty-state">
                                        <i class="fas fa-chart-bar"></i>
                                        <h3>No Sales Data Found</h3>
                                        <p>No sales data available for the selected period. Try adjusting your date range.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Notification dropdown toggle
        function toggleDropdown() {
            const dropdown = document.getElementById('notifDropdown');
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        }

        // Close dropdown when clicking outside
        window.onclick = function(event) {
            const dropdown = document.getElementById('notifDropdown');
            const bell = document.querySelector('.notification-bell button');
            
            if (dropdown && bell && !bell.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = 'none';
            }
        }

        // Mobile sidebar toggle
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('open');
        }

        // Add mobile menu button if needed
        if (window.innerWidth <= 768) {
            const header = document.querySelector('.header-section');
            const menuBtn = document.createElement('button');
            menuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            menuBtn.className = 'btn btn-primary';
            menuBtn.onclick = toggleSidebar;
            menuBtn.style.position = 'absolute';
            menuBtn.style.top = '20px';
            menuBtn.style.left = '20px';
            menuBtn.style.zIndex = '1001';
            document.body.appendChild(menuBtn);
        }

        // Add loading animation for export button
        document.getElementById('exportBtn')?.addEventListener('click', function(e) {
            const btn = e.target.closest('.btn');
            const originalContent = btn.innerHTML;
            
            btn.innerHTML = '<div class="loading"></div> Generating...';
            btn.style.pointerEvents = 'none';
            
            // Reset after 3 seconds
            setTimeout(() => {
                btn.innerHTML = originalContent;
                btn.style.pointerEvents = 'auto';
            }, 3000);
        });

        // Auto-refresh notifications every 30 seconds
        setInterval(function() {
            if (!document.hidden) {
                fetch('sales_analytics.php?ajax=notifications')
                    .then(response => response.json())
                    .then(data => {
                        if (data.unreadCount !== undefined) {
                            const badge = document.querySelector('.notification-badge');
                            const bellButton = document.querySelector('.notification-bell button');
                            
                            if (data.unreadCount > 0) {
                                if (!badge) {
                                    const newBadge = document.createElement('span');
                                    newBadge.className = 'notification-badge';
                                    newBadge.textContent = data.unreadCount;
                                    bellButton.appendChild(newBadge);
                                } else {
                                    badge.textContent = data.unreadCount;
                                }
                            } else if (badge) {
                                badge.remove();
                            }
                        }
                    })
                    .catch(error => console.log('Notification refresh failed:', error));
            }
        }, 30000);

        // Add smooth scrolling to tables
        document.querySelectorAll('.table-container').forEach(container => {
            container.addEventListener('scroll', function() {
                const scrollTop = this.scrollTop;
                const thead = this.querySelector('thead');
                if (thead) {
                    thead.style.transform = `translateY(${scrollTop}px)`;
                }
            });
        });

        // Initialize tooltips for status badges
        document.querySelectorAll('.status-badge').forEach(badge => {
            badge.addEventListener('mouseenter', function() {
                const status = this.textContent.trim().toLowerCase();
                let tooltip = document.createElement('div');
                tooltip.className = 'tooltip';
                tooltip.style.cssText = `
                    position: absolute;
                    background: rgba(0, 0, 0, 0.8);
                    color: white;
                    padding: 8px 12px;
                    border-radius: 6px;
                    font-size: 12px;
                    z-index: 1000;
                    pointer-events: none;
                    white-space: nowrap;
                `;
                
                const tooltipTexts = {
                    'pending': 'Order is waiting for approval',
                    'approved': 'Order has been approved and is being prepared',
                    'preparing': 'Order is currently being prepared',
                    'out for delivery': 'Order is on its way to customer',
                    'delivered': 'Order has been successfully delivered',
                    'rejected': 'Order was rejected',
                    'canceled': 'Order was canceled'
                };
                
                tooltip.textContent = tooltipTexts[status] || 'Order status information';
                
                document.body.appendChild(tooltip);
                
                const rect = this.getBoundingClientRect();
                tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
                tooltip.style.top = rect.top - tooltip.offsetHeight - 8 + 'px';
                
                this.tooltip = tooltip;
            });
            
            badge.addEventListener('mouseleave', function() {
                if (this.tooltip) {
                    this.tooltip.remove();
                    this.tooltip = null;
                }
            });
        });

        // Add number formatting animation for stat cards
        document.querySelectorAll('.stat-value').forEach(element => {
            const finalValue = element.textContent;
            const isPrice = finalValue.includes('₱');
            const numericValue = parseFloat(finalValue.replace(/[₱,]/g, ''));
            
            if (!isNaN(numericValue)) {
                let currentValue = 0;
                const increment = numericValue / 50;
                const timer = setInterval(() => {
                    currentValue += increment;
                    if (currentValue >= numericValue) {
                        currentValue = numericValue;
                        clearInterval(timer);
                    }
                    
                    if (isPrice) {
                        element.textContent = '₱' + currentValue.toLocaleString('en-US', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        });
                    } else {
                        element.textContent = Math.floor(currentValue).toLocaleString();
                    }
                }, 20);
            }
        });
    </script>
</body>
</html>