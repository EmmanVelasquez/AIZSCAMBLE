<?php
session_start();
include('../includes/db.php');
include('../includes/log_activity.php');
require_once('../includes/notify_helper.php');

// Create or update ingredient_movements table if it doesn't match our requirements
$alter_movements_table = "
CREATE TABLE IF NOT EXISTS ingredient_movements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ingredient_id INT NOT NULL,
    movement_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    quantity_before DECIMAL(10,2) DEFAULT 0,
    sales_quantity DECIMAL(10,2) DEFAULT 0,
    current_stock DECIMAL(10,2) NOT NULL,
    restock_quantity DECIMAL(10,2) DEFAULT 0,
    notes TEXT,
    created_by INT,
    FOREIGN KEY (ingredient_id) REFERENCES ingredients(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id)
)";
$conn->query($alter_movements_table);

if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../user/login.php");
    exit;
}

// Get unread notification count for the bell icon
$unreadCount = $conn->query("SELECT COUNT(*) as total FROM AdminNotifications WHERE IsRead = 0")->fetch_assoc()['total'];

// Fetch notifications for the dropdown
$notifQuery = $conn->query("SELECT * FROM AdminNotifications ORDER BY CreatedAt DESC LIMIT 5");

// Function to calculate current quantity on hand for an ingredient
function calculateQuantityOnHand($conn, $ingredient_id) {
    $stmt = $conn->prepare("
        SELECT 
            COALESCE(SUM(restock_quantity), 0) as total_stock_in,
            COALESCE(SUM(sales_quantity), 0) as total_stock_out
        FROM ingredient_movements 
        WHERE ingredient_id = ?
    ");
    $stmt->bind_param("i", $ingredient_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    
    $total_stock_in = floatval($row['total_stock_in']);
    $total_stock_out = floatval($row['total_stock_out']);
    $quantity_on_hand = $total_stock_in - $total_stock_out;
    
    return max(0, $quantity_on_hand); // Ensure QOH is never negative
}

// Function to update ingredient quantity in database (for consistency)
function updateIngredientQuantity($conn, $ingredient_id) {
    $quantity_on_hand = calculateQuantityOnHand($conn, $ingredient_id);
    
    $stmt = $conn->prepare("UPDATE ingredients SET quantity = ? WHERE id = ?");
    $stmt->bind_param("di", $quantity_on_hand, $ingredient_id);
    $stmt->execute();
    $stmt->close();
    
    return $quantity_on_hand;
}

// Function to parse stock value if it's stored as combined string
function parseStockValue($stockValue) {
    if (is_numeric($stockValue)) {
        return ['quantity' => floatval($stockValue), 'unit' => ''];
    }
    
    if (preg_match('/([\d.]+)\s*(\w+)/', $stockValue, $matches)) {
        return [
            'quantity' => floatval($matches[1]),
            'unit' => $matches[2]
        ];
    }
    
    return ['quantity' => 0, 'unit' => ''];
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') { 
    if (isset($_POST['add_ingredient'])) {
        $name = trim($_POST['name']);
        $unit = trim($_POST['unit']);
        $initial_quantity = floatval($_POST['quantity']);
        
        // Validate ingredient name is not empty
        if (empty($name)) {
            $_SESSION['error'] = "Ingredient name cannot be empty.";
            header("Location: ingredients.php");
            exit;
        }
        
        // Validate unit is selected
        if (empty($unit)) {
            $_SESSION['error'] = "Please select a unit of measurement.";
            header("Location: ingredients.php");
            exit;
        }
        
        // Validate quantity is not negative
        if ($initial_quantity < 0) {
            $_SESSION['error'] = "Initial quantity cannot be negative.";
            header("Location: ingredients.php");
            exit;
        }
        
        // Check if ingredient with same name already exists
        $check = $conn->prepare("SELECT COUNT(*) FROM ingredients WHERE LOWER(name) = LOWER(?)");
        $check->bind_param("s", $name);
        $check->execute();
        $check->bind_result($count);
        $check->fetch();
        $check->close();
        
        if ($count > 0) {
            $_SESSION['error'] = "An ingredient with the name '$name' already exists. Please use a different name or update the existing ingredient.";
            header("Location: ingredients.php");
            exit;
        }
        
        // Check if quantity is unreasonably large (prevent typos)
        if ($initial_quantity > 10000) {
            $_SESSION['warning'] = "You're adding a very large quantity ($initial_quantity). Please confirm this is correct.";
            $_SESSION['confirm_data'] = [
                'action' => 'add',
                'name' => $name,
                'unit' => $unit,
                'quantity' => $initial_quantity
            ];
            header("Location: ingredients.php");
            exit;
        }

        // All validations passed, insert the ingredient with initial quantity 0 (will be updated by movement)
        $stmt = $conn->prepare("INSERT INTO ingredients (name, unit, quantity) VALUES (?, ?, 0)");
        $stmt->bind_param("ss", $name, $unit);

        if ($stmt->execute()) {
            $ingredient_id = $conn->insert_id;
            
            // Record the initial quantity as a stock in movement
            $quantity_before = 0; // No previous stock
            $sales_quantity = 0; // No sales for initial stock
            $restock_quantity = $initial_quantity; // Initial quantity is stock in
            $current_stock = $initial_quantity; // Current stock after initial addition
            $notes = "Initial stock when ingredient was added";
            $user_id = $_SESSION['user_id'];
            
            $movement_stmt = $conn->prepare("INSERT INTO ingredient_movements (ingredient_id, quantity_before, sales_quantity, current_stock, restock_quantity, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $movement_stmt->bind_param("idddsis", $ingredient_id, $quantity_before, $sales_quantity, $current_stock, $restock_quantity, $notes, $user_id);
            $movement_stmt->execute();
            
            // Update the ingredient quantity based on movements
            $final_qoh = updateIngredientQuantity($conn, $ingredient_id);
            
            logActivity($conn, $_SESSION['user_id'], 'admin', "Added ingredient: $name ($initial_quantity $unit) - QOH: $final_qoh $unit");
            $_SESSION['message'] = "Ingredient added successfully! Current QOH: $final_qoh $unit";
        } else {
            $_SESSION['error'] = "Failed to add ingredient: " . $conn->error;
        }
        
        header("Location: ingredients.php");
        exit;

    } elseif (isset($_POST['update_ingredient'])) {
        $id = intval($_POST['id']);
        $name = trim($_POST['name']);
        $unit = trim($_POST['unit']);
        $quantity_adjustment = floatval($_POST['quantity_adjustment']);
        $adjustment_notes = trim($_POST['adjustment_notes']);
        
        // Validate ingredient name is not empty
        if (empty($name)) {
            $_SESSION['error'] = "Ingredient name cannot be empty.";
            header("Location: ingredients.php");
            exit;
        }
        
        // Validate unit is selected
        if (empty($unit)) {
            $_SESSION['error'] = "Please select a unit of measurement.";
            header("Location: ingredients.php");
            exit;
        }
        
        // Check if ingredient with same name already exists (excluding current ingredient)
        $check = $conn->prepare("SELECT COUNT(*) FROM ingredients WHERE LOWER(name) = LOWER(?) AND id != ?");
        $check->bind_param("si", $name, $id);
        $check->execute();
        $check->bind_result($count);
        $check->fetch();
        $check->close();
        
        if ($count > 0) {
            $_SESSION['error'] = "Another ingredient with the name '$name' already exists. Please use a different name.";
            header("Location: ingredients.php");
            exit;
        }
        
        // Get current ingredient info
        $stmt = $conn->prepare("SELECT name, unit FROM ingredients WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->bind_result($old_name, $old_unit);
        $stmt->fetch();
        $stmt->close();
        
        // Validate the ingredient exists
        if ($old_name === null) {
            $_SESSION['error'] = "Ingredient not found. It may have been deleted.";
            header("Location: ingredients.php");
            exit;
        }
        
        // Calculate current QOH dynamically
        $current_qoh = calculateQuantityOnHand($conn, $id);
        
        // Validate quantity adjustment is not zero
        if ($quantity_adjustment == 0) {
            $_SESSION['error'] = "Quantity adjustment cannot be zero. Please enter a positive or negative value.";
            header("Location: ingredients.php");
            exit;
        }
        
        // Calculate new QOH after adjustment
        $new_qoh = $current_qoh + $quantity_adjustment;
        
        // Validate new QOH is not negative
        if ($new_qoh < 0) {
            $_SESSION['error'] = "Quantity cannot be negative. Current QOH: $current_qoh $old_unit. Maximum you can remove: $current_qoh $old_unit.";
            header("Location: ingredients.php");
            exit;
        }
        
        // Check if adjustment is unreasonably large (prevent typos)
        if (abs($quantity_adjustment) > 1000) {
            $_SESSION['warning'] = "You're making a very large adjustment (" . ($quantity_adjustment > 0 ? "+" : "") . "$quantity_adjustment $unit). Please confirm this is correct.";
            $_SESSION['confirm_data'] = [
                'action' => 'update',
                'id' => $id,
                'name' => $name,
                'unit' => $unit,
                'quantity_adjustment' => $quantity_adjustment,
                'adjustment_notes' => $adjustment_notes
            ];
            header("Location: ingredients.php");
            exit;
        }
        
        // Check if unit is being changed and warn the user
        if ($unit !== $old_unit) {
            $_SESSION['warning'] = "You're changing the unit from '$old_unit' to '$unit'. This could affect recipes. Please confirm this is correct.";
            $_SESSION['confirm_data'] = [
                'action' => 'update',
                'id' => $id,
                'name' => $name,
                'unit' => $unit,
                'quantity_adjustment' => $quantity_adjustment,
                'adjustment_notes' => $adjustment_notes
            ];
            header("Location: ingredients.php");
            exit;
        }
        
        // All validations passed, update the ingredient name and unit
        $stmt = $conn->prepare("UPDATE ingredients SET name=?, unit=? WHERE id=?");
        $stmt->bind_param("ssi", $name, $unit, $id);

        if ($stmt->execute()) {
            // Record the quantity adjustment as a movement
            $quantity_before = $current_qoh; // QOH before adjustment
            $sales_quantity = $quantity_adjustment < 0 ? abs($quantity_adjustment) : 0; // Stock Out
            $restock_quantity = $quantity_adjustment > 0 ? $quantity_adjustment : 0; // Stock In
            $current_stock = $new_qoh; // QOH after adjustment
            $notes = !empty($adjustment_notes) ? $adjustment_notes : "Manual stock adjustment";
            $user_id = $_SESSION['user_id'];
            
            $movement_stmt = $conn->prepare("INSERT INTO ingredient_movements (ingredient_id, quantity_before, sales_quantity, current_stock, restock_quantity, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $movement_stmt->bind_param("idddsis", $id, $quantity_before, $sales_quantity, $current_stock, $restock_quantity, $notes, $user_id);
            $movement_stmt->execute();
            
            // Update the ingredient quantity based on movements
            $final_qoh = updateIngredientQuantity($conn, $id);
            
            $adjustment_type = $quantity_adjustment >= 0 ? "Stock In" : "Stock Out";
            $adjustment_amount = abs($quantity_adjustment);
            
            logActivity(
                $conn,
                $_SESSION['user_id'],
                'admin',
                "$adjustment_type: $adjustment_amount $unit for ingredient '$name'. QOH: $current_qoh → $final_qoh $unit"
            );
            
            $_SESSION['message'] = "Ingredient updated successfully! QOH: $current_qoh → $final_qoh $unit";
        } else {
            $_SESSION['error'] = "Failed to update ingredient: " . $conn->error;
        }
        
        header("Location: ingredients.php");
        exit;

    } elseif (isset($_POST['delete_ingredient'])) {
        $id = intval($_POST['id']);

        // Validate the ingredient exists
        $check_exists = $conn->prepare("SELECT COUNT(*) FROM ingredients WHERE id = ?");
        $check_exists->bind_param("i", $id);
        $check_exists->execute();
        $check_exists->bind_result($exists);
        $check_exists->fetch();
        $check_exists->close();
        
        if ($exists == 0) {
            $_SESSION['error'] = "Ingredient not found. It may have been already deleted.";
            header("Location: ingredients.php");
            exit;
        }

        // Check if ingredient is used in any products
        $check = $conn->prepare("SELECT COUNT(*) FROM product_ingredients WHERE ingredient_id=?");
        $check->bind_param("i", $id);
        $check->execute();
        $check->bind_result($count);
        $check->fetch();
        $check->close();

        if ($count > 0) {
            // Get product names that use this ingredient
            $products_stmt = $conn->prepare("
                SELECT p.name 
                FROM products p 
                JOIN product_ingredients pi ON p.id = pi.product_id 
                WHERE pi.ingredient_id = ? 
                LIMIT 5
            ");
            $products_stmt->bind_param("i", $id);
            $products_stmt->execute();
            $products_result = $products_stmt->get_result();
            
            $product_names = [];
            while ($row = $products_result->fetch_assoc()) {
                $product_names[] = $row['name'];
            }
            $products_stmt->close();
            
            $product_list = implode(", ", $product_names);
            if (count($product_names) < $count) {
                $product_list .= ", and " . ($count - count($product_names)) . " more";
            }
            
            $_SESSION['error'] = "Cannot delete ingredient - it's used in $count product(s): $product_list";
        } else {
            $stmt = $conn->prepare("SELECT name, unit FROM ingredients WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->bind_result($del_name, $del_unit);
            $stmt->fetch();
            $stmt->close();
            
            $del_qoh = calculateQuantityOnHand($conn, $id);

            $stmt = $conn->prepare("DELETE FROM ingredients WHERE id=?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                logActivity($conn, $_SESSION['user_id'], 'admin', "Deleted ingredient: $del_name (QOH: $del_qoh $del_unit)");
                $_SESSION['message'] = "Ingredient deleted successfully!";
            } else {
                $_SESSION['error'] = "Failed to delete ingredient: " . $conn->error;
            }
        }

        header("Location: ingredients.php");
        exit;
    } elseif (isset($_POST['confirm_action'])) {
        // Handle confirmed actions (for large quantities or unit changes)
        if (isset($_SESSION['confirm_data'])) {
            $data = $_SESSION['confirm_data'];
            
            if ($data['action'] == 'add') {
                $name = $data['name'];
                $unit = $data['unit'];
                $initial_quantity = $data['quantity'];
                
                $stmt = $conn->prepare("INSERT INTO ingredients (name, unit, quantity) VALUES (?, ?, 0)");
                $stmt->bind_param("ss", $name, $unit);
                
                if ($stmt->execute()) {
                    $ingredient_id = $conn->insert_id;
                    
                    // Record the initial quantity as a stock in movement
                    $quantity_before = 0;
                    $sales_quantity = 0;
                    $restock_quantity = $initial_quantity;
                    $current_stock = $initial_quantity;
                    $notes = "Initial stock when ingredient was added";
                    $user_id = $_SESSION['user_id'];
                    
                    $movement_stmt = $conn->prepare("INSERT INTO ingredient_movements (ingredient_id, quantity_before, sales_quantity, current_stock, restock_quantity, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $movement_stmt->bind_param("idddsis", $ingredient_id, $quantity_before, $sales_quantity, $current_stock, $restock_quantity, $notes, $user_id);
                    $movement_stmt->execute();
                    
                    $final_qoh = updateIngredientQuantity($conn, $ingredient_id);
                    
                    logActivity($conn, $_SESSION['user_id'], 'admin', "Added ingredient: $name ($initial_quantity $unit) - QOH: $final_qoh $unit");
                    $_SESSION['message'] = "Ingredient added successfully! Current QOH: $final_qoh $unit";
                } else {
                    $_SESSION['error'] = "Failed to add ingredient: " . $conn->error;
                }
            } elseif ($data['action'] == 'update') {
                $id = $data['id'];
                $name = $data['name'];
                $unit = $data['unit'];
                $quantity_adjustment = $data['quantity_adjustment'];
                $adjustment_notes = isset($data['adjustment_notes']) ? $data['adjustment_notes'] : '';
                
                // Get current QOH
                $current_qoh = calculateQuantityOnHand($conn, $id);
                $new_qoh = $current_qoh + $quantity_adjustment;
                
                $stmt = $conn->prepare("UPDATE ingredients SET name=?, unit=? WHERE id=?");
                $stmt->bind_param("ssi", $name, $unit, $id);
                
                if ($stmt->execute()) {
                    // Record the quantity adjustment as a movement
                    $quantity_before = $current_qoh;
                    $sales_quantity = $quantity_adjustment < 0 ? abs($quantity_adjustment) : 0;
                    $restock_quantity = $quantity_adjustment > 0 ? $quantity_adjustment : 0;
                    $current_stock = $new_qoh;
                    $notes = !empty($adjustment_notes) ? $data['adjustment_notes'] : "Manual stock adjustment";
                    $user_id = $_SESSION['user_id'];
                    
                    $movement_stmt = $conn->prepare("INSERT INTO ingredient_movements (ingredient_id, quantity_before, sales_quantity, current_stock, restock_quantity, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $movement_stmt->bind_param("idddsis", $id, $quantity_before, $sales_quantity, $current_stock, $restock_quantity, $notes, $user_id);
                    $movement_stmt->execute();
                    
                    $final_qoh = updateIngredientQuantity($conn, $id);
                    
                    $adjustment_type = $quantity_adjustment >= 0 ? "Stock In" : "Stock Out";
                    $adjustment_amount = abs($quantity_adjustment);
                    
                    logActivity(
                        $conn,
                        $_SESSION['user_id'],
                        'admin',
                        "$adjustment_type: $adjustment_amount $unit for ingredient '$name'. QOH: $current_qoh → $final_qoh $unit"
                    );
                    
                    $_SESSION['message'] = "Ingredient updated successfully! QOH: $current_qoh → $final_qoh $unit";
                } else {
                    $_SESSION['error'] = "Failed to update ingredient: " . $conn->error;
                }
            }
            
            unset($_SESSION['confirm_data']);
        }
        
        header("Location: ingredients.php");
        exit;
    } elseif (isset($_POST['cancel_action'])) {
        // User canceled the confirmation
        unset($_SESSION['confirm_data']);
        $_SESSION['message'] = "Action canceled.";
        header("Location: ingredients.php");
        exit;
    }
}

// Fetch all ingredients with dynamically calculated QOH
$ingredients = [];
$result = $conn->query("
    SELECT 
        i.id,
        i.name,
        i.unit,
        COALESCE(SUM(im.restock_quantity), 0) as total_stock_in,
        COALESCE(SUM(im.sales_quantity), 0) as total_stock_out,
        GREATEST(0, COALESCE(SUM(im.restock_quantity), 0) - COALESCE(SUM(im.sales_quantity), 0)) as quantity_on_hand
    FROM ingredients i
    LEFT JOIN ingredient_movements im ON i.id = im.ingredient_id
    GROUP BY i.id, i.name, i.unit
    ORDER BY i.name
");

if ($result) {
    $ingredients = $result->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ingredient Management - AIZCAmble</title>
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --error-color: #EF4444;
            --info-color: #3B82F6;
            --shadow-pink: rgba(236, 72, 153, 0.2);
            --shadow-strong: rgba(0, 0, 0, 0.1);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-gradient-start) 0%, var(--background-gradient-end) 100%);
            min-height: 100vh;
            display: flex;
            color: var(--text-primary);
            position: relative;
            overflow-x: hidden;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, var(--primary-pink) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, var(--accent-purple) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, var(--secondary-pink) 0%, transparent 50%);
            opacity: 0.05;
            z-index: -1;
            animation: backgroundFloat 20s ease-in-out infinite;
        }

        @keyframes backgroundFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(-20px, -20px) scale(1.05); }
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary-pink) 0%, var(--primary-pink-dark) 100%);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--border-light);
            box-shadow: 4px 0 20px var(--shadow-pink);
            padding: 0;
            min-height: 100vh;
            position: relative;
            overflow: hidden;
        }

        .sidebar::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.1) 50%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
        }

        @keyframes shimmer {
            0%, 100% { transform: translateX(-100%); }
            50% { transform: translateX(100%); }
        }

        .logo-section {
            text-align: center;
            padding: 32px 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            position: relative;
            z-index: 2;
        }

        .logo-container {
            position: relative;
            display: inline-block;
            margin-bottom: 16px;
        }

        .logo-container::before {
            content: '';
            position: absolute;
            top: -8px;
            left: -8px;
            right: -8px;
            bottom: -8px;
            background: linear-gradient(45deg, rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0.1));
            border-radius: 50%;
            animation: logoGlow 2s ease-in-out infinite;
        }

        @keyframes logoGlow {
            0%, 100% { transform: scale(1); opacity: 0.7; }
            50% { transform: scale(1.05); opacity: 1; }
        }

        .logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(255, 255, 255, 0.9);
            object-fit: cover;
            position: relative;
            z-index: 2;
            transition: all 0.3s ease;
        }

        .logo:hover {
            transform: scale(1.1) rotate(5deg);
        }

        .brand-name {
            color: white;
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 8px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .admin-title {
            color: rgba(255, 255, 255, 0.9);
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-menu {
            padding: 24px 0;
            position: relative;
            z-index: 2;
        }

        .nav-item {
            display: block;
            padding: 16px 24px;
            margin: 8px 16px;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            border-radius: 16px;
            font-weight: 500;
            font-size: 15px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
        }

        .nav-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .nav-item:hover::before {
            left: 100%;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(8px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item.active {
            background: rgba(255, 255, 255, 0.25);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        .main-content {
            flex: 1;
            padding: 32px;
            overflow-y: auto;
            position: relative;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            padding: 24px 32px;
            border-radius: 20px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            position: relative;
            overflow: hidden;
        }

        .header-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .page-title {
            font-size: 32px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* Notification Bell */
        .notification-bell {
            position: relative;
            display: inline-block;
        }

        .notification-bell button {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border: none;
            border-radius: 50%;
            width: 48px;
            height: 48px;
            color: white;
            font-size: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        .notification-bell button:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 20px var(--shadow-pink);
        }

        .notification-badge {
            position: absolute;
            top: -6px;
            right: -6px;
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
            border-radius: 50%;
            padding: 4px 8px;
            font-size: 12px;
            font-weight: 700;
            min-width: 20px;
            text-align: center;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }

        .notification-dropdown {
            display: none;
            position: absolute;
            right: 0;
            top: 60px;
            background: white;
            width: 350px;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            max-height: 400px;
            overflow: hidden;
            border: 1px solid var(--border-light);
        }

        .notification-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 20px;
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            font-weight: 600;
        }

        .notification-header a {
            color: white;
            font-size: 12px;
            text-decoration: none;
            opacity: 0.9;
            transition: opacity 0.2s;
        }

        .notification-header a:hover {
            opacity: 1;
        }

        .notification-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            max-height: 300px;
            overflow-y: auto;
        }

        .notification-dropdown li {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border-light);
            transition: background-color 0.2s;
        }

        .notification-dropdown li:last-child {
            border-bottom: none;
        }

        .notification-dropdown li:hover {
            background-color: rgba(236, 72, 153, 0.05);
        }

        .notification-footer {
            padding: 16px 20px;
            text-align: center;
            border-top: 1px solid var(--border-light);
            background: rgba(236, 72, 153, 0.05);
        }

        .notification-footer a {
            color: var(--primary-pink);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.2s;
        }

        .notification-footer a:hover {
            color: var(--primary-pink-dark);
        }

        /* Alert Messages */
        .message {
            padding: 16px 20px;
            margin-bottom: 24px;
            border-radius: 12px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .success {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(5, 150, 105, 0.1));
            color: var(--success-color);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .error {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(220, 38, 38, 0.1));
            color: var(--error-color);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .warning {
            background: linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(217, 119, 6, 0.1));
            color: var(--warning-color);
            border: 1px solid rgba(245, 158, 11, 0.2);
            border-left: 4px solid var(--warning-color);
        }

        /* Form Container */
        .form-container {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 32px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            margin-bottom: 32px;
            position: relative;
            overflow: hidden;
        }

        .form-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        .form-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .form-title i {
            color: var(--primary-pink);
            font-size: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--text-primary);
            font-size: 14px;
        }

        input[type="text"],
        input[type="number"],
        select,
        textarea {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--border-light);
            border-radius: 12px;
            font-size: 14px;
            font-weight: 500;
            background: white;
            transition: all 0.3s ease;
            outline: none;
        }

        input[type="text"]:focus,
        input[type="number"]:focus,
        select:focus,
        textarea:focus {
            border-color: var(--primary-pink);
            box-shadow: 0 0 0 4px rgba(236, 72, 153, 0.1);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            border: none;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
        }

        .btn-success {
            background: linear-gradient(135deg, var(--success-color), #059669);
            color: white;
        }

        .btn-warning {
            background: linear-gradient(135deg, var(--warning-color), #D97706);
            color: white;
        }

        .btn-danger {
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
        }

        .btn-secondary {
            background: var(--text-light);
            color: white;
        }

        /* Ingredients Table Container */
        .ingredients-container {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            overflow: hidden;
            position: relative;
            margin-bottom: 32px;
        }

        .ingredients-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        .ingredients-header {
            padding: 24px 32px;
            border-bottom: 1px solid var(--border-light);
        }

        .ingredients-title {
            font-size: 20px;
            font-weight: 700;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .table-container {
            max-height: 600px;
            overflow-y: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            padding: 16px 20px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        td {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border-light);
            font-size: 14px;
            font-weight: 500;
        }

        tr:hover {
            background: rgba(236, 72, 153, 0.02);
        }

        tr:last-child td {
            border-bottom: none;
        }

        /* Stock Status Badges */
        .quantity-highlight {
            display: inline-flex;
            align-items: center;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .quantity-highlight {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success-color);
        }

        .quantity-highlight.low-stock {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning-color);
        }

        .quantity-highlight.out-of-stock {
            background: rgba(239, 68, 68, 0.1);
            color: var(--error-color);
        }

        .stock-summary {
            display: flex;
            gap: 12px;
            font-size: 12px;
            margin-top: 4px;
        }

        .stock-in {
            color: var(--success-color);
            font-weight: 600;
        }

        .stock-out {
            color: var(--error-color);
            font-weight: 600;
        }

        /* Action Buttons */
        .action-btn {
            padding: 8px 16px;
            margin: 0 4px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .edit-btn {
            background: linear-gradient(135deg, var(--info-color), #2563EB);
            color: white;
        }

        .delete-btn {
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
        }

        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        /* Movement History Section */
        .movement-history-container {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            overflow: hidden;
            position: relative;
        }

        .movement-history-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        .movement-header {
            padding: 24px 32px;
            border-bottom: 1px solid var(--border-light);
        }

        .movement-title {
            font-size: 20px;
            font-weight: 700;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* Filter Section */
        .filter-section {
            padding: 24px 32px;
            background: rgba(236, 72, 153, 0.05);
            border-bottom: 1px solid var(--border-light);
        }

        .filter-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .filter-label {
            font-weight: 600;
            color: var(--text-primary);
            font-size: 14px;
        }

        .filter-input {
            padding: 10px 14px;
            border: 2px solid var(--border-light);
            border-radius: 10px;
            font-size: 14px;
            background: white;
            transition: all 0.3s ease;
        }

        .filter-input:focus {
            border-color: var(--primary-pink);
            box-shadow: 0 0 0 4px rgba(236, 72, 153, 0.1);
        }

        .filter-actions {
            display: flex;
            gap: 12px;
        }

        /* Movement Table */
        .stock-movement-table {
            width: 100%;
            border-collapse: collapse;
        }

        .stock-movement-table th {
            background: linear-gradient(135deg, var(--accent-purple), var(--accent-purple-light));
            color: white;
            padding: 16px 20px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .stock-movement-table td {
            padding: 12px 20px;
            border-bottom: 1px solid var(--border-light);
            font-size: 14px;
        }

        .stock-movement-table tr:nth-child(even) {
            background: rgba(236, 72, 153, 0.02);
        }

        .stock-movement-table tr:hover {
            background: rgba(236, 72, 153, 0.05);
        }

        .in-quantity {
            color: var(--success-color);
            font-weight: 700;
        }

        .out-quantity {
            color: var(--error-color);
            font-weight: 700;
        }

        .balance-quantity {
            font-weight: 700;
            color: var(--primary-pink);
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(5px);
        }

        .modal-content {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            margin: 5% auto;
            padding: 32px;
            border-radius: 20px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            border: 1px solid var(--border-light);
            position: relative;
            overflow: hidden;
        }

        .modal-content::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        .close {
            color: var(--text-light);
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .close:hover {
            color: var(--primary-pink);
        }

        .modal h3 {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .modal h3 i {
            color: var(--primary-pink);
        }

        /* Current Stock Display */
        .current-stock {
            background: linear-gradient(135deg, rgba(236, 72, 153, 0.1), rgba(139, 92, 246, 0.1));
            padding: 16px;
            border-radius: 12px;
            margin: 12px 0;
            font-weight: 700;
            color: var(--primary-pink);
            border: 1px solid var(--border-light);
        }

        .stock-adjustment {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .stock-adjustment input {
            flex: 1;
        }

        .stock-note {
            font-size: 12px;
            color: var(--text-secondary);
            margin-top: 8px;
            padding: 8px 12px;
            background: rgba(236, 72, 153, 0.05);
            border-radius: 8px;
            border-left: 3px solid var(--primary-pink);
        }

        /* Resulting Stock Container */
        .resulting-stock-container {
            margin-top: 20px;
            padding: 16px;
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(37, 99, 235, 0.1));
            border: 2px solid rgba(59, 130, 246, 0.2);
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.1);
            transition: all 0.3s ease;
        }

        .resulting-stock-label {
            font-weight: 700;
            color: var(--info-color);
            margin-bottom: 8px;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .resulting-stock-value {
            font-size: 20px;
            font-weight: 800;
        }

        .resulting-stock-positive {
            color: var(--success-color);
        }

        .resulting-stock-negative {
            color: var(--error-color);
            animation: pulse 1.5s infinite;
        }

        .resulting-stock-warning {
            color: var(--warning-color);
        }

        /* Confirmation Actions */
        .confirmation-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 24px;
            gap: 12px;
        }

        .btn-confirm {
            background: linear-gradient(135deg, var(--success-color), #059669);
            color: white;
        }

        .btn-cancel {
            background: var(--text-light);
            color: white;
        }

        /* Error States */
        .input-error {
            border-color: var(--error-color) !important;
            background-color: rgba(239, 68, 68, 0.05);
        }

        .error-message {
            color: var(--error-color);
            font-size: 12px;
            margin-top: 4px;
            display: none;
            font-weight: 500;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-light);
        }

        .empty-state i {
            font-size: 64px;
            margin-bottom: 20px;
            color: var(--primary-pink);
            opacity: 0.5;
        }

        .empty-state h3 {
            font-size: 20px;
            margin-bottom: 12px;
            color: var(--text-secondary);
        }

        .empty-state p {
            font-size: 16px;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .sidebar {
                width: 240px;
            }
        }

        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                min-height: auto;
                position: fixed;
                top: 0;
                left: -100%;
                z-index: 1000;
                transition: left 0.3s ease;
            }
            
            .sidebar.open {
                left: 0;
            }
            
            .main-content {
                padding: 20px;
                margin-top: 0;
            }
            
            .header-section {
                flex-direction: column;
                gap: 16px;
                text-align: center;
            }
            
            .page-title {
                font-size: 24px;
            }
            
            .filter-container {
                grid-template-columns: 1fr;
            }
            
            .filter-actions {
                justify-content: center;
            }
            
            .table-container {
                overflow-x: auto;
            }
            
            table {
                min-width: 800px;
            }
            
            .modal-content {
                width: 95%;
                margin: 10% auto;
                padding: 20px;
            }
            
            .notification-dropdown {
                width: 300px;
                right: -50px;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(236, 72, 153, 0.1);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--primary-pink-dark), var(--primary-pink));
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <div class="logo-container">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo" class="logo">
            </div>
            <div class="brand-name">AIZCAmble</div>
            <div class="admin-title">Admin Panel</div>
        </div>

        <nav class="nav-menu">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                Dashboard
            </a>
            <a href="orders.php" class="nav-item">
                <i class="fas fa-shopping-bag"></i>
                Manage Orders
            </a>
            <a href="add_product.php" class="nav-item">
                <i class="fas fa-plus-circle"></i>
                Add Product
            </a>
            <a href="stock.php" class="nav-item">
                <i class="fas fa-boxes"></i>
                Stock Management
            </a>
            <a href="sales_analytics.php" class="nav-item">
                <i class="fas fa-chart-bar"></i>
                Sales Analytics
            </a>
            <a href="users.php" class="nav-item">
                <i class="fas fa-users"></i>
                Customers
            </a>
            <a href="ingredients.php" class="nav-item active">
                <i class="fas fa-flask"></i>
                Ingredients
            </a>
            <a href="admins.php" class="nav-item">
                <i class="fas fa-user-shield"></i>
                Admins
            </a>
            <a href="shutdown.php" class="nav-item">
                <i class="fas fa-power-off"></i>
                Shutdown Shop
            </a>
            <a href="activity_log.php" class="nav-item">
                <i class="fas fa-history"></i>
                Activity History
            </a>
            <a href="notifications.php" class="nav-item">
                <i class="fas fa-bell"></i>
                Notifications
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header-section">
            <h1 class="page-title">
                <i class="fas fa-flask"></i>
                Ingredient Management
            </h1>
            
            <!-- Notification Bell -->
            <div class="notification-bell">
                <button onclick="toggleDropdown()">
                    <i class="fas fa-bell"></i>
                    <?php if ($unreadCount > 0): ?>
                        <span class="notification-badge">
                            <?= $unreadCount ?>
                        </span>
                    <?php endif; ?>
                </button>
                <div id="notifDropdown" class="notification-dropdown">
                    <div class="notification-header">
                        <span>Notifications</span>
                        <?php if ($unreadCount > 0): ?>
                            <a href="ingredients.php?mark_read=all">Mark all as read</a>
                        <?php endif; ?>
                    </div>
                    <ul>
                        <?php if ($notifQuery->num_rows > 0): ?>
                            <?php while ($notif = $notifQuery->fetch_assoc()): ?>
                                <li style="<?= $notif['IsRead'] ? '' : 'background-color: rgba(236, 72, 153, 0.05);' ?>">
                                    <strong><?= htmlspecialchars($notif['Title']) ?></strong><br>
                                    <small><?= htmlspecialchars($notif['message']) ?></small><br>
                                    <small style="color: #888;"><?= date('M d, Y h:i A', strtotime($notif['CreatedAt'])) ?></small>
                                </li>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <li>No notifications yet</li>
                        <?php endif; ?>
                    </ul>
                    <div class="notification-footer">
                        <a href="notifications.php">View All Notifications</a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Alert Messages -->
        <?php if (isset($_SESSION['message'])): ?>
            <div class="message success">
                <i class="fas fa-check-circle"></i>
                <?= htmlspecialchars($_SESSION['message']) ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="message error">
                <i class="fas fa-exclamation-circle"></i>
                <?= htmlspecialchars($_SESSION['error']) ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['warning']) && isset($_SESSION['confirm_data'])): ?>
            <div class="message warning">
                <p><strong><i class="fas fa-exclamation-triangle"></i> Warning:</strong> <?= htmlspecialchars($_SESSION['warning']) ?></p>
                <form method="POST" class="confirmation-actions">
                    <button type="submit" name="confirm_action" class="btn btn-confirm">
                        <i class="fas fa-check"></i>
                        Confirm
                    </button>
                    <button type="submit" name="cancel_action" class="btn btn-cancel">
                        <i class="fas fa-times"></i>
                        Cancel
                    </button>
                </form>
            </div>
            <?php unset($_SESSION['warning']); ?>
        <?php endif; ?>
        
        <!-- Add Ingredient Form -->
        <div class="form-container">
            <h3 class="form-title">
                <i class="fas fa-plus-circle"></i>
                Add New Ingredient
            </h3>
            <form method="POST" id="addIngredientForm">
                <div class="form-group">
                    <label for="ingredientName">
                        <i class="fas fa-tag"></i>
                        Ingredient Name:
                    </label>
                    <input type="text" id="ingredientName" name="name" required placeholder="Enter ingredient name">
                    <div id="nameError" class="error-message">Ingredient name is required</div>
                </div>
                
                <div class="form-group">
                    <label for="ingredientUnit">
                        <i class="fas fa-balance-scale"></i>
                        Unit of Measurement:
                    </label>
                    <select id="ingredientUnit" name="unit" required>
                        <option value="">Select Unit</option>
                        <option value="g">grams (g)</option>
                        <option value="kg">kilograms (kg)</option>
                        <option value="ml">milliliters (ml)</option>
                        <option value="L">liters (L)</option>
                        <option value="pcs">pieces (pcs)</option>
                        <option value="cups">cups</option>
                        <option value="tbsp">tablespoons (tbsp)</option>
                        <option value="tsp">teaspoons (tsp)</option>
                    </select>
                    <div id="unitError" class="error-message">Please select a unit of measurement</div>
                </div>
                
                <div class="form-group">
                    <label for="ingredientQuantity">
                        <i class="fas fa-plus"></i>
                        Initial Stock In Quantity:
                    </label>
                    <input type="number" id="ingredientQuantity" step="0.01" name="quantity" required min="0" placeholder="0.00">
                    <div id="quantityError" class="error-message">Quantity must be a positive number</div>
                    <p class="stock-note">
                        <i class="fas fa-info-circle"></i>
                        This will be recorded as the initial Stock In for this ingredient.
                    </p>
                </div>
                
                <button type="submit" name="add_ingredient" class="btn btn-primary">
                    <i class="fas fa-plus"></i>
                    Add Ingredient
                </button>
            </form>
        </div>
        
        <!-- Current Ingredients -->
        <div class="ingredients-container">
            <div class="ingredients-header">
                <h3 class="ingredients-title">
                    <i class="fas fa-list"></i>
                    Current Ingredients
                </h3>
            </div>
            
            <?php if (empty($ingredients)): ?>
                <div class="empty-state">
                    <i class="fas fa-flask"></i>
                    <h3>No Ingredients Found</h3>
                    <p>Add your first ingredient using the form above to get started.</p>
                </div>
            <?php else: ?>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th><i class="fas fa-tag"></i> Name</th>
                                <th><i class="fas fa-boxes"></i> Quantity On Hand (QOH)</th>
                                <th><i class="fas fa-balance-scale"></i> Unit</th>
                                <th><i class="fas fa-chart-line"></i> Stock Summary</th>
                                <th><i class="fas fa-cogs"></i> Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($ingredients as $ingredient): ?>
                                <?php
                                $qoh = floatval($ingredient['quantity_on_hand']);
                                $total_in = floatval($ingredient['total_stock_in']);
                                $total_out = floatval($ingredient['total_stock_out']);
                                $unit = htmlspecialchars($ingredient['unit']);
                                
                                // Determine QOH status class
                                $qoh_class = 'quantity-highlight';
                                if ($qoh == 0) {
                                    $qoh_class .= ' out-of-stock';
                                } elseif ($qoh < 10) {
                                    $qoh_class .= ' low-stock';
                                }
                                ?>
                                <tr>
                                    <td>
                                        <strong><?= htmlspecialchars($ingredient['name']) ?></strong>
                                    </td>
                                    <td>
                                        <span class="<?= $qoh_class ?>">
                                            <?= number_format($qoh, 2) ?>
                                        </span>
                                    </td>
                                    <td><?= $unit ?></td>
                                    <td>
                                        <div class="stock-summary">
                                            <span class="stock-in">
                                                <i class="fas fa-arrow-up"></i>
                                                In: <?= number_format($total_in, 2) ?>
                                            </span>
                                            <span class="stock-out">
                                                <i class="fas fa-arrow-down"></i>
                                                Out: <?= number_format($total_out, 2) ?>
                                            </span>
                                        </div>
                                    </td>
                                    <td>
                                        <button class="action-btn edit-btn" onclick="openEditModal(
                                            <?= $ingredient['id'] ?>, 
                                            '<?= htmlspecialchars(addslashes($ingredient['name'])) ?>',
                                            '<?= $unit ?>',
                                            <?= $qoh ?>
                                        )">
                                            <i class="fas fa-edit"></i>
                                            Update Stock
                                        </button>
                                        
                                        <button class="action-btn delete-btn" onclick="confirmDelete(<?= $ingredient['id'] ?>)">
                                            <i class="fas fa-trash"></i>
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Movement History Section -->
        <div class="movement-history-container">
            <div class="movement-header">
                <h3 class="movement-title">
                    <i class="fas fa-history"></i>
                    Stock Movement History
                </h3>
            </div>
            
            <div class="filter-section">
                <div class="filter-container">
                    <div class="filter-group">
                        <label class="filter-label" for="ingredient-filter">
                            <i class="fas fa-filter"></i>
                            Filter by Ingredient:
                        </label>
                        <select id="ingredient-filter" class="filter-input">
                            <option value="">All Ingredients</option>
                            <?php foreach ($ingredients as $ingredient): ?>
                                <option value="<?= $ingredient['id'] ?>"><?= htmlspecialchars($ingredient['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label class="filter-label" for="date-from">
                            <i class="fas fa-calendar-alt"></i>
                            From Date:
                        </label>
                        <input type="date" id="date-from" class="filter-input">
                    </div>
                    
                    <div class="filter-group">
                        <label class="filter-label" for="date-to">
                            <i class="fas fa-calendar-alt"></i>
                            To Date:
                        </label>
                        <input type="date" id="date-to" class="filter-input">
                    </div>
                </div>
                
                <div class="filter-actions">
                    <button id="apply-filters" class="btn btn-primary">
                        <i class="fas fa-search"></i>
                        Apply Filters
                    </button>
                    <button id="reset-filters" class="btn btn-secondary">
                        <i class="fas fa-undo"></i>
                        Reset Filters
                    </button>
                </div>
            </div>
            
            <div id="movement-history-container" style="max-height: 500px; overflow-y: auto; padding: 0 32px 32px;">
                <table class="stock-movement-table" id="movement-history-table">
                    <thead>
                        <tr>
                            <th><i class="fas fa-clock"></i> Date/Time</th>
                            <th><i class="fas fa-tag"></i> Ingredient Name</th>
                            <th><i class="fas fa-balance-scale"></i> Unit</th>
                            <th><i class="fas fa-arrow-down"></i> Sales</th>
                            <th><i class="fas fa-arrow-up"></i> Restock</th>
                            <th><i class="fas fa-boxes"></i> QOH</th>
                            <th><i class="fas fa-sticky-note"></i> Notes</th>
                        </tr>
                    </thead>
                    <tbody id="movement-history-body">
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 20px;">
                                <i class="fas fa-spinner fa-spin"></i>
                                Loading movement history...
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeEditModal()">&times;</span>
            <h3>
                <i class="fas fa-edit"></i>
                Update Ingredient Stock
            </h3>
            <form id="editForm" method="POST">
                <input type="hidden" name="id" id="editId">
                
                <div class="form-group">
                    <label for="editName">
                        <i class="fas fa-tag"></i>
                        Ingredient Name:
                    </label>
                    <input type="text" name="name" id="editName" required>
                    <div id="editNameError" class="error-message">Ingredient name is required</div>
                </div>
                
                <div class="form-group">
                    <label for="editUnit">
                        <i class="fas fa-balance-scale"></i>
                        Unit of Measurement:
                    </label>
                    <select name="unit" id="editUnit" required>
                        <option value="">Select Unit</option>
                        <option value="g">grams (g)</option>
                        <option value="kg">kilograms (kg)</option>
                        <option value="ml">milliliters (ml)</option>
                        <option value="L">liters (L)</option>
                        <option value="pcs">pieces (pcs)</option>
                        <option value="cups">cups</option>
                        <option value="tbsp">tablespoons (tbsp)</option>
                        <option value="tsp">teaspoons (tsp)</option>
                    </select>
                    <div id="editUnitError" class="error-message">Please select a unit of measurement</div>
                </div>
                
                <div class="form-group">
                    <label>
                        <i class="fas fa-boxes"></i>
                        Current Quantity On Hand (QOH):
                    </label>
                    <div class="current-stock" id="currentQuantityDisplay"></div>
                </div>
                
                <div class="form-group">
                    <label for="quantityAdjustment">
                        <i class="fas fa-exchange-alt"></i>
                        Stock Adjustment (+ for Stock In, - for Stock Out):
                    </label>
                    <div class="stock-adjustment">
                        <input type="number" step="0.01" name="quantity_adjustment" id="quantityAdjustment" required placeholder="e.g., +50 (Stock In) or -10 (Stock Out)">
                        <span id="unitDisplay"></span>
                    </div>
                    <div id="adjustmentError" class="error-message">Stock adjustment cannot be zero</div>
                    <p class="stock-note">
                        <strong><i class="fas fa-arrow-up"></i> Stock In (+):</strong> Receiving new inventory, restocking<br>
                        <strong><i class="fas fa-arrow-down"></i> Stock Out (-):</strong> Sales, usage, waste, transfers<br>
                        QOH will be automatically recalculated: QOH = Total Stock In - Total Stock Out
                    </p>
                </div>
                
                <div class="form-group">
                    <label for="adjustmentNotes">
                        <i class="fas fa-sticky-note"></i>
                        Notes:
                    </label>
                    <textarea id="adjustmentNotes" name="adjustment_notes" rows="3" placeholder="e.g., 'Received shipment' or 'Used for production'"></textarea>
                </div>
                
                <div class="resulting-stock-container" id="resultingQuantityContainer">
                    <div class="resulting-stock-label">
                        <i class="fas fa-calculator"></i>
                        New QOH After Adjustment:
                    </div>
                    <div class="resulting-stock-value">
                        <span id="newQuantityValue">0</span> <span id="newQuantityUnit"></span>
                    </div>
                </div>
                
                <button type="submit" name="update_ingredient" id="updateButton" class="btn btn-primary">
                    <i class="fas fa-save"></i>
                    Update Stock
                </button>
            </form>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeDeleteModal()">&times;</span>
            <h3>
                <i class="fas fa-exclamation-triangle"></i>
                Confirm Deletion
            </h3>
            <p>Are you sure you want to delete this ingredient?</p>
            <p class="stock-note">
                <i class="fas fa-warning"></i>
                Warning: This action cannot be undone. If this ingredient is used in any products, deletion will be prevented.
            </p>
            <form id="deleteForm" method="POST">
                <input type="hidden" name="id" id="deleteId">
                <div class="confirmation-actions">
                    <button type="submit" name="delete_ingredient" class="btn btn-danger">
                        <i class="fas fa-trash"></i>
                        Delete
                    </button>
                    <button type="button" onclick="closeDeleteModal()" class="btn btn-secondary">
                        <i class="fas fa-times"></i>
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Edit Ingredient Modal
        function openEditModal(id, name, unit, currentQoh) {
            document.getElementById('editId').value = id;
            document.getElementById('editName').value = name;
            document.getElementById('editUnit').value = unit;
            document.getElementById('currentQuantityDisplay').textContent = currentQoh + ' ' + unit;
            document.getElementById('unitDisplay').textContent = unit;
            document.getElementById('newQuantityUnit').textContent = unit;
            document.getElementById('quantityAdjustment').value = '';
            document.getElementById('adjustmentNotes').value = '';
            
            // Store current QOH for calculations
            document.getElementById('quantityAdjustment').dataset.currentQoh = currentQoh;
            document.getElementById('quantityAdjustment').dataset.originalUnit = unit;
            
            // Reset error messages
            hideAllErrors();
            
            document.getElementById('editModal').style.display = 'block';
            
            // Update the resulting quantity display when adjustment changes
            updateResultingQuantity();
        }

        function updateResultingQuantity() {
            const quantityAdjustmentElement = document.getElementById('quantityAdjustment');
            const currentQoh = parseFloat(quantityAdjustmentElement.dataset.currentQoh) || 0;
            const adjustment = parseFloat(quantityAdjustmentElement.value) || 0;
            const newQoh = currentQoh + adjustment;
            
            const newQuantityElement = document.getElementById('newQuantityValue');
            const resultingQuantityContainer = document.getElementById('resultingQuantityContainer');
            
            newQuantityElement.textContent = newQoh.toFixed(2);
            
            // Remove all classes first
            newQuantityElement.classList.remove('resulting-stock-positive', 'resulting-stock-negative', 'resulting-stock-warning');
            
            // Apply appropriate class based on the value
            if (newQoh < 0) {
                newQuantityElement.classList.add('resulting-stock-negative');
                resultingQuantityContainer.style.backgroundColor = 'rgba(239, 68, 68, 0.1)';
                resultingQuantityContainer.style.borderColor = 'rgba(239, 68, 68, 0.2)';
                document.getElementById('updateButton').disabled = true;
            } else if (newQoh == 0) {
                newQuantityElement.classList.add('resulting-stock-warning');
                resultingQuantityContainer.style.backgroundColor = 'rgba(245, 158, 11, 0.1)';
                resultingQuantityContainer.style.borderColor = 'rgba(245, 158, 11, 0.2)';
                document.getElementById('updateButton').disabled = false;
            } else if (newQoh < 10) { // Low stock warning
                newQuantityElement.classList.add('resulting-stock-warning');
                resultingQuantityContainer.style.backgroundColor = 'rgba(245, 158, 11, 0.1)';
                resultingQuantityContainer.style.borderColor = 'rgba(245, 158, 11, 0.2)';
                document.getElementById('updateButton').disabled = false;
            } else {
                newQuantityElement.classList.add('resulting-stock-positive');
                resultingQuantityContainer.style.backgroundColor = 'rgba(16, 185, 129, 0.1)';
                resultingQuantityContainer.style.borderColor = 'rgba(16, 185, 129, 0.2)';
                document.getElementById('updateButton').disabled = false;
            }
            
            // Highlight the container when value changes
            resultingQuantityContainer.style.transform = 'scale(1.03)';
            setTimeout(() => {
                resultingQuantityContainer.style.transform = 'scale(1)';
            }, 200);
            
            // Check if unit has changed
            const originalUnit = quantityAdjustmentElement.dataset.originalUnit;
            const currentUnit = document.getElementById('editUnit').value;
            
            if (originalUnit !== currentUnit && currentUnit !== '') {
                const unitWarning = document.createElement('div');
                unitWarning.className = 'stock-note';
                unitWarning.style.color = '#dc3545';
                unitWarning.style.fontWeight = 'bold';
                unitWarning.id = 'unitWarning';
                unitWarning.innerHTML = `<i class="fas fa-exclamation-triangle"></i> Warning: Changing unit from ${originalUnit} to ${currentUnit} may affect recipes!`;
                
                // Remove existing warning if any
                const existingWarning = document.getElementById('unitWarning');
                if (existingWarning) {
                    existingWarning.remove();
                }
                
                // Add the warning after the unit select
                document.getElementById('editUnit').parentNode.insertBefore(unitWarning, document.getElementById('editUnitError').nextSibling);
            } else {
                // Remove warning if unit is changed back to original
                const existingWarning = document.getElementById('unitWarning');
                if (existingWarning) {
                    existingWarning.remove();
                }
            }
        }

        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }

        // Delete Confirmation Modal
        function confirmDelete(id) {
            document.getElementById('deleteId').value = id;
            document.getElementById('deleteModal').style.display = 'block';
        }

        function closeDeleteModal() {
            document.getElementById('deleteModal').style.display = 'none';
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            if (event.target == document.getElementById('editModal')) {
                closeEditModal();
            }
            if (event.target == document.getElementById('deleteModal')) {
                closeDeleteModal();
            }
        }

        // Show error message and highlight input
        function showError(inputId, errorId, message) {
            const input = document.getElementById(inputId);
            const error = document.getElementById(errorId);
            
            input.classList.add('input-error');
            error.textContent = message;
            error.style.display = 'block';
            
            return false;
        }

        // Hide all error messages
        function hideAllErrors() {
            const errorMessages = document.querySelectorAll('.error-message');
            const errorInputs = document.querySelectorAll('.input-error');
            
            errorMessages.forEach(error => {
                error.style.display = 'none';
            });
            
            errorInputs.forEach(input => {
                input.classList.remove('input-error');
            });
        }

        // Notification dropdown toggle
        function toggleDropdown() {
            const dropdown = document.getElementById('notifDropdown');
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        }

        // Close dropdown when clicking outside
        window.addEventListener('click', function(event) {
            const dropdown = document.getElementById('notifDropdown');
            const bell = document.querySelector('.notification-bell button');
            if (!bell.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = 'none';
            }
        });

        // Add event listeners when DOM is loaded
        document.addEventListener('DOMContentLoaded', function() {
            // Quantity adjustment input handler
            const quantityAdjustment = document.getElementById('quantityAdjustment');
            if (quantityAdjustment) {
                quantityAdjustment.addEventListener('input', updateResultingQuantity);
            }
            
            // Unit change handler
            const editUnit = document.getElementById('editUnit');
            if (editUnit) {
                editUnit.addEventListener('change', updateResultingQuantity);
            }
            
            // Add form validation
            const addForm = document.getElementById('addIngredientForm');
            if (addForm) {
                addForm.addEventListener('submit', function(e) {
                    hideAllErrors();
                    let isValid = true;
                    
                    // Validate name
                    const name = document.getElementById('ingredientName').value.trim();
                    if (name === '') {
                        isValid = showError('ingredientName', 'nameError', 'Ingredient name is required');
                    }
                    
                    // Validate unit
                    const unit = document.getElementById('ingredientUnit').value;
                    if (unit === '') {
                        isValid = showError('ingredientUnit', 'unitError', 'Please select a unit of measurement');
                    }
                    
                    // Validate quantity
                    const quantity = parseFloat(document.getElementById('ingredientQuantity').value);
                    if (isNaN(quantity) || quantity < 0) {
                        isValid = showError('ingredientQuantity', 'quantityError', 'Quantity must be a positive number');
                    }
                    
                    if (!isValid) {
                        e.preventDefault();
                    }
                });
            }
            
            // Edit form validation
            const editForm = document.getElementById('editForm');
            if (editForm) {
                editForm.addEventListener('submit', function(e) {
                    hideAllErrors();
                    let isValid = true;
                    
                    // Validate name
                    const name = document.getElementById('editName').value.trim();
                    if (name === '') {
                        isValid = showError('editName', 'editNameError', 'Ingredient name is required');
                    }
                    
                    // Validate unit
                    const unit = document.getElementById('editUnit').value;
                    if (unit === '') {
                        isValid = showError('editUnit', 'editUnitError', 'Please select a unit of measurement');
                    }
                    
                    // Validate quantity adjustment
                    const quantityAdjustmentElement = document.getElementById('quantityAdjustment');
                    const adjustment = parseFloat(quantityAdjustmentElement.value);
                    if (isNaN(adjustment) || adjustment === 0) {
                        isValid = showError('quantityAdjustment', 'adjustmentError', 'Stock adjustment cannot be zero');
                    }
                    
                    // Validate resulting QOH is not negative
                    const currentQoh = parseFloat(quantityAdjustmentElement.dataset.currentQoh) || 0;
                    const newQoh = currentQoh + adjustment;
                    
                    if (newQoh < 0) {
                        isValid = showError('quantityAdjustment', 'adjustmentError', `Cannot remove more than current QOH (${currentQoh})`);
                    }
                    
                    if (!isValid) {
                        e.preventDefault();
                    }
                });
            }
            
            // Load movement history
            loadMovementHistory();
            
            // Apply filters button
            document.getElementById('apply-filters').addEventListener('click', function() {
                const ingredientId = document.getElementById('ingredient-filter').value;
                const dateFrom = document.getElementById('date-from').value;
                const dateTo = document.getElementById('date-to').value;
                
                loadMovementHistory(ingredientId, dateFrom, dateTo);
            });
            
            // Reset filters button
            document.getElementById('reset-filters').addEventListener('click', function() {
                document.getElementById('ingredient-filter').value = '';
                document.getElementById('date-from').value = '';
                document.getElementById('date-to').value = '';
                
                loadMovementHistory();
            });

            // Mobile sidebar toggle
            if (window.innerWidth <= 768) {
                const header = document.querySelector('.header-section');
                const menuBtn = document.createElement('button');
                menuBtn.innerHTML = '<i class="fas fa-bars"></i>';
                menuBtn.className = 'btn btn-primary';
                menuBtn.onclick = toggleSidebar;
                menuBtn.style.position = 'absolute';
                menuBtn.style.top = '20px';
                menuBtn.style.left = '20px';
                menuBtn.style.zIndex = '1001';
                document.body.appendChild(menuBtn);
            }
        });

        // Mobile sidebar toggle
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('open');
        }

        // Stock Movement History functionality
        function loadMovementHistory(ingredientId = '', dateFrom = '', dateTo = '') {
            const tableBody = document.getElementById('movement-history-body');
            tableBody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 20px;"><i class="fas fa-spinner fa-spin"></i> Loading movement history...</td></tr>';
            
            // Build query parameters
            const params = new URLSearchParams();
            if (ingredientId) params.append('ingredient_id', ingredientId);
            if (dateFrom) params.append('date_from', dateFrom);
            if (dateTo) params.append('date_to', dateTo);
            
            // Create a PHP file to handle this request - get_ingredient_movements.php
            fetch('get_ingredient_movements.php?' + params.toString())
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (data.movements && data.movements.length > 0) {
                            let html = '';
                            
                            data.movements.forEach(movement => {
                                const qohBefore = parseFloat(movement.quantity_before) || 0;
                                const stockOut = parseFloat(movement.sales_quantity) || 0;
                                const stockIn = parseFloat(movement.restock_quantity) || 0;
                                const qohAfter = parseFloat(movement.current_stock) || 0;
                                
                                html += `
                                    <tr>
                                        <td>${formatDateTime(movement.movement_date)}</td>
                                        <td><strong>${escapeHtml(movement.ingredient_name)}</strong></td>
                                        <td>${escapeHtml(movement.unit)}</td>
                                        <td class="${stockOut > 0 ? 'out-quantity' : ''}">${stockOut > 0 ? stockOut.toFixed(2) : '-'}</td>
                                        <td class="${stockIn > 0 ? 'in-quantity' : ''}">${stockIn > 0 ? stockIn.toFixed(2) : '-'}</td>
                                        <td class="balance-quantity">${qohAfter.toFixed(2)}</td>
                                        <td>${escapeHtml(movement.notes || '')}</td>
                                    </tr>
                                `;
                            });
                            
                            tableBody.innerHTML = html;
                        } else {
                            tableBody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 20px;"><i class="fas fa-info-circle"></i> No movement history found for the selected filters.</td></tr>';
                        }
                    } else {
                        tableBody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 20px; color: red;"><i class="fas fa-exclamation-triangle"></i> Error loading movement history: ' + escapeHtml(data.message || 'Unknown error') + '</td></tr>';
                    }
                })
                .catch(error => {
                    console.error('Error fetching movement history:', error);
                    tableBody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 20px; color: red;"><i class="fas fa-exclamation-triangle"></i> Error loading movement history. Please try again.</td></tr>';
                });
        }

        function formatDateTime(dateTimeStr) {
            const date = new Date(dateTimeStr);
            return date.toLocaleString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        }

        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Auto-refresh notifications every 30 seconds
        setInterval(function() {
            if (!document.hidden) {
                fetch('ingredients.php?ajax=notifications')
                    .then(response => response.json())
                    .then(data => {
                        if (data.unreadCount !== undefined) {
                            const badge = document.querySelector('.notification-badge');
                            const bellButton = document.querySelector('.notification-bell button');
                            
                            if (data.unreadCount > 0) {
                                if (!badge) {
                                    const newBadge = document.createElement('span');
                                    newBadge.className = 'notification-badge';
                                    newBadge.textContent = data.unreadCount;
                                    bellButton.appendChild(newBadge);
                                } else {
                                    badge.textContent = data.unreadCount;
                                }
                            } else if (badge) {
                                badge.remove();
                            }
                        }
                    })
                    .catch(error => console.log('Notification refresh failed:', error));
            }
        }, 30000);
    </script>
</body>
</html>