<?php
session_start();
include('../includes/db.php');

// 🛒 Ensure the product ID and quantity are passed
if (!isset($_POST['product_id']) || !isset($_POST['quantity'])) {
    header("Location: index.php");
    exit;
}

// 🛒 Get the product details from the database
$product_id = $_POST['product_id'];
$quantity = $_POST['quantity'];
$size = $_POST['size'] ?? null;
$flavor = $_POST['flavor'] ?? null;
$addons = $_POST['addons'] ?? null;

// Fetch product info securely using prepared statement
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();
$stmt->close();

// 🛒 If product exists, add to cart
if ($product) {
    // Check if the product is already in the cart
    $found = false;
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['id'] == $product['id'] && $item['size'] == $size && $item['flavor'] == $flavor && $item['addons'] == $addons) {
            // If product exists, update the quantity
            $item['quantity'] += $quantity;
            $found = true;
            break;
        }
    }

    // If not found in cart, add it
    if (!$found) {
        $cart_item = [
            'id' => $product['id'],
            'name' => $product['name'],
            'price' => $product['price'],
            'quantity' => $quantity,
            'size' => $size,
            'flavor' => $flavor,
            'addons' => $addons,
        ];
        $_SESSION['cart'][] = $cart_item;
    }

    $_SESSION['message'] = 'Product added to cart successfully!';
    header("Location: cart.php");
    exit;
} else {
    $_SESSION['message'] = 'Error: Product not found!';
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <meta charset="UTF-8">
    <title>Add Product to Cart</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto&display=swap">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            background-color: hsl(343, 96%, 89%);
            padding: 20px;
        }

        form {
            max-width: 600px;
            margin: 0 auto;
            background: hsl(293, 51%, 74%);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(77, 75, 75, 0.1);
            color: rgb(34, 33, 34);
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input[type="text"], input[type="number"], input[type="file"] {
            width: 95%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }

        button {
            margin-top: 20px;
            padding: 12px 25px;
            background-color: rgb(214, 134, 190);
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: rgb(226, 197, 222);
        }

        #customOptions {
            display: none;
            margin-top: 20px;
        }

    </style>
</head>
<body>

<h2>Add to Cart</h2>

<form method="POST" action="add_to_cart.php">
    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">

    <label>Quantity:</label>
    <input type="number" name="quantity" required>

    <label><input type="checkbox" id="toggleCustom"> Customizable?</label>

    <div id="customOptions">
        <label>Size (e.g., Small(+0), Medium(+10), Large(+20)):</label>
        <input type="text" name="size" placeholder="Optional if not customizable">

        <label>Flavor (e.g., Chocolate(+10), Vanilla(+5)):</label>
        <input type="text" name="flavor" placeholder="Flavor options with additional fees">

        <label>Add-ons (e.g., Cheese(+10), Bacon(+15)):</label>
        <input type="text" name="addons" placeholder="Optional extras">
    </div>

    <button type="submit">Add to Cart</button>
</form>

<script>
    document.getElementById('toggleCustom').addEventListener('change', function () {
        document.getElementById('customOptions').style.display = this.checked ? 'block' : 'none';
    });
</script>

</body>
</html>
