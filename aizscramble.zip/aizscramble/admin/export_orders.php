<?php
include('../includes/db.php');

$status = $_POST['status'] ?? 'all';
$from_date = $_POST['from_date'] ?? '';
$to_date = $_POST['to_date'] ?? '';

$where = "1=1";
$params = [];
$types = "";

if ($status !== 'all') {
    $where .= " AND status = ?";
    $params[] = $status;
    $types .= "s";
}
if (!empty($from_date) && !empty($to_date)) {
    $where .= " AND DATE(created_at) BETWEEN ? AND ?";
    $params[] = $from_date;
    $params[] = $to_date;
    $types .= "ss";
}

$sql = "SELECT * FROM orders WHERE $where ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=orders_export.csv');

$output = fopen('php://output', 'w');
fputcsv($output, ['Order ID', 'User ID', 'Total', 'Status', 'Payment', 'Delivery Place', 'Landmark', 'Created At']);

while ($row = $result->fetch_assoc()) {
    fputcsv($output, [
        $row['id'],
        $row['user_id'],
        $row['total_amount'],
        $row['status'],
        $row['payment_method'],
        $row['delivery_place'],
        $row['delivery_landmark'],
        $row['created_at']
    ]);
}

fclose($output);
exit;
