<?php
session_start();
include('../includes/db.php');
include('../includes/log_activity.php');
require_once('../includes/notify_helper.php');

if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../user/login.php");
    exit;
}

// Mark notifications as read if requested
if (isset($_GET['mark_read']) && $_GET['mark_read'] == 'all') {
    $conn->query("UPDATE AdminNotifications SET IsRead = 1 WHERE IsRead = 0");
    header("Location: admins.php");
    exit;
}

// Get unread notification count for the bell icon
$unreadCount = $conn->query("SELECT COUNT(*) as total FROM AdminNotifications WHERE IsRead = 0")->fetch_assoc()['total'];

// Fetch notifications for the dropdown
$notifQuery = $conn->query("SELECT * FROM AdminNotifications ORDER BY CreatedAt DESC LIMIT 5");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_admin'])) {
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        $name = trim($_POST['name']);
        $contact = trim($_POST['contact']);
        
        // Validation
        $errors = [];
        
        if (empty($name)) {
            $errors[] = "Name is required.";
        }
        
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Valid email is required.";
        }
        
        if (empty($contact)) {
            $errors[] = "Contact number is required.";
        }
        
        if (empty($password) || strlen($password) < 6) {
            $errors[] = "Password must be at least 6 characters long.";
        }
        
        // Check if email already exists
        if (empty($errors)) {
            $check_email = $conn->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
            $check_email->bind_param("s", $email);
            $check_email->execute();
            $check_email->bind_result($email_count);
            $check_email->fetch();
            $check_email->close();
            
            if ($email_count > 0) {
                $errors[] = "Email already exists in the system.";
            }
        }
        
        if (empty($errors)) {
            $pass_hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (name, email, contact, password, is_admin) VALUES (?, ?, ?, ?, 1)");
            $stmt->bind_param("ssss", $name, $email, $contact, $pass_hash);
            
            if ($stmt->execute()) {
                logActivity($conn, $_SESSION['user_id'], 'admin', "Added new admin: $name ($email)");
                $_SESSION['success'] = "Admin added successfully!";
            } else {
                $_SESSION['error'] = "Failed to add admin. Please try again.";
            }
            $stmt->close();
        } else {
            $_SESSION['error'] = implode("<br>", $errors);
        }
        
        header("Location: admins.php");
        exit;
    }
    
    if (isset($_POST['delete_admin'])) {
        $admin_id = intval($_POST['admin_id']);
        $current_user_id = $_SESSION['user_id'];
        
        // Prevent self-deletion
        if ($admin_id == $current_user_id) {
            $_SESSION['error'] = "You cannot delete your own admin account.";
        } else {
            // Get admin info before deletion
            $admin_info = $conn->prepare("SELECT name, email FROM users WHERE id = ? AND is_admin = 1");
            $admin_info->bind_param("i", $admin_id);
            $admin_info->execute();
            $admin_info->bind_result($admin_name, $admin_email);
            $admin_info->fetch();
            $admin_info->close();
            
            if ($admin_name) {
                $delete_stmt = $conn->prepare("DELETE FROM users WHERE id = ? AND is_admin = 1");
                $delete_stmt->bind_param("i", $admin_id);
                
                if ($delete_stmt->execute()) {
                    logActivity($conn, $_SESSION['user_id'], 'admin', "Deleted admin: $admin_name ($admin_email)");
                    $_SESSION['success'] = "Admin deleted successfully!";
                } else {
                    $_SESSION['error'] = "Failed to delete admin. Please try again.";
                }
                $delete_stmt->close();
            } else {
                $_SESSION['error'] = "Admin not found.";
            }
        }
        
        header("Location: admins.php");
        exit;
    }
}

// Get all admins
$admins = $conn->query("SELECT id, name, email, contact, created_at FROM users WHERE is_admin = 1 ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Management - AIZCAmble</title>
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --error-color: #EF4444;
            --info-color: #3B82F6;
            --shadow-pink: rgba(236, 72, 153, 0.2);
            --shadow-strong: rgba(0, 0, 0, 0.1);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-gradient-start) 0%, var(--background-gradient-end) 100%);
            min-height: 100vh;
            display: flex;
            color: var(--text-primary);
            position: relative;
            overflow-x: hidden;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, var(--primary-pink) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, var(--accent-purple) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, var(--secondary-pink) 0%, transparent 50%);
            opacity: 0.05;
            z-index: -1;
            animation: backgroundFloat 20s ease-in-out infinite;
        }

        @keyframes backgroundFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(-20px, -20px) scale(1.05); }
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary-pink) 0%, var(--primary-pink-dark) 100%);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--border-light);
            box-shadow: 4px 0 20px var(--shadow-pink);
            padding: 0;
            min-height: 100vh;
            position: relative;
            overflow: hidden;
        }

        .sidebar::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.1) 50%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
        }

        @keyframes shimmer {
            0%, 100% { transform: translateX(-100%); }
            50% { transform: translateX(100%); }
        }

        .logo-section {
            text-align: center;
            padding: 32px 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            position: relative;
            z-index: 2;
        }

        .logo-container {
            position: relative;
            display: inline-block;
            margin-bottom: 16px;
        }

        .logo-container::before {
            content: '';
            position: absolute;
            top: -8px;
            left: -8px;
            right: -8px;
            bottom: -8px;
            background: linear-gradient(45deg, rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0.1));
            border-radius: 50%;
            animation: logoGlow 2s ease-in-out infinite;
        }

        @keyframes logoGlow {
            0%, 100% { transform: scale(1); opacity: 0.7; }
            50% { transform: scale(1.05); opacity: 1; }
        }

        .logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(255, 255, 255, 0.9);
            object-fit: cover;
            position: relative;
            z-index: 2;
            transition: all 0.3s ease;
        }

        .logo:hover {
            transform: scale(1.1) rotate(5deg);
        }

        .brand-name {
            color: white;
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 8px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .admin-title {
            color: rgba(255, 255, 255, 0.9);
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-menu {
            padding: 24px 0;
            position: relative;
            z-index: 2;
        }

        .nav-item {
            display: block;
            padding: 16px 24px;
            margin: 8px 16px;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            border-radius: 16px;
            font-weight: 500;
            font-size: 15px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
        }

        .nav-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .nav-item:hover::before {
            left: 100%;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(8px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item.active {
            background: rgba(255, 255, 255, 0.25);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        .main-content {
            flex: 1;
            padding: 32px;
            overflow-y: auto;
            position: relative;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            padding: 24px 32px;
            border-radius: 20px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            position: relative;
            overflow: hidden;
        }

        .header-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .page-title {
            font-size: 32px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* Notification Bell */
        .notification-bell {
            position: relative;
            display: inline-block;
        }

        .notification-bell button {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border: none;
            border-radius: 50%;
            width: 48px;
            height: 48px;
            color: white;
            font-size: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        .notification-bell button:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 20px var(--shadow-pink);
        }

        .notification-badge {
            position: absolute;
            top: -6px;
            right: -6px;
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
            border-radius: 50%;
            padding: 4px 8px;
            font-size: 12px;
            font-weight: 700;
            min-width: 20px;
            text-align: center;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }

        .notification-dropdown {
            display: none;
            position: absolute;
            right: 0;
            top: 60px;
            background: white;
            width: 350px;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            max-height: 400px;
            overflow: hidden;
            border: 1px solid var(--border-light);
        }

        .notification-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 20px;
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            font-weight: 600;
        }

        .notification-header a {
            color: white;
            font-size: 12px;
            text-decoration: none;
            opacity: 0.9;
            transition: opacity 0.2s;
        }

        .notification-header a:hover {
            opacity: 1;
        }

        .notification-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            max-height: 300px;
            overflow-y: auto;
        }

        .notification-dropdown li {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border-light);
            transition: background-color 0.2s;
        }

        .notification-dropdown li:last-child {
            border-bottom: none;
        }

        .notification-dropdown li:hover {
            background-color: rgba(236, 72, 153, 0.05);
        }

        .notification-footer {
            padding: 16px 20px;
            text-align: center;
            border-top: 1px solid var(--border-light);
            background: rgba(236, 72, 153, 0.05);
        }

        .notification-footer a {
            color: var(--primary-pink);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.2s;
        }

        .notification-footer a:hover {
            color: var(--primary-pink-dark);
        }

        /* Alert Messages */
        .message {
            padding: 16px 20px;
            margin-bottom: 24px;
            border-radius: 12px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .success {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(5, 150, 105, 0.1));
            color: var(--success-color);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .error {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(220, 38, 38, 0.1));
            color: var(--error-color);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        /* Form Container */
        .form-container {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 32px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            margin-bottom: 32px;
            position: relative;
            overflow: hidden;
        }

        .form-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        .form-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .form-title i {
            color: var(--primary-pink);
            font-size: 20px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 24px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        label {
            font-weight: 600;
            color: var(--text-primary);
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        label i {
            color: var(--primary-pink);
            width: 16px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            padding: 12px 16px;
            border: 2px solid var(--border-light);
            border-radius: 12px;
            font-size: 14px;
            font-weight: 500;
            background: white;
            transition: all 0.3s ease;
            outline: none;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus {
            border-color: var(--primary-pink);
            box-shadow: 0 0 0 4px rgba(236, 72, 153, 0.1);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            border: none;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
        }

        .btn-danger {
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
        }

        /* Admin Cards Container */
        .admins-container {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            overflow: hidden;
            position: relative;
        }

        .admins-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        .admins-header {
            padding: 24px 32px;
            border-bottom: 1px solid var(--border-light);
        }

        .admins-title {
            font-size: 20px;
            font-weight: 700;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .admins-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 24px;
            padding: 32px;
        }

        .admin-card {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--border-light);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .admin-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(180deg, var(--primary-pink), var(--accent-purple));
            transition: width 0.3s ease;
        }

        .admin-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }

        .admin-card:hover::before {
            width: 8px;
        }

        .admin-card-header {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 16px;
        }

        .admin-avatar {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .admin-info h4 {
            font-size: 18px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 4px;
        }

        .admin-info p {
            color: var(--text-secondary);
            font-size: 14px;
            margin-bottom: 2px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .admin-info i {
            color: var(--primary-pink);
            width: 16px;
        }

        .admin-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid var(--border-light);
        }

        .admin-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            background: rgba(139, 92, 246, 0.1);
            color: var(--accent-purple);
        }

        .admin-actions {
            display: flex;
            gap: 8px;
        }

        .btn-small {
            padding: 6px 12px;
            font-size: 12px;
            border-radius: 8px;
        }

        /* Current User Highlight */
        .current-user {
            background: linear-gradient(135deg, rgba(236, 72, 153, 0.1), rgba(139, 92, 246, 0.1));
            border: 2px solid rgba(236, 72, 153, 0.2);
        }

        .current-user::before {
            background: linear-gradient(180deg, var(--warning-color), #D97706);
        }

        .current-user-badge {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning-color);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-light);
        }

        .empty-state i {
            font-size: 64px;
            margin-bottom: 20px;
            color: var(--primary-pink);
            opacity: 0.5;
        }

        .empty-state h3 {
            font-size: 20px;
            margin-bottom: 12px;
            color: var(--text-secondary);
        }

        .empty-state p {
            font-size: 16px;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(5px);
        }

        .modal-content {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            margin: 10% auto;
            padding: 32px;
            border-radius: 20px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            border: 1px solid var(--border-light);
            position: relative;
            overflow: hidden;
        }

        .modal-content::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        .close {
            color: var(--text-light);
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .close:hover {
            color: var(--primary-pink);
        }

        .modal h3 {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .modal h3 i {
            color: var(--error-color);
        }

        .modal-actions {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            margin-top: 24px;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .sidebar {
                width: 240px;
            }
        }

        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                min-height: auto;
                position: fixed;
                top: 0;
                left: -100%;
                z-index: 1000;
                transition: left 0.3s ease;
            }
            
            .sidebar.open {
                left: 0;
            }
            
            .main-content {
                padding: 20px;
                margin-top: 0;
            }
            
            .header-section {
                flex-direction: column;
                gap: 16px;
                text-align: center;
            }
            
            .page-title {
                font-size: 24px;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .admins-grid {
                grid-template-columns: 1fr;
                padding: 20px;
            }
            
            .notification-dropdown {
                width: 300px;
                right: -50px;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(236, 72, 153, 0.1);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--primary-pink-dark), var(--primary-pink));
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <div class="logo-container">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo" class="logo">
            </div>
            <div class="brand-name">AIZCAmble</div>
            <div class="admin-title">Admin Panel</div>
        </div>

        <nav class="nav-menu">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                Dashboard
            </a>
            <a href="orders.php" class="nav-item">
                <i class="fas fa-shopping-bag"></i>
                Manage Orders
            </a>
            <a href="add_product.php" class="nav-item">
                <i class="fas fa-plus-circle"></i>
                Add Product
            </a>
            <a href="stock.php" class="nav-item">
                <i class="fas fa-boxes"></i>
                Stock Management
            </a>
            <a href="sales_analytics.php" class="nav-item">
                <i class="fas fa-chart-bar"></i>
                Sales Analytics
            </a>
            <a href="users.php" class="nav-item">
                <i class="fas fa-users"></i>
                Customers
            </a>
            <a href="ingredients.php" class="nav-item">
                <i class="fas fa-flask"></i>
                Ingredients
            </a>
            <a href="admins.php" class="nav-item active">
                <i class="fas fa-user-shield"></i>
                Admins
            </a>
            <a href="shutdown.php" class="nav-item">
                <i class="fas fa-power-off"></i>
                Shutdown Shop
            </a>
            <a href="activity_log.php" class="nav-item">
                <i class="fas fa-history"></i>
                Activity History
            </a>
            <a href="notifications.php" class="nav-item">
                <i class="fas fa-bell"></i>
                Notifications
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header-section">
            <h1 class="page-title">
                <i class="fas fa-user-shield"></i>
                Admin Management
            </h1>
            
            <!-- Notification Bell -->
            <div class="notification-bell">
                <button onclick="toggleDropdown()">
                    <i class="fas fa-bell"></i>
                    <?php if ($unreadCount > 0): ?>
                        <span class="notification-badge">
                            <?= $unreadCount ?>
                        </span>
                    <?php endif; ?>
                </button>
                <div id="notifDropdown" class="notification-dropdown">
                    <div class="notification-header">
                        <span>Notifications</span>
                        <?php if ($unreadCount > 0): ?>
                            <a href="admins.php?mark_read=all">Mark all as read</a>
                        <?php endif; ?>
                    </div>
                    <ul>
                        <?php if ($notifQuery->num_rows > 0): ?>
                            <?php while ($notif = $notifQuery->fetch_assoc()): ?>
                                <li style="<?= $notif['IsRead'] ? '' : 'background-color: rgba(236, 72, 153, 0.05);' ?>">
                                    <strong><?= htmlspecialchars($notif['Title']) ?></strong><br>
                                    <small><?= htmlspecialchars($notif['message']) ?></small><br>
                                    <small style="color: #888;"><?= date('M d, Y h:i A', strtotime($notif['CreatedAt'])) ?></small>
                                </li>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <li>No notifications yet</li>
                        <?php endif; ?>
                    </ul>
                    <div class="notification-footer">
                        <a href="notifications.php">View All Notifications</a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Alert Messages -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="message success">
                <i class="fas fa-check-circle"></i>
                <?= htmlspecialchars($_SESSION['success']) ?>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="message error">
                <i class="fas fa-exclamation-circle"></i>
                <?= $_SESSION['error'] ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <!-- Add Admin Form -->
        <div class="form-container">
            <h3 class="form-title">
                <i class="fas fa-user-plus"></i>
                Add New Administrator
            </h3>
            <form method="POST" id="addAdminForm">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="name">
                            <i class="fas fa-user"></i>
                            Full Name
                        </label>
                        <input type="text" id="name" name="name" required placeholder="Enter full name">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">
                            <i class="fas fa-envelope"></i>
                            Email Address
                        </label>
                        <input type="email" id="email" name="email" required placeholder="Enter email address">
                    </div>
                    
                    <div class="form-group">
                        <label for="contact">
                            <i class="fas fa-phone"></i>
                            Contact Number
                        </label>
                        <input type="text" id="contact" name="contact" required placeholder="Enter contact number">
                    </div>
                    
                    <div class="form-group">
                        <label for="password">
                            <i class="fas fa-lock"></i>
                            Password
                        </label>
                        <input type="password" id="password" name="password" required placeholder="Enter password (min. 6 characters)">
                    </div>
                </div>
                
                <button type="submit" name="add_admin" class="btn btn-primary">
                    <i class="fas fa-plus"></i>
                    Add Administrator
                </button>
            </form>
        </div>
        
        <!-- Existing Admins -->
        <div class="admins-container">
            <div class="admins-header">
                <h3 class="admins-title">
                    <i class="fas fa-users-cog"></i>
                    Current Administrators
                </h3>
            </div>
            
            <?php if ($admins->num_rows > 0): ?>
                <div class="admins-grid">
                    <?php while ($admin = $admins->fetch_assoc()): ?>
                        <?php $isCurrentUser = $admin['id'] == $_SESSION['user_id']; ?>
                        <div class="admin-card <?= $isCurrentUser ? 'current-user' : '' ?>">
                            <div class="admin-card-header">
                                <div class="admin-avatar">
                                    <?= strtoupper(substr($admin['name'], 0, 2)) ?>
                                </div>
                                <div class="admin-info">
                                    <h4><?= htmlspecialchars($admin['name']) ?></h4>
                                    <p>
                                        <i class="fas fa-envelope"></i>
                                        <?= htmlspecialchars($admin['email']) ?>
                                    </p>
                                    <p>
                                        <i class="fas fa-phone"></i>
                                        <?= htmlspecialchars($admin['contact']) ?>
                                    </p>
                                    <p>
                                        <i class="fas fa-calendar"></i>
                                        Joined <?= date('M Y', strtotime($admin['created_at'])) ?>
                                    </p>
                                </div>
                            </div>
                            
                            <div class="admin-meta">
                                <div class="admin-badge <?= $isCurrentUser ? 'current-user-badge' : '' ?>">
                                    <i class="fas fa-shield-alt"></i>
                                    <?= $isCurrentUser ? 'You' : 'Administrator' ?>
                                </div>
                                
                                <?php if (!$isCurrentUser): ?>
                                    <div class="admin-actions">
                                        <button class="btn btn-danger btn-small" onclick="confirmDelete(<?= $admin['id'] ?>, '<?= htmlspecialchars(addslashes($admin['name'])) ?>')">
                                            <i class="fas fa-trash"></i>
                                            Remove
                                        </button>
                                    </div>
                                <?php else: ?>
                                    <div class="admin-actions">
                                        <span style="font-size: 12px; color: var(--text-secondary);">
                                            <i class="fas fa-info-circle"></i>
                                            Current Session
                                        </span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-user-shield"></i>
                    <h3>No Administrators Found</h3>
                    <p>Add your first administrator using the form above.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeDeleteModal()">&times;</span>
            <h3>
                <i class="fas fa-exclamation-triangle"></i>
                Confirm Admin Removal
            </h3>
            <p>Are you sure you want to remove <strong id="adminNameToDelete"></strong> from the administrator list?</p>
            <p style="color: var(--error-color); font-size: 14px; margin-top: 12px;">
                <i class="fas fa-warning"></i>
                This action cannot be undone. The user will lose all administrative privileges.
            </p>
            <form id="deleteForm" method="POST">
                <input type="hidden" name="admin_id" id="adminIdToDelete">
                <div class="modal-actions">
                    <button type="submit" name="delete_admin" class="btn btn-danger">
                        <i class="fas fa-trash"></i>
                        Remove Admin
                    </button>
                    <button type="button" onclick="closeDeleteModal()" class="btn btn-secondary">
                        <i class="fas fa-times"></i>
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Notification dropdown toggle
        function toggleDropdown() {
            const dropdown = document.getElementById('notifDropdown');
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        }

        // Close dropdown when clicking outside
        window.addEventListener('click', function(event) {
            const dropdown = document.getElementById('notifDropdown');
            const bell = document.querySelector('.notification-bell button');
            if (!bell.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = 'none';
            }
        });

        // Delete confirmation modal
        function confirmDelete(adminId, adminName) {
            document.getElementById('adminIdToDelete').value = adminId;
            document.getElementById('adminNameToDelete').textContent = adminName;
            document.getElementById('deleteModal').style.display = 'block';
        }

        function closeDeleteModal() {
            document.getElementById('deleteModal').style.display = 'none';
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('deleteModal');
            if (event.target == modal) {
                closeDeleteModal();
            }
        }

        // Form validation
        document.getElementById('addAdminForm').addEventListener('submit', function(e) {
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const contact = document.getElementById('contact').value.trim();
            const password = document.getElementById('password').value;
            
            let errors = [];
            
            if (name === '') {
                errors.push('Name is required.');
            }
            
            if (email === '' || !isValidEmail(email)) {
                errors.push('Valid email is required.');
            }
            
            if (contact === '') {
                errors.push('Contact number is required.');
            }
            
            if (password.length < 6) {
                errors.push('Password must be at least 6 characters long.');
            }
            
            if (errors.length > 0) {
                e.preventDefault();
                alert('Please fix the following errors:\n\n' + errors.join('\n'));
            }
        });

        function isValidEmail(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }

        // Mobile sidebar toggle
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('open');
        }

        // Add mobile menu button if needed
        if (window.innerWidth <= 768) {
            const header = document.querySelector('.header-section');
            const menuBtn = document.createElement('button');
            menuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            menuBtn.className = 'btn btn-primary';
            menuBtn.onclick = toggleSidebar;
            menuBtn.style.position = 'absolute';
            menuBtn.style.top = '20px';
            menuBtn.style.left = '20px';
            menuBtn.style.zIndex = '1001';
            document.body.appendChild(menuBtn);
        }

        // Auto-refresh notifications every 30 seconds
        setInterval(function() {
            if (!document.hidden) {
                fetch('admins.php?ajax=notifications')
                    .then(response => response.json())
                    .then(data => {
                        if (data.unreadCount !== undefined) {
                            const badge = document.querySelector('.notification-badge');
                            const bellButton = document.querySelector('.notification-bell button');
                            
                            if (data.unreadCount > 0) {
                                if (!badge) {
                                    const newBadge = document.createElement('span');
                                    newBadge.className = 'notification-badge';
                                    newBadge.textContent = data.unreadCount;
                                    bellButton.appendChild(newBadge);
                                } else {
                                    badge.textContent = data.unreadCount;
                                }
                            } else if (badge) {
                                badge.remove();
                            }
                        }
                    })
                    .catch(error => console.log('Notification refresh failed:', error));
            }
        }, 30000);

        // Add hover effects to admin cards
        document.querySelectorAll('.admin-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-8px)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(-4px)';
            });
        });

        // Add input focus animations
        document.querySelectorAll('input').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.style.transform = 'scale(1.02)';
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.style.transform = 'scale(1)';
            });
        });
    </script>
</body>
</html>