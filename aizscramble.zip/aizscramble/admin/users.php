<?php
session_start();
require('../includes/db.php');
require_once('../includes/notify_helper.php'); // Added notification helper

if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../user/login.php");
    exit;
}

// Mark notifications as read if requested
if (isset($_GET['mark_read']) && $_GET['mark_read'] == 'all') {
    $conn->query("UPDATE AdminNotifications SET IsRead = 1 WHERE IsRead = 0");
    header("Location: users.php");
    exit;
}

// Fetch notifications for the dropdown
$notifQuery = $conn->query("SELECT * FROM AdminNotifications ORDER BY CreatedAt DESC LIMIT 5");
$unreadCount = $conn->query("SELECT COUNT(*) as total FROM AdminNotifications WHERE IsRead = 0")->fetch_assoc()['total'];

// Get all users
$users_sql = "SELECT * FROM users WHERE is_admin = 0 ORDER BY id DESC";
$users = $conn->query($users_sql);

// Get user ID from query string if viewing specific customer
$customer_id = $_GET['customer_id'] ?? null;

// Filters
$status_filter = $_GET['status'] ?? 'all';
$from_date = $_GET['from_date'] ?? '';
$to_date = $_GET['to_date'] ?? '';

// Build SQL
$where = "1=1";
$params = [];
$types = "";

if ($customer_id) {
    $where .= " AND user_id = ?";
    $params[] = $customer_id;
    $types .= "i";
}

if ($status_filter !== 'all') {
    $where .= " AND status = ?";
    $params[] = $status_filter;
    $types .= "s";
}

if (!empty($from_date) && !empty($to_date)) {
    $where .= " AND DATE(created_at) BETWEEN ? AND ?";
    $params[] = $from_date;
    $params[] = $to_date;
    $types .= "ss";
}

$sql = "SELECT * FROM orders WHERE $where ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$orders = $stmt->get_result();

// Get customer details if viewing specific customer
$customer = null;
if ($customer_id) {
    $customer_stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $customer_stmt->bind_param("i", $customer_id);
    $customer_stmt->execute();
    $customer = $customer_stmt->get_result()->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $customer ? "Orders for ".htmlspecialchars($customer['name']) : "Customer Management" ?> - AIZCAmble</title>
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --error-color: #EF4444;
            --info-color: #3B82F6;
            --shadow-pink: rgba(236, 72, 153, 0.2);
            --shadow-strong: rgba(0, 0, 0, 0.1);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-gradient-start) 0%, var(--background-gradient-end) 100%);
            min-height: 100vh;
            display: flex;
            color: var(--text-primary);
            position: relative;
            overflow-x: hidden;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, var(--primary-pink) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, var(--accent-purple) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, var(--secondary-pink) 0%, transparent 50%);
            opacity: 0.05;
            z-index: -1;
            animation: backgroundFloat 20s ease-in-out infinite;
        }

        @keyframes backgroundFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(-20px, -20px) scale(1.05); }
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary-pink) 0%, var(--primary-pink-dark) 100%);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--border-light);
            box-shadow: 4px 0 20px var(--shadow-pink);
            padding: 0;
            min-height: 100vh;
            position: relative;
            overflow: hidden;
        }

        .sidebar::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.1) 50%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
        }

        @keyframes shimmer {
            0%, 100% { transform: translateX(-100%); }
            50% { transform: translateX(100%); }
        }

        .logo-section {
            text-align: center;
            padding: 32px 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            position: relative;
            z-index: 2;
        }

        .logo-container {
            position: relative;
            display: inline-block;
            margin-bottom: 16px;
        }

        .logo-container::before {
            content: '';
            position: absolute;
            top: -8px;
            left: -8px;
            right: -8px;
            bottom: -8px;
            background: linear-gradient(45deg, rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0.1));
            border-radius: 50%;
            animation: logoGlow 2s ease-in-out infinite;
        }

        @keyframes logoGlow {
            0%, 100% { transform: scale(1); opacity: 0.7; }
            50% { transform: scale(1.05); opacity: 1; }
        }

        .logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(255, 255, 255, 0.9);
            object-fit: cover;
            position: relative;
            z-index: 2;
            transition: all 0.3s ease;
        }

        .logo:hover {
            transform: scale(1.1) rotate(5deg);
        }

        .brand-name {
            color: white;
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 8px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .admin-title {
            color: rgba(255, 255, 255, 0.9);
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-menu {
            padding: 24px 0;
            position: relative;
            z-index: 2;
        }

        .nav-item {
            display: block;
            padding: 16px 24px;
            margin: 8px 16px;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            border-radius: 16px;
            font-weight: 500;
            font-size: 15px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
        }

        .nav-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .nav-item:hover::before {
            left: 100%;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(8px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item.active {
            background: rgba(255, 255, 255, 0.25);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        .main-content {
            flex: 1;
            padding: 32px;
            overflow-y: auto;
            position: relative;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            padding: 24px 32px;
            border-radius: 20px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            position: relative;
            overflow: hidden;
        }

        .header-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .page-title {
            font-size: 32px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* Notification Bell */
        .notification-bell {
            position: relative;
            display: inline-block;
        }

        .notification-bell button {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border: none;
            border-radius: 50%;
            width: 48px;
            height: 48px;
            color: white;
            font-size: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        .notification-bell button:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 20px var(--shadow-pink);
        }

        .notification-badge {
            position: absolute;
            top: -6px;
            right: -6px;
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
            border-radius: 50%;
            padding: 4px 8px;
            font-size: 12px;
            font-weight: 700;
            min-width: 20px;
            text-align: center;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }

        .notification-dropdown {
            display: none;
            position: absolute;
            right: 0;
            top: 60px;
            background: white;
            width: 350px;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            max-height: 400px;
            overflow: hidden;
            border: 1px solid var(--border-light);
        }

        .notification-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 20px;
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            font-weight: 600;
        }

        .notification-header a {
            color: white;
            font-size: 12px;
            text-decoration: none;
            opacity: 0.9;
            transition: opacity 0.2s;
        }

        .notification-header a:hover {
            opacity: 1;
        }

        .notification-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            max-height: 300px;
            overflow-y: auto;
        }

        .notification-dropdown li {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border-light);
            transition: background-color 0.2s;
        }

        .notification-dropdown li:last-child {
            border-bottom: none;
        }

        .notification-dropdown li:hover {
            background-color: rgba(236, 72, 153, 0.05);
        }

        .notification-footer {
            padding: 16px 20px;
            text-align: center;
            border-top: 1px solid var(--border-light);
            background: rgba(236, 72, 153, 0.05);
        }

        .notification-footer a {
            color: var(--primary-pink);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.2s;
        }

        .notification-footer a:hover {
            color: var(--primary-pink-dark);
        }

        /* Back Link */
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 24px;
            color: var(--primary-pink);
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            padding: 12px 20px;
            background: rgba(236, 72, 153, 0.1);
            border-radius: 12px;
            border: 1px solid var(--border-light);
            transition: all 0.3s ease;
        }

        .back-link:hover {
            background: rgba(236, 72, 153, 0.15);
            transform: translateX(-4px);
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        /* Customer Detail Card */
        .customer-detail-card {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            padding: 32px;
            border-radius: 20px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            margin-bottom: 32px;
            position: relative;
            overflow: hidden;
        }

        .customer-detail-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.1) 50%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
        }

        .customer-detail-header {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 20px;
            position: relative;
            z-index: 2;
        }

        .customer-avatar {
            width: 80px;
            height: 80px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            font-weight: 700;
            border: 3px solid rgba(255, 255, 255, 0.3);
        }

        .customer-info h3 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .customer-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
            position: relative;
            z-index: 2;
        }

        .stat-item {
            background: rgba(255, 255, 255, 0.1);
            padding: 16px;
            border-radius: 12px;
            text-align: center;
            backdrop-filter: blur(10px);
        }

        .stat-value {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 4px;
        }

        .stat-label {
            font-size: 14px;
            opacity: 0.9;
        }

        /* Filter Section */
        .filter-section {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            padding: 24px;
            border-radius: 16px;
            margin-bottom: 32px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--border-light);
        }

        .filter-form {
            display: flex;
            gap: 20px;
            align-items: end;
            flex-wrap: wrap;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .filter-group label {
            font-weight: 600;
            color: var(--text-primary);
            font-size: 14px;
        }

        .filter-group input,
        .filter-group select {
            padding: 12px 16px;
            border: 2px solid var(--border-light);
            border-radius: 12px;
            font-size: 14px;
            font-weight: 500;
            background: white;
            transition: all 0.3s ease;
            outline: none;
        }

        .filter-group input:focus,
        .filter-group select:focus {
            border-color: var(--primary-pink);
            box-shadow: 0 0 0 4px rgba(236, 72, 153, 0.1);
        }

        .filter-actions {
            display: flex;
            gap: 12px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 20px;
            border: none;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
        }

        .btn-secondary {
            background: var(--text-light);
            color: white;
        }

        .btn-view {
            background: linear-gradient(135deg, var(--info-color), #2563EB);
            color: white;
        }

        /* Customer Cards */
        .customers-grid {
            display: grid;
            gap: 20px;
        }

        .customer-card {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--border-light);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .customer-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(180deg, var(--primary-pink), var(--accent-purple));
            transition: width 0.3s ease;
        }

        .customer-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }

        .customer-card:hover::before {
            width: 8px;
        }

        .customer-card-header {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 16px;
        }

        .customer-card-avatar {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            font-weight: 700;
        }

        .customer-card-info h4 {
            font-size: 18px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 4px;
        }

        .customer-card-info p {
            color: var(--text-secondary);
            font-size: 14px;
            margin-bottom: 2px;
        }

        .customer-card-stats {
            display: flex;
            justify-content: space-between;
            margin-bottom: 16px;
            padding: 12px;
            background: rgba(236, 72, 153, 0.05);
            border-radius: 8px;
        }

        .customer-stat {
            text-align: center;
        }

        .customer-stat-value {
            font-size: 18px;
            font-weight: 700;
            color: var(--primary-pink);
        }

        .customer-stat-label {
            font-size: 12px;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .customer-card-actions {
            display: flex;
            justify-content: flex-end;
        }

        /* Orders Table */
        .orders-container {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            overflow: hidden;
            position: relative;
        }

        .orders-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        .orders-header {
            padding: 24px 32px;
            border-bottom: 1px solid var(--border-light);
        }

        .orders-title {
            font-size: 20px;
            font-weight: 700;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .table-container {
            max-height: 600px;
            overflow-y: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            padding: 16px 20px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        td {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border-light);
            font-size: 14px;
            font-weight: 500;
        }

        tr:hover {
            background: rgba(236, 72, 153, 0.02);
        }

        tr:last-child td {
            border-bottom: none;
        }

        /* Status Badges */
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-pending {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning-color);
        }

        .status-approved {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success-color);
        }

        .status-rejected {
            background: rgba(239, 68, 68, 0.1);
            color: var(--error-color);
        }

        .status-canceled {
            background: rgba(156, 163, 175, 0.1);
            color: var(--text-light);
        }

        .status-preparing {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning-color);
        }

        .status-out_for_delivery {
            background: rgba(59, 130, 246, 0.1);
            color: var(--info-color);
        }

        .status-delivered {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success-color);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-light);
        }

        .empty-state i {
            font-size: 64px;
            margin-bottom: 20px;
            color: var(--primary-pink);
            opacity: 0.5;
        }

        .empty-state h3 {
            font-size: 20px;
            margin-bottom: 12px;
            color: var(--text-secondary);
        }

        .empty-state p {
            font-size: 16px;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .sidebar {
                width: 240px;
            }
        }

        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                min-height: auto;
                position: fixed;
                top: 0;
                left: -100%;
                z-index: 1000;
                transition: left 0.3s ease;
            }
            
            .sidebar.open {
                left: 0;
            }
            
            .main-content {
                padding: 20px;
                margin-top: 0;
            }
            
            .header-section {
                flex-direction: column;
                gap: 16px;
                text-align: center;
            }
            
            .page-title {
                font-size: 24px;
            }
            
            .filter-form {
                flex-direction: column;
                align-items: stretch;
            }
            
            .filter-actions {
                justify-content: center;
            }
            
            .customer-stats {
                grid-template-columns: 1fr 1fr;
            }
            
            .table-container {
                overflow-x: auto;
            }
            
            table {
                min-width: 600px;
            }
            
            .notification-dropdown {
                width: 300px;
                right: -50px;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(236, 72, 153, 0.1);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--primary-pink-dark), var(--primary-pink));
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <div class="logo-container">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo" class="logo">
            </div>
            <div class="brand-name">AIZCAmble</div>
            <div class="admin-title">Admin Panel</div>
        </div>

        <nav class="nav-menu">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                Dashboard
            </a>
            <a href="orders.php" class="nav-item">
                <i class="fas fa-shopping-bag"></i>
                Manage Orders
            </a>
            <a href="add_product.php" class="nav-item">
                <i class="fas fa-plus-circle"></i>
                Add Product
            </a>
            <a href="stock.php" class="nav-item">
                <i class="fas fa-boxes"></i>
                Stock Management
            </a>
            <a href="sales_analytics.php" class="nav-item">
                <i class="fas fa-chart-bar"></i>
                Sales Analytics
            </a>
            <a href="users.php" class="nav-item active">
                <i class="fas fa-users"></i>
                Customers
            </a>
            <a href="ingredients.php" class="nav-item">
                <i class="fas fa-flask"></i>
                Ingredients
            </a>
            <a href="admins.php" class="nav-item">
                <i class="fas fa-user-shield"></i>
                Admins
            </a>
            <a href="shutdown.php" class="nav-item">
                <i class="fas fa-power-off"></i>
                Shutdown Shop
            </a>
            <a href="activity_log.php" class="nav-item">
                <i class="fas fa-history"></i>
                Activity History
            </a>
            <a href="notifications.php" class="nav-item">
                <i class="fas fa-bell"></i>
                Notifications
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header-section">
            <h1 class="page-title">
                <?php if ($customer): ?>
                    <i class="fas fa-user-circle"></i>
                    Orders for <?= htmlspecialchars($customer['name']) ?>
                <?php else: ?>
                    <i class="fas fa-users"></i>
                    Customer Management
                <?php endif; ?>
            </h1>
            
            <!-- Notification Bell -->
            <div class="notification-bell">
                <button onclick="toggleDropdown()">
                    <i class="fas fa-bell"></i>
                    <?php if ($unreadCount > 0): ?>
                        <span class="notification-badge">
                            <?= $unreadCount ?>
                        </span>
                    <?php endif; ?>
                </button>
                <div id="notifDropdown" class="notification-dropdown">
                    <div class="notification-header">
                        <span>Notifications</span>
                        <?php if ($unreadCount > 0): ?>
                            <a href="users.php?mark_read=all">Mark all as read</a>
                        <?php endif; ?>
                    </div>
                    <ul>
                        <?php if ($notifQuery->num_rows > 0): ?>
                            <?php while ($notif = $notifQuery->fetch_assoc()): ?>
                                <li style="<?= $notif['IsRead'] ? '' : 'background-color: rgba(236, 72, 153, 0.05);' ?>">
                                    <strong><?= htmlspecialchars($notif['Title']) ?></strong><br>
                                    <small><?= htmlspecialchars($notif['message']) ?></small><br>
                                    <small style="color: #888;"><?= date('M d, Y h:i A', strtotime($notif['CreatedAt'])) ?></small>
                                </li>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <li>No notifications yet</li>
                        <?php endif; ?>
                    </ul>
                    <div class="notification-footer">
                        <a href="notifications.php">View All Notifications</a>
                    </div>
                </div>
            </div>
        </div>

        <?php if ($customer): ?>
            <!-- Back Link -->
            <a href="users.php" class="back-link">
                <i class="fas fa-arrow-left"></i>
                Back to All Customers
            </a>
            
            <!-- Customer Detail Card -->
            <div class="customer-detail-card">
                <div class="customer-detail-header">
                    <div class="customer-avatar">
                        <?= strtoupper(substr($customer['name'], 0, 2)) ?>
                    </div>
                    <div class="customer-info">
                        <h3><?= htmlspecialchars($customer['name']) ?></h3>
                        <p><i class="fas fa-envelope"></i> <?= htmlspecialchars($customer['email']) ?></p>
                        <p><i class="fas fa-phone"></i> <?= htmlspecialchars($customer['contact'] ?? 'N/A') ?></p>
                    </div>
                </div>
                <div class="customer-stats">
                    <div class="stat-item">
                        <div class="stat-value"><?= $orders->num_rows ?></div>
                        <div class="stat-label">Total Orders</div>
                    </div>
                    <div class="stat-item">
                        <?php
                        // Calculate total spent
                        $total_spent_sql = "SELECT SUM(total_amount) as total FROM orders WHERE user_id = ? AND status = 'delivered'";
                        $stmt = $conn->prepare($total_spent_sql);
                        $stmt->bind_param("i", $customer_id);
                        $stmt->execute();
                        $total_spent = $stmt->get_result()->fetch_assoc()['total'] ?? 0;
                        ?>
                        <div class="stat-value">₱<?= number_format($total_spent, 2) ?></div>
                        <div class="stat-label">Total Spent</div>
                    </div>
                    <div class="stat-item">
                        <?php
                        // Calculate average order value
                        $avg_order = $orders->num_rows > 0 ? $total_spent / $orders->num_rows : 0;
                        ?>
                        <div class="stat-value">₱<?= number_format($avg_order, 2) ?></div>
                        <div class="stat-label">Avg Order Value</div>
                    </div>
                </div>
            </div>

            <!-- Filter Section -->
            <div class="filter-section">
                <form method="GET" class="filter-form">
                    <input type="hidden" name="customer_id" value="<?= $customer_id ?>">
                    
                    <div class="filter-group">
                        <label>
                            <i class="fas fa-filter"></i>
                            Status
                        </label>
                        <select name="status">
                            <option value="all" <?= $status_filter === 'all' ? 'selected' : '' ?>>All Statuses</option>
                            <option value="pending" <?= $status_filter === 'pending' ? 'selected' : '' ?>>Pending</option>
                            <option value="approved" <?= $status_filter === 'approved' ? 'selected' : '' ?>>Approved</option>
                            <option value="preparing" <?= $status_filter === 'preparing' ? 'selected' : '' ?>>Preparing</option>
                            <option value="out_for_delivery" <?= $status_filter === 'out_for_delivery' ? 'selected' : '' ?>>Out for Delivery</option>
                            <option value="delivered" <?= $status_filter === 'delivered' ? 'selected' : '' ?>>Delivered</option>
                            <option value="rejected" <?= $status_filter === 'rejected' ? 'selected' : '' ?>>Rejected</option>
                            <option value="canceled" <?= $status_filter === 'canceled' ? 'selected' : '' ?>>Canceled</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>
                            <i class="fas fa-calendar-alt"></i>
                            From Date
                        </label>
                        <input type="date" name="from_date" value="<?= $from_date ?>">
                    </div>
                    
                    <div class="filter-group">
                        <label>
                            <i class="fas fa-calendar-alt"></i>
                            To Date
                        </label>
                        <input type="date" name="to_date" value="<?= $to_date ?>">
                    </div>
                    
                    <div class="filter-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search"></i>
                            Apply Filters
                        </button>
                        <a href="?customer_id=<?= $customer_id ?>" class="btn btn-secondary">
                            <i class="fas fa-undo"></i>
                            Reset
                        </a>
                    </div>
                </form>
            </div>

            <!-- Orders Table -->
            <div class="orders-container">
                <div class="orders-header">
                    <h3 class="orders-title">
                        <i class="fas fa-shopping-bag"></i>
                        Customer Orders
                    </h3>
                </div>
                <?php if ($orders->num_rows > 0): ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th><i class="fas fa-hashtag"></i> Order ID</th>
                                    <th><i class="fas fa-calendar"></i> Date</th>
                                    <th><i class="fas fa-money-bill"></i> Amount</th>
                                    <th><i class="fas fa-info-circle"></i> Status</th>
                                    <th><i class="fas fa-cogs"></i> Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                // Reset the result pointer
                                $orders->data_seek(0);
                                while ($order = $orders->fetch_assoc()): 
                                ?>
                                    <tr>
                                        <td>
                                            <strong style="color: var(--primary-pink);">#<?= $order['id'] ?></strong>
                                        </td>
                                        <td>
                                            <span style="color: var(--text-secondary);">
                                                <?= date('M j, Y', strtotime($order['created_at'])) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span style="font-weight: 700; color: var(--success-color);">
                                                ₱<?= number_format($order['total_amount'], 2) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="status-badge status-<?= $order['status'] ?>">
                                                <?php
                                                $status_icons = [
                                                    'pending' => 'fas fa-clock',
                                                    'approved' => 'fas fa-check',
                                                    'preparing' => 'fas fa-utensils',
                                                    'out_for_delivery' => 'fas fa-truck',
                                                    'delivered' => 'fas fa-check-circle',
                                                    'rejected' => 'fas fa-times-circle',
                                                    'canceled' => 'fas fa-ban'
                                                ];
                                                $icon = $status_icons[$order['status']] ?? 'fas fa-info-circle';
                                                ?>
                                                <i class="<?= $icon ?>"></i>
                                                <?= ucfirst($order['status']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="view_order.php?id=<?= $order['id'] ?>" class="btn btn-view">
                                                <i class="fas fa-eye"></i>
                                                View Details
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-shopping-bag"></i>
                        <h3>No Orders Found</h3>
                        <p>This customer hasn't placed any orders yet or no orders match your filters.</p>
                    </div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <!-- All Customers View -->
            <div class="orders-container">
                <div class="orders-header">
                    <h3 class="orders-title">
                        <i class="fas fa-users"></i>
                        All Customers
                    </h3>
                </div>
                <?php if ($users->num_rows > 0): ?>
                    <div style="padding: 32px;">
                        <div class="customers-grid">
                            <?php while ($user = $users->fetch_assoc()): 
                                // Get order count for this user
                                $order_count_sql = "SELECT COUNT(*) as count FROM orders WHERE user_id = ?";
                                $stmt = $conn->prepare($order_count_sql);
                                $stmt->bind_param("i", $user['id']);
                                $stmt->execute();
                                $order_count = $stmt->get_result()->fetch_assoc()['count'];
                                
                                // Get total spent by this user
                                $total_spent_sql = "SELECT SUM(total_amount) as total FROM orders WHERE user_id = ? AND status = 'delivered'";
                                $stmt = $conn->prepare($total_spent_sql);
                                $stmt->bind_param("i", $user['id']);
                                $stmt->execute();
                                $total_spent = $stmt->get_result()->fetch_assoc()['total'] ?? 0;
                            ?>
                                <div class="customer-card">
                                    <div class="customer-card-header">
                                        <div class="customer-card-avatar">
                                            <?= strtoupper(substr($user['name'], 0, 2)) ?>
                                        </div>
                                        <div class="customer-card-info">
                                            <h4><?= htmlspecialchars($user['name']) ?></h4>
                                            <p><i class="fas fa-envelope"></i> <?= htmlspecialchars($user['email']) ?></p>
                                            <p><i class="fas fa-phone"></i> <?= htmlspecialchars($user['contact'] ?? 'N/A') ?></p>
                                            <p><i class="fas fa-calendar"></i> Joined <?= date('M Y', strtotime($user['created_at'])) ?></p>
                                        </div>
                                    </div>
                                    <div class="customer-card-stats">
                                        <div class="customer-stat">
                                            <div class="customer-stat-value"><?= $order_count ?></div>
                                            <div class="customer-stat-label">Orders</div>
                                        </div>
                                        <div class="customer-stat">
                                            <div class="customer-stat-value">₱<?= number_format($total_spent, 0) ?></div>
                                            <div class="customer-stat-label">Total Spent</div>
                                        </div>
                                    </div>
                                    <div class="customer-card-actions">
                                        <a href="?customer_id=<?= $user['id'] ?>" class="btn btn-view">
                                            <i class="fas fa-eye"></i>
                                            View Orders
                                        </a>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-users"></i>
                        <h3>No Customers Found</h3>
                        <p>No customers have registered yet.</p>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // Notification dropdown toggle
        function toggleDropdown() {
            const dropdown = document.getElementById('notifDropdown');
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        }

        // Close dropdown when clicking outside
        window.onclick = function(event) {
            const dropdown = document.getElementById('notifDropdown');
            const bell = document.querySelector('.notification-bell button');
            
            if (dropdown && bell && !bell.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = 'none';
            }
        }

        // Mobile sidebar toggle
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('open');
        }

        // Add mobile menu button if needed
        if (window.innerWidth <= 768) {
            const header = document.querySelector('.header-section');
            const menuBtn = document.createElement('button');
            menuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            menuBtn.className = 'btn btn-primary';
            menuBtn.onclick = toggleSidebar;
            menuBtn.style.position = 'absolute';
            menuBtn.style.top = '20px';
            menuBtn.style.left = '20px';
            menuBtn.style.zIndex = '1001';
            document.body.appendChild(menuBtn);
        }

        // Auto-refresh notifications every 30 seconds
        setInterval(function() {
            if (!document.hidden) {
                fetch('users.php?ajax=notifications')
                    .then(response => response.json())
                    .then(data => {
                        if (data.unreadCount !== undefined) {
                            const badge = document.querySelector('.notification-badge');
                            const bellButton = document.querySelector('.notification-bell button');
                            
                            if (data.unreadCount > 0) {
                                if (!badge) {
                                    const newBadge = document.createElement('span');
                                    newBadge.className = 'notification-badge';
                                    newBadge.textContent = data.unreadCount;
                                    bellButton.appendChild(newBadge);
                                } else {
                                    badge.textContent = data.unreadCount;
                                }
                            } else if (badge) {
                                badge.remove();
                            }
                        }
                    })
                    .catch(error => console.log('Notification refresh failed:', error));
            }
        }, 30000);

        // Add smooth scrolling to tables
        document.querySelectorAll('.table-container').forEach(container => {
            container.addEventListener('scroll', function() {
                const scrollTop = this.scrollTop;
                const thead = this.querySelector('thead');
                if (thead) {
                    thead.style.transform = `translateY(${scrollTop}px)`;
                }
            });
        });

        // Initialize tooltips for status badges
        document.querySelectorAll('.status-badge').forEach(badge => {
            badge.addEventListener('mouseenter', function() {
                const status = this.textContent.trim().toLowerCase();
                let tooltip = document.createElement('div');
                tooltip.className = 'tooltip';
                tooltip.style.cssText = `
                    position: absolute;
                    background: rgba(0, 0, 0, 0.8);
                    color: white;
                    padding: 8px 12px;
                    border-radius: 6px;
                    font-size: 12px;
                    z-index: 1000;
                    pointer-events: none;
                    white-space: nowrap;
                `;
                
                const tooltipTexts = {
                    'pending': 'Order is waiting for approval',
                    'approved': 'Order has been approved and is being prepared',
                    'preparing': 'Order is currently being prepared',
                    'out for delivery': 'Order is on its way to customer',
                    'delivered': 'Order has been successfully delivered',
                    'rejected': 'Order was rejected',
                    'canceled': 'Order was canceled'
                };
                
                tooltip.textContent = tooltipTexts[status] || 'Order status information';
                
                document.body.appendChild(tooltip);
                
                const rect = this.getBoundingClientRect();
                tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
                tooltip.style.top = rect.top - tooltip.offsetHeight - 8 + 'px';
                
                this.tooltip = tooltip;
            });
            
            badge.addEventListener('mouseleave', function() {
                if (this.tooltip) {
                    this.tooltip.remove();
                    this.tooltip = null;
                }
            });
        });

        // Add number formatting animation for customer stats
        document.querySelectorAll('.customer-stat-value, .stat-value').forEach(element => {
            const finalValue = element.textContent;
            const isPrice = finalValue.includes('₱');
            const numericValue = parseFloat(finalValue.replace(/[₱,]/g, ''));
            
            if (!isNaN(numericValue) && numericValue > 0) {
                let currentValue = 0;
                const increment = numericValue / 30;
                const timer = setInterval(() => {
                    currentValue += increment;
                    if (currentValue >= numericValue) {
                        currentValue = numericValue;
                        clearInterval(timer);
                    }
                    
                    if (isPrice) {
                        element.textContent = '₱' + currentValue.toLocaleString('en-US', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        });
                    } else {
                        element.textContent = Math.floor(currentValue).toLocaleString();
                    }
                }, 50);
            }
        });

        // Add hover effects to customer cards
        document.querySelectorAll('.customer-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-8px)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(-4px)';
            });
        });
    </script>
</body>
</html>