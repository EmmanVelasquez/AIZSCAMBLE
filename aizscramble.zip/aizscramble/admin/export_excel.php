<?php
session_start();
require_once('../includes/db.php');

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../user/login.php");
    exit;
}

// Get export type and date range
$type = isset($_GET['type']) ? $_GET['type'] : 'sales';
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-7 days'));
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="' . ($type == 'sales' ? 'Sales_Report_' : 'Inventory_Report_') . date('Y-m-d') . '.xls"');
header('Cache-Control: max-age=0');

// Output the Excel file header
echo '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .stock-warning {
            color: red;
            font-weight: bold;
        }
        .stock-low {
            color: orange;
        }
    </style>
</head>
<body>
';

if ($type == 'sales') {
    // Daily Sales Analytics Query
    $sales_query = "
        SELECT 
            p.id AS product_id,
            p.name AS product_name,
            DATE(o.created_at) AS sale_date,
            SUM(oi.quantity) AS total_quantity,
            COUNT(DISTINCT o.id) AS transaction_count,
            SUM(oi.quantity * oi.price) AS total_sales
        FROM 
            products p
        JOIN 
            order_items oi ON p.id = oi.product_id
        JOIN 
            orders o ON oi.order_id = o.id
        WHERE 
            o.status = 'delivered'
            AND DATE(o.created_at) BETWEEN ? AND ?
        GROUP BY 
            p.id, p.name, DATE(o.created_at)
        ORDER BY 
            sale_date DESC, p.name ASC
    ";

    $stmt = $conn->prepare($sales_query);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Calculate total sales for the period
    $total_sales_query = "
        SELECT 
            SUM(oi.quantity * oi.price) AS period_total
        FROM 
            order_items oi
        JOIN 
            orders o ON oi.order_id = o.id
        WHERE 
            o.status = 'delivered'
            AND DATE(o.created_at) BETWEEN ? AND ?
    ";

    $stmt = $conn->prepare($total_sales_query);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $total_result = $stmt->get_result();
    $total_row = $total_result->fetch_assoc();
    $period_total = $total_row['period_total'] ?? 0;
    
    // Output the report title and summary
    echo '
    <h1>Sales Analytics Report</h1>
    <p>Period: ' . date('M d, Y', strtotime($start_date)) . ' to ' . date('M d, Y', strtotime($end_date)) . '</p>
    <p>Total Sales for Period: ₱' . number_format($period_total, 2) . '</p>
    
    <table>
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Date of Sale</th>
                <th>Total Quantity Sold</th>
                <th>Number of Transactions</th>
                <th>Total Sales Amount</th>
            </tr>
        </thead>
        <tbody>
    ';
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<tr>
                <td>' . htmlspecialchars($row['product_name']) . '</td>
                <td>' . date('Y-m-d', strtotime($row['sale_date'])) . '</td>
                <td>' . $row['total_quantity'] . '</td>
                <td>' . $row['transaction_count'] . '</td>
                <td>₱' . number_format($row['total_sales'], 2) . '</td>
            </tr>';
        }
    } else {
        echo '<tr><td colspan="5" style="text-align: center;">No sales data found for the selected period.</td></tr>';
    }
    
    echo '</tbody></table>';
    
} else {
    // Inventory/Stock Query
    $inventory_query = "
        SELECT 
            p.id AS product_id,
            p.name AS product_name,
            p.stock AS initial_stock,
            COALESCE(SUM(oi.quantity), 0) AS total_sold
        FROM 
            products p
        LEFT JOIN 
            order_items oi ON p.id = oi.product_id
        LEFT JOIN 
            orders o ON oi.order_id = o.id AND o.status = 'delivered'
        GROUP BY 
            p.id, p.name, p.stock
        ORDER BY 
            p.name ASC
    ";

    $result = $conn->query($inventory_query);
    
    // Output the report title
    echo '
    <h1>Inventory Report</h1>
    <p>Generated on: ' . date('M d, Y') . '</p>
    
    <table>
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Initial Stock</th>
                <th>Total Sold</th>
                <th>Current QOH</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
    ';
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $current_qoh = $row['initial_stock'] - $row['total_sold'];
            
            if ($current_qoh <= 0) {
                $status = 'Out of Stock';
                $class = 'stock-warning';
            } elseif ($current_qoh <= 5) {
                $status = 'Low Stock';
                $class = 'stock-low';
            } else {
                $status = 'In Stock';
                $class = '';
            }
            
            echo '<tr>
                <td>' . htmlspecialchars($row['product_name']) . '</td>
                <td>' . $row['initial_stock'] . '</td>
                <td>' . $row['total_sold'] . '</td>
                <td class="' . $class . '">' . $current_qoh . '</td>
                <td class="' . $class . '">' . $status . '</td>
            </tr>';
        }
    } else {
        echo '<tr><td colspan="5" style="text-align: center;">No inventory data found.</td></tr>';
    }
    
    echo '</tbody></table>';
}

// Close the HTML document
echo '
</body>
</html>
';

exit;