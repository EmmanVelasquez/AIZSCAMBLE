<?php
session_start();
include('../includes/db.php');

// Check admin privileges
if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../user/login.php");
    exit;
}

// Pagination setup
$per_page = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page > 1) ? ($page * $per_page) - $per_page : 0;

// Get total products for pagination
$total = $conn->query("SELECT COUNT(*) as total FROM products")->fetch_assoc()['total'];
$pages = ceil($total / $per_page);

// Search functionality
$search = isset($_GET['search']) ? $_GET['search'] : '';
$where = '';
if (!empty($search)) {
    $where = " WHERE name LIKE '%" . $conn->real_escape_string($search) . "%'";
}

// Fetch products with pagination
$sql = "SELECT * FROM products $where ORDER BY name ASC LIMIT $start, $per_page";
$products = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Products - Admin Panel</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto&display=swap">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            display: flex;
            background-color: hsl(343, 96%, 89%);
        }
        .left-nav {
            width: 220px;
            background-color: hsl(293, 51%, 74%);
            padding: 20px;
            min-height: 100vh;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }
        .left-nav h3 {
            color: white;
            text-align: center;
            margin-bottom: 30px;
        }
        .left-nav a {
            display: block;
            padding: 12px;
            margin-bottom: 10px;
            background-color: hsl(343, 96%, 89%);
            color: black;
            text-decoration: none;
            border-radius: 6px;
            transition: background 0.2s ease-in-out;
        }
        .left-nav a:hover {
            background-color: hsl(343, 90%, 82%);
        }
        .main-content {
            flex-grow: 1;
            padding: 40px;
        }
        h1 {
            text-align: center;
            color: #272626;
            margin-bottom: 30px;
        }
        .search-add {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .search-box {
            padding: 8px;
            width: 300px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        .add-btn {
            padding: 8px 16px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background: white;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: hsl(293, 51%, 74%);
            color: white;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        .actions a {
            display: inline-block;
            padding: 6px 12px;
            margin-right: 5px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
        }
        .edit-btn {
            background-color: #2196F3;
            color: white;
        }
        .delete-btn {
            background-color: #f44336;
            color: white;
        }
        .pagination {
            display: flex;
            justify-content: center;
            list-style: none;
            padding: 0;
        }
        .pagination a {
            color: black;
            padding: 8px 16px;
            text-decoration: none;
            border: 1px solid #ddd;
            margin: 0 4px;
        }
        .pagination a.active {
            background-color: hsl(293, 51%, 74%);
            color: white;
            border: 1px solid hsl(293, 51%, 74%);
        }
        .pagination a:hover:not(.active) {
            background-color: #ddd;
        }
        .product-image {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 4px;
        }
    </style>
</head>
<body>

<!-- Sidebar Navigation -->
<div class="left-nav">
    <div style="text-align: center; margin-bottom: 20px;">
        <img src="/assets/FavLogo.jpg" alt="Logo" style="max-width: 150px; border-radius: 75px;">
    </div>
    <h3>Admin Panel</h3>
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="orders.php">📦 Manage Orders</a>
    <a href="products.php">🛍️ Manage Products</a>
    <a href="add_product.php">➕ Add Product</a>
    <a href="stock.php">📦 Stock</a>
    <a href="ingredients.php";>🥛 Ingredients</a>
    <a href="users.php">👤 Customers</a>
    <a href="admins.php">👨‍💼 Admins</a>
    <a href="shutdown.php">🚪 Shutdown Shop</a>
    <a href="../logout.php">🚪 Logout</a>
</div>

<!-- Main Content -->
<div class="main-content">
    <h1>🛍️ Product Management</h1>
    
    <div class="search-add">
        <form method="GET" action="">
            <input type="text" name="search" class="search-box" placeholder="Search products..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit">Search</button>
            <?php if (!empty($search)): ?>
                <a href="products.php" style="margin-left: 10px;">Clear Search</a>
            <?php endif; ?>
        </form>
        <a href="add_product.php" class="add-btn">➕ Add New Product</a>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>Image</th>
                <th>Name</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Customizable</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($product = $products->fetch_assoc()): ?>
            <tr>
                <td>
                    <?php if (!empty($product['image'])): ?>
                        <img src="<?= $product['image'] ?>" class="product-image" alt="<?= htmlspecialchars($product['name']) ?>">
                    <?php else: ?>
                        <span>No Image</span>
                    <?php endif; ?>
                </td>
                <td><?= htmlspecialchars($product['name']) ?></td>
                <td>₱<?= number_format($product['price'], 2) ?></td>
                <td><?= $product['stock'] ?></td>
                <td><?= $product['is_customizable'] ? 'Yes' : 'No' ?></td>
                <td class="actions">
                    <a href="edit_product.php?id=<?= $product['id'] ?>" class="edit-btn">✏️ Edit</a>
                    <a href="delete_product.php?id=<?= $product['id'] ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this product?')">🗑️ Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    
    <?php if ($pages > 1): ?>
    <div class="pagination">
        <?php for ($i = 1; $i <= $pages; $i++): ?>
            <a href="?page=<?= $i ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>" <?= ($page == $i) ? 'class="active"' : '' ?>>
                <?= $i ?>
            </a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>

</body>
</html>