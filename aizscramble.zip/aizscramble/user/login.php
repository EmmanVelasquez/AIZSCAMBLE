<?php
session_start();
include('../includes/db.php');
include('../includes/log_activity.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email    = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password, is_admin FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($id, $hashed_password, $is_admin);
    $stmt->fetch();

    if ($stmt->num_rows > 0 && password_verify($password, $hashed_password)) {
        $_SESSION['user_id'] = $id;
        $_SESSION['is_admin'] = $is_admin;

        // ✅ LOG ACTIVITY
        $role = $is_admin ? 'admin' : 'user';
        logActivity($conn, $id, $role, 'Logged in');

        if ($is_admin) {
            header("Location: ../admin/dashboard.php");
        } else {
            header("Location: ../index.php");
        }
        exit;
    } else {
        $error = "Invalid email or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <title>Login - AIZCAmble</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --accent-gold: #F59E0B;
            --accent-gold-light: #FCD34D;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --background-deep-start: #831843;
            --background-deep-end: #BE185D;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --error-color: #EF4444;
            --shadow-pink: rgba(236, 72, 153, 0.3);
            --shadow-strong: rgba(0, 0, 0, 0.25);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: linear-gradient(135deg, var(--background-deep-start) 0%, var(--background-deep-end) 50%, var(--primary-pink-dark) 100%);
            font-family: 'Poppins', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            color: var(--text-primary);
            position: relative;
            overflow: hidden;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, var(--primary-pink) 1px, transparent 1px);
            background-size: 50px 50px;
            animation: backgroundMove 20s linear infinite;
            opacity: 0.1;
        }

        body::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(circle at 20% 80%, var(--primary-pink) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, var(--accent-purple) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, var(--secondary-pink) 0%, transparent 50%);
            opacity: 0.15;
            animation: gradientShift 15s ease-in-out infinite;
        }

        @keyframes backgroundMove {
            0% { transform: translate(0, 0) rotate(0deg); }
            100% { transform: translate(50px, 50px) rotate(360deg); }
        }

        @keyframes gradientShift {
            0%, 100% { opacity: 0.15; }
            50% { opacity: 0.25; }
        }

        .login-container {
            background: var(--surface-white);
            backdrop-filter: blur(25px);
            border: 2px solid var(--surface-glass);
            border-radius: 32px;
            box-shadow: 
                0 32px 64px var(--shadow-strong),
                0 0 0 1px rgba(255, 255, 255, 0.1) inset,
                0 2px 16px var(--shadow-pink);
            width: 480px;
            padding: 56px 48px;
            text-align: center;
            position: relative;
            animation: containerEntrance 1s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            z-index: 10;
            overflow: hidden;
        }

        .login-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink), var(--primary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        @keyframes containerEntrance {
            0% {
                opacity: 0;
                transform: translateY(50px) scale(0.9);
                filter: blur(10px);
            }
            100% {
                opacity: 1;
                transform: translateY(0) scale(1);
                filter: blur(0);
            }
        }

        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .logo-container {
            position: relative;
            margin-bottom: 40px;
        }

        .logo-wrapper {
            position: relative;
            display: inline-block;
        }

        .logo-wrapper::before {
            content: '';
            position: absolute;
            top: -8px;
            left: -8px;
            right: -8px;
            bottom: -8px;
            background: linear-gradient(45deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink), var(--primary-pink));
            background-size: 300% 300%;
            border-radius: 50%;
            animation: logoGlow 4s ease-in-out infinite;
            z-index: -1;
        }

        @keyframes logoGlow {
            0%, 100% { 
                background-position: 0% 50%;
                transform: scale(1);
            }
            50% { 
                background-position: 100% 50%;
                transform: scale(1.05);
            }
        }

        .logo {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
            border: 4px solid rgba(255, 255, 255, 0.9);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            z-index: 2;
            box-shadow: 0 8px 32px var(--shadow-pink);
        }

        .logo:hover {
            transform: scale(1.1) rotate(5deg);
            box-shadow: 0 16px 48px var(--shadow-pink);
        }

        .brand-section {
            margin-bottom: 40px;
        }

        .brand-name {
            font-size: 36px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 12px;
            letter-spacing: -1px;
            position: relative;
        }

        .brand-tagline {
            font-size: 14px;
            color: var(--text-light);
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 8px;
        }

        .welcome-text {
            font-size: 18px;
            color: var(--text-secondary);
            margin-bottom: 40px;
            font-weight: 400;
            line-height: 1.6;
        }

        .form-container {
            position: relative;
        }

        .input-group {
            position: relative;
            margin-bottom: 28px;
        }

        .input-label {
            position: absolute;
            left: 56px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
            font-size: 16px;
            font-weight: 500;
            pointer-events: none;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            z-index: 2;
        }

        .input-icon {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
            font-size: 20px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            z-index: 2;
        }

        .input-field {
            width: 100%;
            padding: 20px 20px 20px 60px;
            border: 2px solid var(--border-light);
            border-radius: 16px;
            font-size: 16px;
            font-weight: 500;
            background: rgba(255, 255, 255, 0.8);
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            outline: none;
            font-family: 'Poppins', sans-serif;
        }

        .input-field:focus,
        .input-field:not(:placeholder-shown) {
            border-color: var(--primary-pink);
            background: rgba(255, 255, 255, 1);
            box-shadow: 
                0 0 0 4px rgba(236, 72, 153, 0.1),
                0 8px 32px rgba(236, 72, 153, 0.15);
            transform: translateY(-2px);
        }

        .input-field:focus + .input-icon,
        .input-field:not(:placeholder-shown) + .input-icon {
            color: var(--primary-pink);
            transform: translateY(-50%) scale(1.1);
        }

        .input-field:focus ~ .input-label,
        .input-field:not(:placeholder-shown) ~ .input-label {
            top: -8px;
            left: 16px;
            font-size: 12px;
            color: var(--primary-pink);
            background: white;
            padding: 0 8px;
            border-radius: 8px;
            font-weight: 600;
        }

        .input-field::placeholder {
            color: transparent;
        }

        .error-message {
            background: linear-gradient(135deg, #FEE2E2, #FECACA);
            color: var(--error-color);
            padding: 20px;
            border-radius: 16px;
            margin-bottom: 28px;
            font-size: 14px;
            font-weight: 600;
            text-align: left;
            border: 2px solid #FCA5A5;
            position: relative;
            animation: errorShake 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            box-shadow: 0 8px 32px rgba(239, 68, 68, 0.2);
        }

        @keyframes errorShake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-8px); }
            75% { transform: translateX(8px); }
        }

        .error-message::before {
            content: '⚠️';
            margin-right: 12px;
            font-size: 16px;
        }

        .login-button {
            background: linear-gradient(135deg, var(--primary-pink) 0%, var(--primary-pink-dark) 50%, var(--accent-purple) 100%);
            color: white;
            border: none;
            border-radius: 16px;
            padding: 20px 32px;
            width: 100%;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-family: 'Poppins', sans-serif;
            box-shadow: 0 8px 32px var(--shadow-pink);
        }

        .login-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .login-button:hover::before {
            left: 100%;
        }

        .login-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 16px 48px var(--shadow-pink);
            background: linear-gradient(135deg, var(--primary-pink-dark) 0%, var(--primary-pink) 50%, var(--accent-purple-light) 100%);
        }

        .login-button:active {
            transform: translateY(-1px);
        }

        .divider {
            display: flex;
            align-items: center;
            margin: 40px 0;
            color: var(--text-light);
            font-size: 14px;
            font-weight: 600;
        }

        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            height: 2px;
            background: linear-gradient(to right, transparent, var(--primary-pink), transparent);
            opacity: 0.3;
        }

        .divider span {
            padding: 0 24px;
            background: var(--surface-white);
            border-radius: 20px;
            position: relative;
        }

        .register-section {
            margin-top: 32px;
            padding: 24px;
            background: rgba(236, 72, 153, 0.05);
            border-radius: 20px;
            border: 1px solid rgba(236, 72, 153, 0.1);
        }

        .register-link {
            font-size: 16px;
            color: var(--text-secondary);
            font-weight: 500;
        }

        .register-link a {
            color: var(--primary-pink);
            text-decoration: none;
            font-weight: 700;
            position: relative;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .register-link a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 3px;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            transition: width 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border-radius: 2px;
        }

        .register-link a:hover::after {
            width: 100%;
        }

        .register-link a:hover {
            color: var(--primary-pink-dark);
            transform: translateY(-1px);
        }

        /* Floating particles animation */
        .particle {
            position: absolute;
            border-radius: 50%;
            background: linear-gradient(45deg, var(--primary-pink), var(--secondary-pink));
            animation: floatParticle 20s infinite linear;
            pointer-events: none;
            opacity: 0.6;
        }

        @keyframes floatParticle {
            0% {
                transform: translateY(100vh) rotate(0deg) scale(0);
                opacity: 0;
            }
            10% {
                opacity: 0.6;
                transform: translateY(90vh) rotate(36deg) scale(1);
            }
            90% {
                opacity: 0.6;
                transform: translateY(-10vh) rotate(324deg) scale(1);
            }
            100% {
                transform: translateY(-100vh) rotate(360deg) scale(0);
                opacity: 0;
            }
        }

        /* Additional pink-themed particles */
        .particle-pink {
            position: absolute;
            border-radius: 50%;
            background: linear-gradient(45deg, var(--secondary-pink), var(--primary-pink-light));
            animation: floatParticlePink 25s infinite linear;
            pointer-events: none;
            opacity: 0.4;
        }

        @keyframes floatParticlePink {
            0% {
                transform: translateY(100vh) rotate(0deg) scale(0);
                opacity: 0;
            }
            15% {
                opacity: 0.4;
                transform: translateY(85vh) rotate(54deg) scale(1);
            }
            85% {
                opacity: 0.4;
                transform: translateY(-15vh) rotate(306deg) scale(1);
            }
            100% {
                transform: translateY(-100vh) rotate(360deg) scale(0);
                opacity: 0;
            }
        }

        /* Responsive design */
        @media (max-width: 520px) {
            .login-container {
                width: 95%;
                padding: 40px 32px;
                margin: 20px;
                border-radius: 24px;
            }
            
            .brand-name {
                font-size: 28px;
            }
            
            .input-field {
                padding: 18px 18px 18px 55px;
                font-size: 15px;
            }
            
            .input-icon {
                font-size: 18px;
                left: 18px;
            }

            .login-button {
                padding: 18px 28px;
                font-size: 16px;
            }
        }

        /* Loading state for button */
        .login-button.loading {
            pointer-events: none;
            opacity: 0.8;
            background: linear-gradient(135deg, var(--text-light), var(--text-light));
        }

        .login-button.loading::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 24px;
            height: 24px;
            margin: -12px 0 0 -12px;
            border: 3px solid transparent;
            border-top: 3px solid white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Success animation */
        .success-checkmark {
            display: none;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 24px;
            height: 24px;
        }

        .success-checkmark::after {
            content: '✓';
            color: var(--success-color);
            font-size: 20px;
            font-weight: bold;
            animation: checkmarkPop 0.3s ease-out;
        }

        @keyframes checkmarkPop {
            0% { transform: scale(0); }
            100% { transform: scale(1); }
        }

        /* Enhanced glassmorphism effect */
        .login-container::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.05) 50%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
            pointer-events: none;
            border-radius: 32px;
        }

        @keyframes shimmer {
            0%, 100% { transform: translateX(-100%); }
            50% { transform: translateX(100%); }
        }

        /* Enhanced focus states */
        .input-field:focus {
            border-color: var(--primary-pink);
            box-shadow: 
                0 0 0 4px rgba(236, 72, 153, 0.1),
                0 8px 32px rgba(236, 72, 153, 0.2),
                0 0 20px rgba(236, 72, 153, 0.3);
        }

        /* Improved button hover effects */
        .login-button:hover {
            background: linear-gradient(135deg, var(--primary-pink-dark) 0%, var(--primary-pink) 30%, var(--secondary-pink) 70%, var(--accent-purple-light) 100%);
            box-shadow: 
                0 16px 48px var(--shadow-pink),
                0 0 30px rgba(236, 72, 153, 0.4);
        }

        /* Additional visual enhancements */
        .brand-section::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 200px;
            height: 200px;
            background: radial-gradient(circle, rgba(236, 72, 153, 0.1) 0%, transparent 70%);
            border-radius: 50%;
            z-index: -1;
            animation: brandGlow 4s ease-in-out infinite;
        }

        @keyframes brandGlow {
            0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 0.5; }
            50% { transform: translate(-50%, -50%) scale(1.2); opacity: 0.8; }
        }
    </style>
</head>
<body>
    <!-- Enhanced floating particles with pink theme -->
    <div class="particle" style="left: 5%; width: 6px; height: 6px; animation-delay: 0s;"></div>
    <div class="particle-pink" style="left: 15%; width: 4px; height: 4px; animation-delay: 3s;"></div>
    <div class="particle" style="left: 25%; width: 8px; height: 8px; animation-delay: 6s;"></div>
    <div class="particle-pink" style="left: 35%; width: 5px; height: 5px; animation-delay: 9s;"></div>
    <div class="particle" style="left: 45%; width: 7px; height: 7px; animation-delay: 12s;"></div>
    <div class="particle-pink" style="left: 55%; width: 4px; height: 4px; animation-delay: 15s;"></div>
    <div class="particle" style="left: 65%; width: 6px; height: 6px; animation-delay: 18s;"></div>
    <div class="particle-pink" style="left: 75%; width: 5px; height: 5px; animation-delay: 21s;"></div>
    <div class="particle" style="left: 85%; width: 7px; height: 7px; animation-delay: 24s;"></div>
    <div class="particle-pink" style="left: 95%; width: 4px; height: 4px; animation-delay: 27s;"></div>

    <div class="login-container">
        <div class="logo-container">
            <div class="logo-wrapper">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo" class="logo">
            </div>
        </div>
        
        <div class="brand-section">
            <div class="brand-tagline">Premium Experience</div>
            <h1 class="brand-name">AIZCAmble</h1>
            <p class="welcome-text">Welcome back! Sign in to access your premium account</p>
        </div>

        <?php if (!empty($error)): ?>
            <div class="error-message"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" class="form-container" id="loginForm">
            <div class="input-group">
                <input type="email" name="email" class="input-field" placeholder="Enter your email" required>
                <i class="fas fa-envelope input-icon"></i>
                <label class="input-label">Email Address</label>
            </div>
            
            <div class="input-group">
                <input type="password" name="password" class="input-field" placeholder="Enter your password" required>
                <i class="fas fa-lock input-icon"></i>
                <label class="input-label">Password</label>
            </div>

            <button type="submit" class="login-button" id="loginBtn">
                <span>Sign In Securely</span>
                <div class="success-checkmark"></div>
            </button>
        </form>

        <div class="divider">
            <span>New Member?</span>
        </div>

        <div class="register-section">
            <div class="register-link">
                Don't have an account? <a href="register.php">Join AIZCAmble Today</a>
            </div>
        </div>
    </div>

    <script>
        // Enhanced form submission with loading states
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const btn = document.getElementById('loginBtn');
            const btnText = btn.querySelector('span');
            
            btn.classList.add('loading');
            btnText.style.opacity = '0';
            
            // Simulate processing time for better UX
            setTimeout(() => {
                btnText.textContent = 'Authenticating...';
                btnText.style.opacity = '1';
            }, 300);
        });

        // Enhanced input animations
        document.querySelectorAll('.input-field').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.style.transform = 'translateY(-2px)';
                this.parentElement.style.transition = 'all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.style.transform = 'translateY(0)';
            });

            // Real-time validation feedback
            input.addEventListener('input', function() {
                if (this.type === 'email' && this.value) {
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (emailRegex.test(this.value)) {
                        this.style.borderColor = 'var(--success-color)';
                        this.nextElementSibling.style.color = 'var(--success-color)';
                    } else {
                        this.style.borderColor = 'var(--error-color)';
                        this.nextElementSibling.style.color = 'var(--error-color)';
                    }
                }
            });
        });

        // Enhanced ripple effect for button
        document.querySelector('.login-button').addEventListener('click', function(e) {
            if (this.classList.contains('loading')) return;
            
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.cssText = `
                width: ${size}px;
                height: ${size}px;
                left: ${x}px;
                top: ${y}px;
                position: absolute;
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.4);
                transform: scale(0);
                animation: rippleEffect 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275);
                pointer-events: none;
            `;
            
            this.appendChild(ripple);
            
            setTimeout(() => ripple.remove(), 800);
        });

        // Add enhanced ripple animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes rippleEffect {
                0% {
                    transform: scale(0);
                    opacity: 1;
                }
                100% {
                    transform: scale(4);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);

        // Logo interaction with pink theme
        document.querySelector('.logo').addEventListener('click', function() {
            this.style.animation = 'none';
            this.style.transform = 'scale(1.2) rotate(360deg)';
            this.style.boxShadow = '0 20px 60px var(--shadow-pink)';
            
            setTimeout(() => {
                this.style.animation = '';
                this.style.transform = '';
                this.style.boxShadow = '';
            }, 500);
        });

        // Enhanced parallax effect for background elements
        document.addEventListener('mousemove', function(e) {
            const mouseX = e.clientX / window.innerWidth;
            const mouseY = e.clientY / window.innerHeight;
            
            // Move particles based on mouse position
            document.querySelectorAll('.particle, .particle-pink').forEach((particle, index) => {
                const speed = (index % 3 + 1) * 0.5;
                const x = (mouseX - 0.5) * speed * 20;
                const y = (mouseY - 0.5) * speed * 20;
                particle.style.transform = `translate(${x}px, ${y}px)`;
            });
            
            // Subtle container movement
            const container = document.querySelector('.login-container');
            const moveX = (mouseX - 0.5) * 10;
            const moveY = (mouseY - 0.5) * 10;
            container.style.transform = `translate(${moveX}px, ${moveY}px)`;
        });

        // Enhanced brand section animation
        document.querySelector('.brand-name').addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.05)';
            this.style.textShadow = '0 0 20px rgba(236, 72, 153, 0.5)';
        });

        document.querySelector('.brand-name').addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
            this.style.textShadow = 'none';
        });

        // Add dynamic background color shifts
        setInterval(() => {
            const hue = Math.random() * 30 + 320; // Pink to purple range
            document.documentElement.style.setProperty('--dynamic-bg', `hsl(${hue}, 70%, 15%)`);
        }, 5000);

        // Enhanced input focus effects
        document.querySelectorAll('.input-field').forEach(input => {
            input.addEventListener('focus', function() {
                // Add glow effect to the entire input group
                this.parentElement.style.filter = 'drop-shadow(0 0 10px rgba(236, 72, 153, 0.3))';
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.style.filter = 'none';
            });
        });
    </script>
</body>
</html>