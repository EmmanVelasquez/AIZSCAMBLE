<?php
session_start();
include('../includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("HTTP/1.1 403 Forbidden");
    die(json_encode(['success' => false, 'message' => 'Unauthorized']));
}

$order_id = $_POST['order_id'] ?? null;
$reason = $_POST['reason'] ?? '';

if (!$order_id) {
    die(json_encode(['success' => false, 'message' => 'Invalid order ID']));
}

// Verify the order belongs to the user
$stmt = $conn->prepare("SELECT user_id FROM orders WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();
$order = $result->fetch_assoc();

if (!$order || $order['user_id'] != $_SESSION['user_id']) {
    die(json_encode(['success' => false, 'message' => 'Order not found or unauthorized']));
}

// Update status to canceled
$update = $conn->prepare("UPDATE orders SET status = 'canceled', cancel_reason = ? WHERE id = ?");
$update->bind_param("si", $reason, $order_id);

if ($update->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
?>