<?php
function logActivity($conn, $userId, $role, $action) {
    if (!$conn || !$userId || !$role || !$action) return false;

   $stmt = $conn->prepare("INSERT INTO ActivityLog (user_id, role, action) VALUES (?, ?, ?)");

    if ($stmt) {
        $stmt->bind_param("iss", $userId, $role, $action);
        $success = $stmt->execute();
        $stmt->close();
        return $success;
    }
    return false;
}
?>
