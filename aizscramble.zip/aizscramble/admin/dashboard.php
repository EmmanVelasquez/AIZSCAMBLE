<?php
ini_set('memory_limit', '256M');

session_start();
require('../includes/db.php');
require_once('../includes/notify_helper.php'); // Added notification helper

if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../user/login.php");
    exit;
}

// Mark notifications as read if requested
if (isset($_GET['mark_read']) && $_GET['mark_read'] == 'all') {
    $conn->query("UPDATE AdminNotifications SET IsRead = 1 WHERE IsRead = 0");
    header("Location: dashboard.php");
    exit;
}

// Fetch notifications for the dropdown
$notifQuery = $conn->query("SELECT * FROM AdminNotifications ORDER BY CreatedAt DESC LIMIT 5");
$unreadCount = $conn->query("SELECT COUNT(*) as total FROM AdminNotifications WHERE IsRead = 0")->fetch_assoc()['total'];

// Dashboard stats
$total_orders = $conn->query("SELECT COUNT(*) as count FROM orders")->fetch_assoc()['count'];
$pending_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status = 'pending'")->fetch_assoc()['count'];
$total_revenue = $conn->query("SELECT SUM(total_amount) as total FROM orders WHERE status = 'delivered'")->fetch_assoc()['total'] ?? 0;
$total_customers = $conn->query("SELECT COUNT(*) as count FROM users WHERE is_admin = 0")->fetch_assoc()['count'];

// Recent orders
$recent_orders = $conn->query("SELECT o.*, u.name as customer_name FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 5");

// Low stock products
$low_stock_products = $conn->query("SELECT * FROM products WHERE stock <= 5 ORDER BY stock ASC LIMIT 5");

// Low stock ingredients
$low_stock_ingredients = $conn->query("SELECT * FROM ingredients WHERE quantity <= 5 ORDER BY quantity ASC LIMIT 5");

// Sales by day (last 7 days)
$sales_by_day_query = "
    SELECT 
        DATE(created_at) as order_date,
        COUNT(*) as order_count,
        SUM(total_amount) as total_sales
    FROM orders
    WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    GROUP BY DATE(created_at)
    ORDER BY order_date DESC
";
$sales_by_day = $conn->query($sales_by_day_query);

// Top selling products
$top_products_query = "
    SELECT 
        p.name,
        SUM(oi.quantity) as total_sold
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    JOIN orders o ON oi.order_id = o.id
    WHERE o.status = 'delivered'
    GROUP BY oi.product_id
    ORDER BY total_sold DESC
    LIMIT 5
";
$top_products = $conn->query($top_products_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - AIZCAmble</title>
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --error-color: #EF4444;
            --shadow-pink: rgba(236, 72, 153, 0.2);
            --shadow-strong: rgba(0, 0, 0, 0.1);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-gradient-start) 0%, var(--background-gradient-end) 100%);
            min-height: 100vh;
            display: flex;
            color: var(--text-primary);
            position: relative;
            overflow-x: hidden;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, var(--primary-pink) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, var(--accent-purple) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, var(--secondary-pink) 0%, transparent 50%);
            opacity: 0.05;
            z-index: -1;
            animation: backgroundFloat 20s ease-in-out infinite;
        }

        @keyframes backgroundFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(-20px, -20px) scale(1.05); }
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary-pink) 0%, var(--primary-pink-dark) 100%);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--border-light);
            box-shadow: 4px 0 20px var(--shadow-pink);
            padding: 0;
            min-height: 100vh;
            position: relative;
            overflow: hidden;
        }

        .sidebar::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.1) 50%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
        }

        @keyframes shimmer {
            0%, 100% { transform: translateX(-100%); }
            50% { transform: translateX(100%); }
        }

        .logo-section {
            text-align: center;
            padding: 32px 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            position: relative;
            z-index: 2;
        }

        .logo-container {
            position: relative;
            display: inline-block;
            margin-bottom: 16px;
        }

        .logo-container::before {
            content: '';
            position: absolute;
            top: -8px;
            left: -8px;
            right: -8px;
            bottom: -8px;
            background: linear-gradient(45deg, rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0.1));
            border-radius: 50%;
            animation: logoGlow 2s ease-in-out infinite;
        }

        @keyframes logoGlow {
            0%, 100% { transform: scale(1); opacity: 0.7; }
            50% { transform: scale(1.05); opacity: 1; }
        }

        .logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(255, 255, 255, 0.9);
            object-fit: cover;
            position: relative;
            z-index: 2;
            transition: all 0.3s ease;
        }

        .logo:hover {
            transform: scale(1.1) rotate(5deg);
        }

        .brand-name {
            color: white;
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 8px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .admin-title {
            color: rgba(255, 255, 255, 0.9);
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-menu {
            padding: 24px 0;
            position: relative;
            z-index: 2;
        }

        .nav-item {
            display: block;
            padding: 16px 24px;
            margin: 8px 16px;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            border-radius: 16px;
            font-weight: 500;
            font-size: 15px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
        }

        .nav-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .nav-item:hover::before {
            left: 100%;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(8px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item.active {
            background: rgba(255, 255, 255, 0.25);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        .main-content {
            flex: 1;
            padding: 32px;
            overflow-y: auto;
            position: relative;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            padding: 24px 32px;
            border-radius: 24px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
        }

        .page-title {
            font-size: 32px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin: 0;
        }

        .page-subtitle {
            color: var(--text-secondary);
            font-size: 16px;
            font-weight: 500;
            margin-top: 4px;
        }

        /* Notification Bell */
        .notification-bell {
            position: relative;
            display: inline-block;
        }

        .notification-btn {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border: none;
            border-radius: 16px;
            padding: 16px;
            color: white;
            font-size: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 8px 25px var(--shadow-pink);
            position: relative;
            overflow: hidden;
        }

        .notification-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s ease;
        }

        .notification-btn:hover::before {
            left: 100%;
        }

        .notification-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 35px var(--shadow-pink);
        }

        .notification-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
            border-radius: 50%;
            padding: 6px 8px;
            font-size: 12px;
            font-weight: 700;
            min-width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }

        .notification-dropdown {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            margin-top: 8px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            width: 380px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
            border: 1px solid var(--border-light);
            z-index: 1000;
            overflow: hidden;
            animation: dropdownSlide 0.3s ease-out;
        }

        @keyframes dropdownSlide {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .notification-header {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            padding: 20px 24px;
            font-weight: 600;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .notification-list {
            max-height: 400px;
            overflow-y: auto;
            padding: 0;
            margin: 0;
            list-style: none;
        }

        .notification-item {
            padding: 20px 24px;
            border-bottom: 1px solid var(--border-light);
            transition: background 0.2s ease;
        }

        .notification-item:hover {
            background: rgba(236, 72, 153, 0.05);
        }

        .notification-item:last-child {
            border-bottom: none;
        }

        .notification-item.unread {
            background: linear-gradient(90deg, rgba(236, 72, 153, 0.1), transparent);
            border-left: 4px solid var(--primary-pink);
        }

        .notification-footer {
            padding: 16px 24px;
            text-align: center;
            border-top: 1px solid var(--border-light);
            background: rgba(236, 72, 153, 0.02);
        }

        .notification-footer a {
            color: var(--primary-pink);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.2s ease;
        }

        .notification-footer a:hover {
            color: var(--primary-pink-dark);
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 24px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 32px;
            text-align: center;
            border: 1px solid var(--border-light);
            box-shadow: 0 8px 32px var(--shadow-pink);
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .stat-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 60px var(--shadow-pink);
        }

        .stat-icon {
            width: 64px;
            height: 64px;
            border-radius: 20px;
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 28px;
            color: white;
            box-shadow: 0 8px 25px var(--shadow-pink);
        }

        .stat-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--text-secondary);
            margin-bottom: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat-value {
            font-size: 36px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 8px;
        }

        .stat-subtitle {
            font-size: 14px;
            color: var(--text-light);
            font-weight: 500;
        }

        /* Data Cards */
        .data-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 24px;
            margin-bottom: 32px;
        }

        .data-card {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 32px;
            border: 1px solid var(--border-light);
            box-shadow: 0 8px 32px var(--shadow-pink);
            transition: all 0.3s ease;
        }

        .data-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 16px 48px var(--shadow-pink);
        }

        .data-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
            padding-bottom: 16px;
            border-bottom: 2px solid var(--border-light);
        }

        .data-card-title {
            font-size: 20px;
            font-weight: 700;
            color: var(--text-primary);
            display: flex;
            align-items: center;
        }

        .data-card-title i {
            margin-right: 12px;
            color: var(--primary-pink);
        }

        /* Tables */
        .table-container {
            overflow-x: auto;
            border-radius: 16px;
            border: 1px solid var(--border-light);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }

        th {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            padding: 16px 20px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        th:first-child {
            border-top-left-radius: 16px;
        }

        th:last-child {
            border-top-right-radius: 16px;
        }

        td {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border-light);
            font-weight: 500;
        }

        tr:hover {
            background: rgba(236, 72, 153, 0.05);
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:last-child td:first-child {
            border-bottom-left-radius: 16px;
        }

        tr:last-child td:last-child {
            border-bottom-right-radius: 16px;
        }

        /* Status Badges */
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-pending {
            background: linear-gradient(135deg, #FEF3C7, #FDE68A);
            color: #92400E;
        }

        .status-approved, .status-delivered {
            background: linear-gradient(135deg, #D1FAE5, #A7F3D0);
            color: #065F46;
        }

        .status-cancelled {
            background: linear-gradient(135deg, #FEE2E2, #FECACA);
            color: #991B1B;
        }

        .stock-warning {
            color: var(--error-color);
            font-weight: 700;
        }

        .stock-low {
            color: var(--warning-color);
            font-weight: 600;
        }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            padding: 10px 20px;
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            text-decoration: none;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px var(--shadow-pink);
            background: linear-gradient(135deg, var(--primary-pink-dark), var(--primary-pink));
        }

        .btn i {
            margin-right: 8px;
        }

        .btn-secondary {
            background: linear-gradient(135deg, var(--accent-purple), var(--accent-purple-light));
            box-shadow: 0 4px 15px rgba(139, 92, 246, 0.3);
        }

        .btn-secondary:hover {
            box-shadow: 0 8px 25px rgba(139, 92, 246, 0.4);
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 12px;
            justify-content: flex-end;
            margin-top: 20px;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .sidebar {
                width: 240px;
            }
            
            .stats-grid {
                grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            }
            
            .data-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                min-height: auto;
                position: fixed;
                top: 0;
                left: -100%;
                z-index: 1000;
                transition: left 0.3s ease;
            }
            
            .sidebar.open {
                left: 0;
            }
            
            .main-content {
                padding: 20px;
            }
            
            .header-section {
                flex-direction: column;
                gap: 16px;
                text-align: center;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .notification-dropdown {
                width: 320px;
                right: -20px;
            }
        }

        /* Loading Animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-light);
        }

        .empty-state i {
            font-size: 48px;
            margin-bottom: 16px;
            color: var(--primary-pink);
            opacity: 0.5;
        }

        .empty-state h3 {
            font-size: 18px;
            margin-bottom: 8px;
            color: var(--text-secondary);
        }

        .empty-state p {
            font-size: 14px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <div class="logo-container">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo" class="logo">
            </div>
            <div class="brand-name">AIZCAmble</div>
            <div class="admin-title">Admin Panel</div>
        </div>

        <nav class="nav-menu">
            <a href="dashboard.php" class="nav-item active">
                <i class="fas fa-chart-line"></i>
                Dashboard
            </a>
            <a href="orders.php" class="nav-item">
                <i class="fas fa-shopping-bag"></i>
                Manage Orders
            </a>
            <a href="add_product.php" class="nav-item">
                <i class="fas fa-plus-circle"></i>
                Add Product
            </a>
            <a href="stock.php" class="nav-item">
                <i class="fas fa-boxes"></i>
                Stock Management
            </a>
            <a href="sales_analytics.php" class="nav-item">
                <i class="fas fa-chart-bar"></i>
                Sales Analytics
            </a>
            <a href="users.php" class="nav-item">
                <i class="fas fa-users"></i>
                Customers
            </a>
            <a href="ingredients.php" class="nav-item">
                <i class="fas fa-flask"></i>
                Ingredients
            </a>
            <a href="admins.php" class="nav-item">
                <i class="fas fa-user-shield"></i>
                Admins
            </a>
            <a href="shutdown.php" class="nav-item">
                <i class="fas fa-power-off"></i>
                Shutdown Shop
            </a>
            <a href="activity_log.php" class="nav-item">
                <i class="fas fa-history"></i>
                Activity History
            </a>
            <a href="notifications.php" class="nav-item">
                <i class="fas fa-bell"></i>
                Notifications
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header-section">
            <div>
                <h1 class="page-title">Dashboard Overview</h1>
                <p class="page-subtitle">Welcome back! Here's what's happening with your business today.</p>
            </div>
            
            <!-- Notification Bell -->
            <div class="notification-bell">
                <button class="notification-btn" onclick="toggleDropdown()">
                    <i class="fas fa-bell"></i>
                    <?php if ($unreadCount > 0): ?>
                        <span class="notification-badge"><?= $unreadCount ?></span>
                    <?php endif; ?>
                </button>
                
                <div id="notifDropdown" class="notification-dropdown">
                    <div class="notification-header">
                        <span><i class="fas fa-bell"></i> Notifications</span>
                        <?php if ($unreadCount > 0): ?>
                            <a href="dashboard.php?mark_read=all" style="color: white; font-size: 12px;">
                                <i class="fas fa-check-double"></i> Mark all read
                            </a>
                        <?php endif; ?>
                    </div>
                    
                    <ul class="notification-list">
                        <?php if ($notifQuery->num_rows > 0): ?>
                            <?php while ($notif = $notifQuery->fetch_assoc()): ?>
                                <li class="notification-item <?= $notif['IsRead'] ? '' : 'unread' ?>">
                                    <strong><?= htmlspecialchars($notif['Title']) ?></strong><br>
                                    <small style="color: var(--text-secondary);"><?= htmlspecialchars($notif['message']) ?></small><br>
                                    <small style="color: var(--text-light);">
                                        <i class="fas fa-clock"></i> 
                                        <?= date('M d, Y h:i A', strtotime($notif['CreatedAt'])) ?>
                                    </small>
                                </li>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <li class="notification-item">
                                <div class="empty-state">
                                    <i class="fas fa-bell-slash"></i>
                                    <p>No notifications yet</p>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                    
                    <div class="notification-footer">
                        <a href="notifications.php">
                            <i class="fas fa-external-link-alt"></i> View All Notifications
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <div class="stat-title">Total Orders</div>
                <div class="stat-value"><?= number_format($total_orders) ?></div>
                <div class="stat-subtitle">All time orders</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-title">Pending Orders</div>
                <div class="stat-value"><?= number_format($pending_orders) ?></div>
                <div class="stat-subtitle">Awaiting processing</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-peso-sign"></i>
                </div>
                <div class="stat-title">Total Revenue</div>
                <div class="stat-value">₱<?= number_format($total_revenue, 0) ?></div>
                <div class="stat-subtitle">From completed orders</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-title">Total Customers</div>
                <div class="stat-value"><?= number_format($total_customers) ?></div>
                <div class="stat-subtitle">Registered users</div>
            </div>
        </div>

        <!-- Data Grid -->
        <div class="data-grid">
            <!-- Recent Orders -->
            <div class="data-card">
                <div class="data-card-header">
                    <h3 class="data-card-title">
                        <i class="fas fa-shopping-bag"></i>
                        Recent Orders
                    </h3>
                </div>
                
                <?php if ($recent_orders->num_rows > 0): ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Customer</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($order = $recent_orders->fetch_assoc()): ?>
                                    <tr>
                                        <td><strong>#<?= $order['id'] ?></strong></td>
                                        <td><?= htmlspecialchars($order['customer_name']) ?></td>
                                        <td><strong>₱<?= number_format($order['total_amount'], 2) ?></strong></td>
                                        <td>
                                            <span class="status-badge status-<?= $order['status'] ?>">
                                                <?= ucfirst($order['status']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="orders.php?id=<?= $order['id'] ?>" class="btn">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="action-buttons">
                        <a href="orders.php" class="btn btn-secondary">
                            <i class="fas fa-list"></i> View All Orders
                        </a>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-shopping-bag"></i>
                        <h3>No Orders Yet</h3>
                        <p>Orders will appear here once customers start placing them.</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Low Stock Ingredients -->
            <div class="data-card">
                <div class="data-card-header">
                    <h3 class="data-card-title">
                        <i class="fas fa-exclamation-triangle"></i>
                        Low Stock Ingredients
                    </h3>
                </div>
                
                <?php if ($low_stock_ingredients->num_rows > 0): ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Ingredient</th>
                                    <th>Stock</th>
                                    <th>Unit</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($ingredient = $low_stock_ingredients->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($ingredient['name']) ?></td>
                                        <td>
                                            <span class="<?= $ingredient['quantity'] <= 2 ? 'stock-warning' : 'stock-low' ?>">
                                                <strong><?= $ingredient['quantity'] ?></strong>
                                            </span>
                                        </td>
                                        <td><?= htmlspecialchars($ingredient['unit']) ?></td>
                                        <td>
                                            <a href="stock.php" class="btn">
                                                <i class="fas fa-edit"></i> Update
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-check-circle"></i>
                        <h3>All Stock Levels Good</h3>
                        <p>No ingredients are running low on stock.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Additional Data Grid -->
        <div class="data-grid">
            <!-- Top Selling Products -->
            <div class="data-card">
                <div class="data-card-header">
                    <h3 class="data-card-title">
                        <i class="fas fa-trophy"></i>
                        Top Selling Products
                    </h3>
                </div>
                
                <?php if ($top_products->num_rows > 0): ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Units Sold</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($product = $top_products->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($product['name']) ?></td>
                                        <td><strong><?= number_format($product['total_sold']) ?></strong></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-chart-bar"></i>
                        <h3>No Sales Data</h3>
                        <p>Sales data will appear here once orders are completed.</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Recent Sales -->
            <div class="data-card">
                <div class="data-card-header">
                    <h3 class="data-card-title">
                        <i class="fas fa-calendar-week"></i>
                        Recent Sales (Last 7 Days)
                    </h3>
                </div>
                
                <?php if ($sales_by_day->num_rows > 0): ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Orders</th>
                                    <th>Total Sales</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($day = $sales_by_day->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= date('M j, Y', strtotime($day['order_date'])) ?></td>
                                        <td><strong><?= number_format($day['order_count']) ?></strong></td>
                                        <td><strong>₱<?= number_format($day['total_sales'], 2) ?></strong></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-calendar-times"></i>
                        <h3>No Recent Sales</h3>
                        <p>No sales recorded in the last 7 days.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // Notification dropdown toggle
        function toggleDropdown() {
            const dropdown = document.getElementById('notifDropdown');
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        }

        // Close dropdown when clicking outside
        window.addEventListener('click', function(event) {
            const dropdown = document.getElementById('notifDropdown');
            const bell = document.querySelector('.notification-btn');
            if (!bell.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = 'none';
            }
        });

        // Add loading states to buttons
        document.querySelectorAll('.btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                if (this.href && !this.href.includes('#')) {
                    const originalText = this.innerHTML;
                    this.innerHTML = '<div class="loading"></div> Loading...';
                    this.style.pointerEvents = 'none';
                    
                    // Reset after 3 seconds if page doesn't change
                    setTimeout(() => {
                        this.innerHTML = originalText;
                        this.style.pointerEvents = 'auto';
                    }, 3000);
                }
            });
        });

        // Add hover effects to stat cards
        document.querySelectorAll('.stat-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-8px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });

        // Auto-refresh notifications every 30 seconds
        setInterval(function() {
            // You can implement AJAX refresh here if needed
            console.log('Checking for new notifications...');
        }, 30000);

        // Mobile sidebar toggle (for responsive design)
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('open');
        }

        // Add mobile menu button if needed
        if (window.innerWidth <= 768) {
            const header = document.querySelector('.header-section');
            const menuBtn = document.createElement('button');
            menuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            menuBtn.className = 'btn';
            menuBtn.onclick = toggleSidebar;
            header.insertBefore(menuBtn, header.firstChild);
        }
    </script>
</body>
</html>