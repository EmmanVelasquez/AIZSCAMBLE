<?php
ob_start(); // Start output buffer
$response = ['success' => true, 'message' => 'status updated'];
echo json_encode($response);
$debug = ob_get_clean(); // Capture output
error_log("DEBUG OUTPUT: " . $debug); // Log to server error log

function deductIngredientsForOrder($conn, $order_id, $admin_id) {
    $deducted = [];

    // Get all items in the order
    $item_stmt = $conn->prepare("SELECT product_id, quantity FROM order_items WHERE order_id = ?");
    $item_stmt->bind_param("i", $order_id);
    $item_stmt->execute();
    $items_result = $item_stmt->get_result();

    while ($item = $items_result->fetch_assoc()) {
        $product_id = $item['product_id'];
        $ordered_quantity = $item['quantity'];

        // Get the ingredients for the product
        $ing_stmt = $conn->prepare("SELECT ingredient_id, quantity FROM product_ingredients WHERE product_id = ?");
        $ing_stmt->bind_param("i", $product_id);
        $ing_stmt->execute();
        $ingredients_result = $ing_stmt->get_result();

        while ($ingredient = $ingredients_result->fetch_assoc()) {
            $ingredient_id = $ingredient['ingredient_id'];
            $required_per_product = $ingredient['quantity'];
            $quantity_to_deduct = $required_per_product * $ordered_quantity;

            // Get current stock and unit
            $stock_stmt = $conn->prepare("SELECT stock, unit, name FROM ingredients WHERE id = ?");
            $stock_stmt->bind_param("i", $ingredient_id);
            $stock_stmt->execute();
            $stock_result = $stock_stmt->get_result();

            if ($stock_result->num_rows === 0) {
                return ['success' => false, 'message' => "Ingredient ID $ingredient_id not found."];
            }

            $stock = $stock_result->fetch_assoc();
            $before_qty = $stock['stock']; // Correct column name
            $unit = $stock['unit'];
            $ingredient_name = $stock['name'];

            // Calculate new stock
            $after_qty = $before_qty - $quantity_to_deduct;
            if ($after_qty < 0) $after_qty = 0;

            // Update ingredient stock
            $update_stmt = $conn->prepare("UPDATE ingredients SET stock = ? WHERE id = ?");
            $update_stmt->bind_param("di", $after_qty, $ingredient_id);
            $update_stmt->execute();

            // Insert into ingredient_movements
            $movement_stmt = $conn->prepare("INSERT INTO ingredient_movements (
                ingredient_id, quantity_before, sales_quantity, current_stock, restock_quantity, movement_date, created_by, notes
            ) VALUES (?, ?, ?, ?, 0, NOW(), ?, ?)");
            $note = "Deducted for Order #$order_id";
            $movement_stmt->bind_param("idddis", $ingredient_id, $before_qty, $quantity_to_deduct, $after_qty, $admin_id, $note);
            $movement_stmt->execute();

            // Track deducted ingredients
            $deducted[] = [
                'name' => $ingredient_name,
                'quantity_used' => $quantity_to_deduct,
                'unit' => $unit
            ];
        }
    }

    return ['success' => true, 'deducted_ingredients' => $deducted];
}
?>
