<form action="update_order_status.php" method="POST">
    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
    
    <div class="form-group">
        <label for="status">Update Status:</label>
        <select name="status" id="status" class="form-control">
            <option value="pending" <?php echo ($order['status'] == 'pending') ? 'selected' : ''; ?>>Pending</option>
            <option value="processing" <?php echo ($order['status'] == 'processing') ? 'selected' : ''; ?>>Processing</option>
            <option value="shipped" <?php echo ($order['status'] == 'shipped') ? 'selected' : ''; ?>>Shipped</option>
            <option value="delivered" <?php echo ($order['status'] == 'delivered') ? 'selected' : ''; ?>>Delivered</option>
            <option value="cancelled" <?php echo ($order['status'] == 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
        </select>
    </div>
    
    <button type="submit" class="btn btn-primary">Update Status</button>
</form>