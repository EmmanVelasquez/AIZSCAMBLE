<?php
include('../includes/db.php');

$success = $error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name     = $_POST['name'];
    $email    = $_POST['email'];
    $contact  = $_POST['contact'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $error = "Email already in use.";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (name, email, contact, password) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $contact, $password);
        if ($stmt->execute()) {
            $success = "Registration successful. <a href='login.php'>Login now</a>";
        } else {
            $error = "Registration failed. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <title>Register - AIZCAmble</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --accent-gold: #F59E0B;
            --accent-gold-light: #FCD34D;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --background-deep-start: #831843;
            --background-deep-end: #BE185D;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --error-color: #EF4444;
            --shadow-pink: rgba(236, 72, 153, 0.3);
            --shadow-strong: rgba(0, 0, 0, 0.25);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: linear-gradient(135deg, var(--background-deep-start) 0%, var(--background-deep-end) 50%, var(--primary-pink-dark) 100%);
            font-family: 'Poppins', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            color: var(--text-primary);
            position: relative;
            overflow: hidden;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, var(--primary-pink) 1px, transparent 1px);
            background-size: 50px 50px;
            animation: backgroundMove 20s linear infinite;
            opacity: 0.1;
        }

        body::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(circle at 20% 80%, var(--primary-pink) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, var(--accent-purple) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, var(--secondary-pink) 0%, transparent 50%);
            opacity: 0.15;
            animation: gradientShift 15s ease-in-out infinite;
        }

        @keyframes backgroundMove {
            0% { transform: translate(0, 0) rotate(0deg); }
            100% { transform: translate(50px, 50px) rotate(360deg); }
        }

        @keyframes gradientShift {
            0%, 100% { opacity: 0.15; }
            50% { opacity: 0.25; }
        }

        .register-container {
            background: var(--surface-white);
            backdrop-filter: blur(25px);
            border: 2px solid var(--surface-glass);
            border-radius: 32px;
            box-shadow: 
                0 32px 64px var(--shadow-strong),
                0 0 0 1px rgba(255, 255, 255, 0.1) inset,
                0 2px 16px var(--shadow-pink);
            width: 520px;
            padding: 56px 48px;
            text-align: center;
            position: relative;
            animation: containerEntrance 1s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            z-index: 10;
            overflow: hidden;
        }

        .register-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink), var(--primary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        .register-container::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.05) 50%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
            pointer-events: none;
            border-radius: 32px;
        }

        @keyframes containerEntrance {
            0% {
                opacity: 0;
                transform: translateY(50px) scale(0.9);
                filter: blur(10px);
            }
            100% {
                opacity: 1;
                transform: translateY(0) scale(1);
                filter: blur(0);
            }
        }

        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        @keyframes shimmer {
            0%, 100% { transform: translateX(-100%); }
            50% { transform: translateX(100%); }
        }

        .logo-container {
            position: relative;
            margin-bottom: 40px;
        }

        .logo-wrapper {
            position: relative;
            display: inline-block;
        }

        .logo-wrapper::before {
            content: '';
            position: absolute;
            top: -8px;
            left: -8px;
            right: -8px;
            bottom: -8px;
            background: linear-gradient(45deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink), var(--primary-pink));
            background-size: 300% 300%;
            border-radius: 50%;
            animation: logoGlow 4s ease-in-out infinite;
            z-index: -1;
        }

        @keyframes logoGlow {
            0%, 100% { 
                background-position: 0% 50%;
                transform: scale(1);
            }
            50% { 
                background-position: 100% 50%;
                transform: scale(1.05);
            }
        }

        .logo {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
            border: 4px solid rgba(255, 255, 255, 0.9);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            z-index: 2;
            box-shadow: 0 8px 32px var(--shadow-pink);
        }

        .logo:hover {
            transform: scale(1.1) rotate(5deg);
            box-shadow: 0 16px 48px var(--shadow-pink);
        }

        .brand-section {
            margin-bottom: 40px;
            position: relative;
        }

        .brand-section::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 200px;
            height: 200px;
            background: radial-gradient(circle, rgba(236, 72, 153, 0.1) 0%, transparent 70%);
            border-radius: 50%;
            z-index: -1;
            animation: brandGlow 4s ease-in-out infinite;
        }

        @keyframes brandGlow {
            0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 0.5; }
            50% { transform: translate(-50%, -50%) scale(1.2); opacity: 0.8; }
        }

        .brand-name {
            font-size: 36px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 12px;
            letter-spacing: -1px;
            position: relative;
        }

        .brand-tagline {
            font-size: 14px;
            color: var(--text-light);
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 8px;
        }

        .welcome-text {
            font-size: 18px;
            color: var(--text-secondary);
            margin-bottom: 40px;
            font-weight: 400;
            line-height: 1.6;
        }

        .form-container {
            position: relative;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .input-group {
            position: relative;
            margin-bottom: 28px;
        }

        .input-group.full-width {
            grid-column: 1 / -1;
        }

        .input-label {
            position: absolute;
            left: 56px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
            font-size: 16px;
            font-weight: 500;
            pointer-events: none;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            z-index: 2;
        }

        .input-icon {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
            font-size: 20px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            z-index: 2;
        }

        .input-field {
            width: 100%;
            padding: 20px 20px 20px 60px;
            border: 2px solid var(--border-light);
            border-radius: 16px;
            font-size: 16px;
            font-weight: 500;
            background: rgba(255, 255, 255, 0.8);
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            outline: none;
            font-family: 'Poppins', sans-serif;
        }

        .input-field:focus,
        .input-field:not(:placeholder-shown) {
            border-color: var(--primary-pink);
            background: rgba(255, 255, 255, 1);
            box-shadow: 
                0 0 0 4px rgba(236, 72, 153, 0.1),
                0 8px 32px rgba(236, 72, 153, 0.15),
                0 0 20px rgba(236, 72, 153, 0.3);
            transform: translateY(-2px);
        }

        .input-field:focus + .input-icon,
        .input-field:not(:placeholder-shown) + .input-icon {
            color: var(--primary-pink);
            transform: translateY(-50%) scale(1.1);
        }

        .input-field:focus ~ .input-label,
        .input-field:not(:placeholder-shown) ~ .input-label {
            top: -8px;
            left: 16px;
            font-size: 12px;
            color: var(--primary-pink);
            background: white;
            padding: 0 8px;
            border-radius: 8px;
            font-weight: 600;
        }

        .input-field::placeholder {
            color: transparent;
        }

        .error-message {
            background: linear-gradient(135deg, #FEE2E2, #FECACA);
            color: var(--error-color);
            padding: 20px;
            border-radius: 16px;
            margin-bottom: 28px;
            font-size: 14px;
            font-weight: 600;
            text-align: left;
            border: 2px solid #FCA5A5;
            position: relative;
            animation: errorShake 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            box-shadow: 0 8px 32px rgba(239, 68, 68, 0.2);
        }

        @keyframes errorShake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-8px); }
            75% { transform: translateX(8px); }
        }

        .error-message::before {
            content: '⚠️';
            margin-right: 12px;
            font-size: 16px;
        }

        .success-message {
            background: linear-gradient(135deg, #D1FAE5, #A7F3D0);
            color: var(--success-color);
            padding: 20px;
            border-radius: 16px;
            margin-bottom: 28px;
            font-size: 14px;
            font-weight: 600;
            text-align: left;
            border: 2px solid #6EE7B7;
            position: relative;
            animation: successPulse 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            box-shadow: 0 8px 32px rgba(16, 185, 129, 0.2);
        }

        @keyframes successPulse {
            0% { transform: scale(0.95); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
        }

        .success-message::before {
            content: '✅';
            margin-right: 12px;
            font-size: 16px;
        }

        .success-message a {
            color: var(--primary-pink);
            text-decoration: none;
            font-weight: 700;
            position: relative;
            transition: all 0.3s ease;
        }

        .success-message a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary-pink);
            transition: width 0.3s ease;
        }

        .success-message a:hover::after {
            width: 100%;
        }

        .success-message a:hover {
            color: var(--primary-pink-dark);
        }

        .register-button {
            background: linear-gradient(135deg, var(--primary-pink) 0%, var(--primary-pink-dark) 50%, var(--accent-purple) 100%);
            color: white;
            border: none;
            border-radius: 16px;
            padding: 20px 32px;
            width: 100%;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-family: 'Poppins', sans-serif;
            box-shadow: 0 8px 32px var(--shadow-pink);
            margin-top: 8px;
        }

        .register-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .register-button:hover::before {
            left: 100%;
        }

        .register-button:hover {
            transform: translateY(-3px);
            box-shadow: 
                0 16px 48px var(--shadow-pink),
                0 0 30px rgba(236, 72, 153, 0.4);
            background: linear-gradient(135deg, var(--primary-pink-dark) 0%, var(--primary-pink) 30%, var(--secondary-pink) 70%, var(--accent-purple-light) 100%);
        }

        .register-button:active {
            transform: translateY(-1px);
        }

        .divider {
            display: flex;
            align-items: center;
            margin: 40px 0;
            color: var(--text-light);
            font-size: 14px;
            font-weight: 600;
        }

        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            height: 2px;
            background: linear-gradient(to right, transparent, var(--primary-pink), transparent);
            opacity: 0.3;
        }

        .divider span {
            padding: 0 24px;
            background: var(--surface-white);
            border-radius: 20px;
            position: relative;
        }

        .login-section {
            margin-top: 32px;
            padding: 24px;
            background: rgba(236, 72, 153, 0.05);
            border-radius: 20px;
            border: 1px solid rgba(236, 72, 153, 0.1);
        }

        .login-link {
            font-size: 16px;
            color: var(--text-secondary);
            font-weight: 500;
        }

        .login-link a {
            color: var(--primary-pink);
            text-decoration: none;
            font-weight: 700;
            position: relative;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .login-link a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 3px;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            transition: width 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border-radius: 2px;
        }

        .login-link a:hover::after {
            width: 100%;
        }

        .login-link a:hover {
            color: var(--primary-pink-dark);
            transform: translateY(-1px);
        }

        /* Password strength indicator */
        .password-strength {
            margin-top: 8px;
            height: 4px;
            background: #E5E7EB;
            border-radius: 2px;
            overflow: hidden;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .password-strength.visible {
            opacity: 1;
        }

        .password-strength-bar {
            height: 100%;
            width: 0%;
            transition: all 0.3s ease;
            border-radius: 2px;
        }

        .strength-weak { background: var(--error-color); width: 25%; }
        .strength-fair { background: #F59E0B; width: 50%; }
        .strength-good { background: var(--primary-pink); width: 75%; }
        .strength-strong { background: var(--success-color); width: 100%; }

        /* Floating particles animation */
        .particle {
            position: absolute;
            border-radius: 50%;
            background: linear-gradient(45deg, var(--primary-pink), var(--secondary-pink));
            animation: floatParticle 20s infinite linear;
            pointer-events: none;
            opacity: 0.6;
        }

        .particle-pink {
            position: absolute;
            border-radius: 50%;
            background: linear-gradient(45deg, var(--secondary-pink), var(--primary-pink-light));
            animation: floatParticlePink 25s infinite linear;
            pointer-events: none;
            opacity: 0.4;
        }

        @keyframes floatParticle {
            0% {
                transform: translateY(100vh) rotate(0deg) scale(0);
                opacity: 0;
            }
            10% {
                opacity: 0.6;
                transform: translateY(90vh) rotate(36deg) scale(1);
            }
            90% {
                opacity: 0.6;
                transform: translateY(-10vh) rotate(324deg) scale(1);
            }
            100% {
                transform: translateY(-100vh) rotate(360deg) scale(0);
                opacity: 0;
            }
        }

        @keyframes floatParticlePink {
            0% {
                transform: translateY(100vh) rotate(0deg) scale(0);
                opacity: 0;
            }
            15% {
                opacity: 0.4;
                transform: translateY(85vh) rotate(54deg) scale(1);
            }
            85% {
                opacity: 0.4;
                transform: translateY(-15vh) rotate(306deg) scale(1);
            }
            100% {
                transform: translateY(-100vh) rotate(360deg) scale(0);
                opacity: 0;
            }
        }

        /* Responsive design */
        @media (max-width: 600px) {
            .register-container {
                width: 95%;
                padding: 40px 32px;
                margin: 20px;
                border-radius: 24px;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
                gap: 0;
            }
            
            .brand-name {
                font-size: 28px;
            }
            
            .input-field {
                padding: 18px 18px 18px 55px;
                font-size: 15px;
            }
            
            .input-icon {
                font-size: 18px;
                left: 18px;
            }

            .register-button {
                padding: 18px 28px;
                font-size: 16px;
            }
        }

        /* Loading state for button */
        .register-button.loading {
            pointer-events: none;
            opacity: 0.8;
            background: linear-gradient(135deg, var(--text-light), var(--text-light));
        }

        .register-button.loading::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 24px;
            height: 24px;
            margin: -12px 0 0 -12px;
            border: 3px solid transparent;
            border-top: 3px solid white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Enhanced focus states */
        .input-field:focus {
            border-color: var(--primary-pink);
            box-shadow: 
                0 0 0 4px rgba(236, 72, 153, 0.1),
                0 8px 32px rgba(236, 72, 153, 0.2),
                0 0 20px rgba(236, 72, 153, 0.3);
        }

        /* Enhanced input group hover effects */
        .input-group:hover .input-field {
            border-color: rgba(236, 72, 153, 0.3);
        }

        .input-group:hover .input-icon {
            color: var(--primary-pink-light);
            transform: translateY(-50%) scale(1.05);
        }
    </style>
</head>
<body>
    <!-- Enhanced floating particles with pink theme -->
    <div class="particle" style="left: 5%; width: 6px; height: 6px; animation-delay: 0s;"></div>
    <div class="particle-pink" style="left: 15%; width: 4px; height: 4px; animation-delay: 3s;"></div>
    <div class="particle" style="left: 25%; width: 8px; height: 8px; animation-delay: 6s;"></div>
    <div class="particle-pink" style="left: 35%; width: 5px; height: 5px; animation-delay: 9s;"></div>
    <div class="particle" style="left: 45%; width: 7px; height: 7px; animation-delay: 12s;"></div>
    <div class="particle-pink" style="left: 55%; width: 4px; height: 4px; animation-delay: 15s;"></div>
    <div class="particle" style="left: 65%; width: 6px; height: 6px; animation-delay: 18s;"></div>
    <div class="particle-pink" style="left: 75%; width: 5px; height: 5px; animation-delay: 21s;"></div>
    <div class="particle" style="left: 85%; width: 7px; height: 7px; animation-delay: 24s;"></div>
    <div class="particle-pink" style="left: 95%; width: 4px; height: 4px; animation-delay: 27s;"></div>

    <div class="register-container">
        <div class="logo-container">
            <div class="logo-wrapper">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo" class="logo">
            </div>
        </div>
        
        <div class="brand-section">
            <div class="brand-tagline">Join Premium Experience</div>
            <h1 class="brand-name">AIZCAmble</h1>
            <p class="welcome-text">Create your premium account and unlock exclusive features</p>
        </div>

        <?php if (!empty($error)): ?>
            <div class="error-message"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <div class="success-message"><?= $success ?></div>
        <?php endif; ?>

        <form method="POST" class="form-container" id="registerForm">
            <div class="form-grid">
                <div class="input-group">
                    <input type="text" name="name" class="input-field" placeholder="Enter your full name" required>
                    <i class="fas fa-user input-icon"></i>
                    <label class="input-label">Full Name</label>
                </div>
                
                <div class="input-group">
                    <input type="email" name="email" class="input-field" placeholder="Enter your email" required>
                    <i class="fas fa-envelope input-icon"></i>
                    <label class="input-label">Email Address</label>
                </div>
            </div>
            
            <div class="input-group full-width">
                <input type="tel" name="contact" class="input-field" placeholder="Enter your contact number" required>
                <i class="fas fa-phone input-icon"></i>
                <label class="input-label">Contact Number</label>
            </div>
            
            <div class="input-group full-width">
                <input type="password" name="password" class="input-field" placeholder="Create a strong password" required id="passwordField">
                <i class="fas fa-lock input-icon"></i>
                <label class="input-label">Password</label>
                <div class="password-strength" id="passwordStrength">
                    <div class="password-strength-bar" id="strengthBar"></div>
                </div>
            </div>

            <button type="submit" class="register-button" id="registerBtn">
                <span>Create Account</span>
            </button>
        </form>

        <div class="divider">
            <span>Already a Member?</span>
        </div>

        <div class="login-section">
            <div class="login-link">
                Already have an account? <a href="login.php">Sign In Here</a>
            </div>
        </div>
    </div>

    <script>
        // Enhanced form submission with loading states
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            const btn = document.getElementById('registerBtn');
            const btnText = btn.querySelector('span');
            
            btn.classList.add('loading');
            btnText.style.opacity = '0';
            
            // Simulate processing time for better UX
            setTimeout(() => {
                btnText.textContent = 'Creating Account...';
                btnText.style.opacity = '1';
            }, 300);
        });

        // Enhanced password strength checker with pink theme
        const passwordField = document.getElementById('passwordField');
        const strengthIndicator = document.getElementById('passwordStrength');
        const strengthBar = document.getElementById('strengthBar');

        passwordField.addEventListener('input', function() {
            const password = this.value;
            const strength = calculatePasswordStrength(password);
            
            if (password.length > 0) {
                strengthIndicator.classList.add('visible');
                updateStrengthBar(strength);
            } else {
                strengthIndicator.classList.remove('visible');
            }
        });

        function calculatePasswordStrength(password) {
            let score = 0;
            
            // Length check
            if (password.length >= 8) score++;
            if (password.length >= 12) score++;
            
            // Character variety checks
            if (/[a-z]/.test(password)) score++;
            if (/[A-Z]/.test(password)) score++;
            if (/[0-9]/.test(password)) score++;
            if (/[^A-Za-z0-9]/.test(password)) score++;
            
            return Math.min(score, 4);
        }

        function updateStrengthBar(strength) {
            strengthBar.className = 'password-strength-bar';
            
            switch(strength) {
                case 1:
                case 2:
                    strengthBar.classList.add('strength-weak');
                    break;
                case 3:
                    strengthBar.classList.add('strength-fair');
                    break;
                case 4:
                    strengthBar.classList.add('strength-good');
                    break;
                case 5:
                case 6:
                    strengthBar.classList.add('strength-strong');
                    break;
            }
        }

        // Enhanced input animations
        document.querySelectorAll('.input-field').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.style.transform = 'translateY(-2px)';
                this.parentElement.style.transition = 'all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
                this.parentElement.style.filter = 'drop-shadow(0 0 10px rgba(236, 72, 153, 0.3))';
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.style.transform = 'translateY(0)';
                this.parentElement.style.filter = 'none';
            });

            // Real-time validation feedback with pink theme
            input.addEventListener('input', function() {
                if (this.type === 'email' && this.value) {
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (emailRegex.test(this.value)) {
                        this.style.borderColor = 'var(--success-color)';
                        this.nextElementSibling.style.color = 'var(--success-color)';
                    } else {
                        this.style.borderColor = 'var(--error-color)';
                        this.nextElementSibling.style.color = 'var(--error-color)';
                    }
                }
                
                if (this.type === 'tel' && this.value) {
                    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
                    if (phoneRegex.test(this.value.replace(/\s/g, ''))) {
                        this.style.borderColor = 'var(--success-color)';
                        this.nextElementSibling.style.color = 'var(--success-color)';
                    } else {
                        this.style.borderColor = 'var(--error-color)';
                        this.nextElementSibling.style.color = 'var(--error-color)';
                    }
                }
            });
        });

        // Enhanced ripple effect for button
        document.querySelector('.register-button').addEventListener('click', function(e) {
            if (this.classList.contains('loading')) return;
            
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.cssText = `
                width: ${size}px;
                height: ${size}px;
                left: ${x}px;
                top: ${y}px;
                position: absolute;
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.4);
                transform: scale(0);
                animation: rippleEffect 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275);
                pointer-events: none;
            `;
            
            this.appendChild(ripple);
            
            setTimeout(() => ripple.remove(), 800);
        });

        // Add enhanced ripple animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes rippleEffect {
                0% {
                    transform: scale(0);
                    opacity: 1;
                }
                100% {
                    transform: scale(4);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);

        // Logo interaction with pink theme
        document.querySelector('.logo').addEventListener('click', function() {
            this.style.animation = 'none';
            this.style.transform = 'scale(1.2) rotate(360deg)';
            this.style.boxShadow = '0 20px 60px var(--shadow-pink)';
            
            setTimeout(() => {
                this.style.animation = '';
                this.style.transform = '';
                this.style.boxShadow = '';
            }, 500);
        });

        // Enhanced parallax effect for background elements
        document.addEventListener('mousemove', function(e) {
            const mouseX = e.clientX / window.innerWidth;
            const mouseY = e.clientY / window.innerHeight;
            
            // Move particles based on mouse position
            document.querySelectorAll('.particle, .particle-pink').forEach((particle, index) => {
                const speed = (index % 3 + 1) * 0.5;
                const x = (mouseX - 0.5) * speed * 20;
                const y = (mouseY - 0.5) * speed * 20;
                particle.style.transform = `translate(${x}px, ${y}px)`;
            });
            
            // Subtle container movement
            const container = document.querySelector('.register-container');
            const moveX = (mouseX - 0.5) * 10;
            const moveY = (mouseY - 0.5) * 10;
            container.style.transform = `translate(${moveX}px, ${moveY}px)`;
        });

        // Enhanced brand section animation
        document.querySelector('.brand-name').addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.05)';
            this.style.textShadow = '0 0 20px rgba(236, 72, 153, 0.5)';
        });

        document.querySelector('.brand-name').addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
            this.style.textShadow = 'none';
        });

        // Enhanced form validation
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            const name = document.querySelector('input[name="name"]').value.trim();
            const email = document.querySelector('input[name="email"]').value.trim();
            const contact = document.querySelector('input[name="contact"]').value.trim();
            const password = document.querySelector('input[name="password"]').value;
            
            let errors = [];
            
            if (name.length < 2) {
                errors.push('Please enter a valid full name (at least 2 characters)');
            }
            
            if (password.length < 6) {
                errors.push('Password must be at least 6 characters long');
            }
            
            if (contact.length < 10) {
                errors.push('Please enter a valid contact number');
            }
            
            if (errors.length > 0) {
                e.preventDefault();
                alert('Please fix the following errors:\n\n' + errors.join('\n'));
                return;
            }
        });

        // Add dynamic background color shifts
        setInterval(() => {
            const hue = Math.random() * 30 + 320; // Pink to purple range
            document.documentElement.style.setProperty('--dynamic-bg', `hsl(${hue}, 70%, 15%)`);
        }, 5000);

        // Enhanced input group animations
        document.querySelectorAll('.input-group').forEach(group => {
            group.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-1px)';
                this.style.transition = 'all 0.3s ease';
            });
            
            group.addEventListener('mouseleave', function() {
                if (!this.querySelector('.input-field:focus')) {
                    this.style.transform = 'translateY(0)';
                }
            });
        });
    </script>
</body>
</html>