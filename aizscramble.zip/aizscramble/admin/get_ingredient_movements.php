<?php
// Enable error reporting for development (remove in production)
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
include('../includes/db.php');

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

try {
    // Get filter parameters with validation
    $ingredient_id = isset($_GET['ingredient_id']) && !empty($_GET['ingredient_id']) ? 
                    intval($_GET['ingredient_id']) : null;
    
    // Validate date format
    $date_from = null;
    if (isset($_GET['date_from']) && !empty($_GET['date_from'])) {
        $date_from = date('Y-m-d', strtotime($_GET['date_from']));
        if ($date_from === false) {
            throw new Exception('Invalid date_from format');
        }
    }
    
    $date_to = null;
    if (isset($_GET['date_to']) && !empty($_GET['date_to'])) {
        $date_to = date('Y-m-d', strtotime($_GET['date_to']));
        if ($date_to === false) {
            throw new Exception('Invalid date_to format');
        }
    }

    // Build the query - Modified to match the required column order
    $query = "
        SELECT 
            m.movement_date,
            i.name AS ingredient_name,
            m.quantity_before,
            m.sales_quantity,
            m.current_stock,
            m.restock_quantity,
            m.id,
            i.unit,
            COALESCE(u.name, 'System') AS username,
            m.notes
        FROM 
            ingredient_movements m
        JOIN 
            ingredients i ON m.ingredient_id = i.id
        LEFT JOIN 
            users u ON m.created_by = u.id
        WHERE 1=1
    ";

    $params = [];
    $types = "";

    // Add filters if provided
    if ($ingredient_id) {
        $query .= " AND m.ingredient_id = ?";
        $params[] = $ingredient_id;
        $types .= "i";
    }

    if ($date_from) {
        $query .= " AND DATE(m.movement_date) >= ?";
        $params[] = $date_from;
        $types .= "s";
    }

    if ($date_to) {
        $query .= " AND DATE(m.movement_date) <= ?";
        $params[] = $date_to;
        $types .= "s";
    }

    // Order by date, newest first
    $query .= " ORDER BY m.movement_date DESC LIMIT 500";

    // Prepare and execute the query
    $stmt = $conn->prepare($query);
    
    if ($stmt === false) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }

    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }

    if (!$stmt->execute()) {
        throw new Exception("Failed to execute query: " . $stmt->error);
    }
    
    $result = $stmt->get_result();
    
    if ($result === false) {
        throw new Exception("Failed to get result: " . $stmt->error);
    }

    $movements = [];
    while ($row = $result->fetch_assoc()) {
        // Format dates for better readability
        $row['movement_date'] = date('Y-m-d H:i:s', strtotime($row['movement_date']));
        
        // Ensure numeric values are properly formatted
        $row['quantity_before'] = floatval($row['quantity_before']);
        $row['sales_quantity'] = floatval($row['sales_quantity']);
        $row['current_stock'] = floatval($row['current_stock']);
        $row['restock_quantity'] = floatval($row['restock_quantity']);
        
        $movements[] = $row;
    }

    // Return the data as JSON
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'count' => count($movements),
        'movements' => $movements
    ]);

} catch (Exception $e) {
    // Return error message
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>