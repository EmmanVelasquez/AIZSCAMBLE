<?php
session_start();
require('../includes/db.php');
require_once('../includes/notify_helper.php');

if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../user/login.php");
    exit;
}

// Handle mark as read
if (isset($_GET['mark_read'])) {
    if ($_GET['mark_read'] == 'all') {
        $conn->query("UPDATE AdminNotifications SET IsRead = 1 WHERE IsRead = 0");
        $_SESSION['message'] = "All notifications marked as read!";
    } else {
        $notif_id = (int)$_GET['mark_read'];
        $stmt = $conn->prepare("UPDATE AdminNotifications SET IsRead = 1 WHERE id = ?");
        $stmt->bind_param("i", $notif_id);
        $stmt->execute();
        $_SESSION['message'] = "Notification marked as read!";
    }
    header("Location: notifications.php");
    exit;
}

// Handle delete notification
if (isset($_GET['delete'])) {
    if ($_GET['delete'] == 'all') {
        $conn->query("DELETE FROM AdminNotifications");
        $_SESSION['message'] = "All notifications deleted!";
    } else {
        $notif_id = (int)$_GET['delete'];
        $stmt = $conn->prepare("DELETE FROM AdminNotifications WHERE id = ?");
        $stmt->bind_param("i", $notif_id);
        $stmt->execute();
        $_SESSION['message'] = "Notification deleted!";
    }
    header("Location: notifications.php");
    exit;
}

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 15;
$offset = ($page - 1) * $limit;

// Filter
$filter = $_GET['filter'] ?? 'all';
$whereClause = '';
if ($filter === 'unread') {
    $whereClause = 'WHERE IsRead = 0';
} elseif ($filter === 'read') {
    $whereClause = 'WHERE IsRead = 1';
}

// Get total count for pagination
$total_count = $conn->query("SELECT COUNT(*) as count FROM AdminNotifications $whereClause")->fetch_assoc()['count'];
$total_pages = ceil($total_count / $limit);

// Get notifications with pagination
$notifications = $conn->query("SELECT * FROM AdminNotifications $whereClause ORDER BY CreatedAt DESC LIMIT $offset, $limit")->fetch_all(MYSQLI_ASSOC);

// Get unread count for the bell icon
$unreadCount = $conn->query("SELECT COUNT(*) as total FROM AdminNotifications WHERE IsRead = 0")->fetch_assoc()['total'];

// Get statistics
$totalNotifications = $conn->query("SELECT COUNT(*) as total FROM AdminNotifications")->fetch_assoc()['total'];
$readCount = $conn->query("SELECT COUNT(*) as total FROM AdminNotifications WHERE IsRead = 1")->fetch_assoc()['total'];
$todayCount = $conn->query("SELECT COUNT(*) as total FROM AdminNotifications WHERE DATE(CreatedAt) = CURDATE()")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <title>Notifications - AIZCAmble Admin</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --error-color: #EF4444;
            --info-color: #3B82F6;
            --shadow-pink: rgba(236, 72, 153, 0.2);
            --shadow-strong: rgba(0, 0, 0, 0.1);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-gradient-start) 0%, var(--background-gradient-end) 100%);
            min-height: 100vh;
            display: flex;
            color: var(--text-primary);
            position: relative;
            overflow-x: hidden;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, var(--primary-pink) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, var(--accent-purple) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, var(--secondary-pink) 0%, transparent 50%);
            opacity: 0.05;
            z-index: -1;
            animation: backgroundFloat 20s ease-in-out infinite;
        }

        @keyframes backgroundFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(-20px, -20px) scale(1.05); }
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary-pink) 0%, var(--primary-pink-dark) 100%);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--border-light);
            box-shadow: 4px 0 20px var(--shadow-pink);
            padding: 0;
            min-height: 100vh;
            position: relative;
            overflow: hidden;
        }

        .sidebar::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.1) 50%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
        }

        @keyframes shimmer {
            0%, 100% { transform: translateX(-100%); }
            50% { transform: translateX(100%); }
        }

        .logo-section {
            text-align: center;
            padding: 32px 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            position: relative;
            z-index: 2;
        }

        .logo-container {
            position: relative;
            display: inline-block;
            margin-bottom: 16px;
        }

        .logo-container::before {
            content: '';
            position: absolute;
            top: -8px;
            left: -8px;
            right: -8px;
            bottom: -8px;
            background: linear-gradient(45deg, rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0.1));
            border-radius: 50%;
            animation: logoGlow 2s ease-in-out infinite;
        }

        @keyframes logoGlow {
            0%, 100% { transform: scale(1); opacity: 0.7; }
            50% { transform: scale(1.05); opacity: 1; }
        }

        .logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(255, 255, 255, 0.9);
            object-fit: cover;
            position: relative;
            z-index: 2;
            transition: all 0.3s ease;
        }

        .logo:hover {
            transform: scale(1.1) rotate(5deg);
        }

        .brand-name {
            color: white;
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 8px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .admin-title {
            color: rgba(255, 255, 255, 0.9);
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-menu {
            padding: 24px 0;
            position: relative;
            z-index: 2;
        }

        .nav-item {
            display: block;
            padding: 16px 24px;
            margin: 8px 16px;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            border-radius: 16px;
            font-weight: 500;
            font-size: 15px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
        }

        .nav-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .nav-item:hover::before {
            left: 100%;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(8px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item.active {
            background: rgba(255, 255, 255, 0.25);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        .nav-badge {
            background: var(--error-color);
            color: white;
            border-radius: 50%;
            padding: 4px 8px;
            font-size: 12px;
            font-weight: 700;
            float: right;
            animation: pulse 2s infinite;
        }

        .main-content {
            flex: 1;
            padding: 32px;
            overflow-y: auto;
            position: relative;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            padding: 24px 32px;
            border-radius: 20px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            position: relative;
            overflow: hidden;
        }

        .header-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .page-title {
            font-size: 32px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* Alert Messages */
        .message {
            padding: 16px 20px;
            margin-bottom: 24px;
            border-radius: 12px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.5s ease;
        }

        .success {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(5, 150, 105, 0.1));
            color: var(--success-color);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        @keyframes slideIn {
            0% { transform: translateY(-20px); opacity: 0; }
            100% { transform: translateY(0); opacity: 1; }
        }

        /* Statistics Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 24px;
            margin-bottom: 32px;
        }

        .stat-card {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 24px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 16px 48px var(--shadow-pink);
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
            margin-bottom: 16px;
        }

        .stat-icon.total { background: linear-gradient(135deg, var(--info-color), #2563EB); }
        .stat-icon.unread { background: linear-gradient(135deg, var(--error-color), #DC2626); }
        .stat-icon.read { background: linear-gradient(135deg, var(--success-color), #059669); }
        .stat-icon.today { background: linear-gradient(135deg, var(--warning-color), #D97706); }

        .stat-value {
            font-size: 32px;
            font-weight: 800;
            color: var(--text-primary);
            margin-bottom: 8px;
        }

        .stat-label {
            font-size: 14px;
            color: var(--text-secondary);
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Controls Section */
        .controls-section {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 24px 32px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            margin-bottom: 32px;
            position: relative;
            overflow: hidden;
        }

        .controls-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        .controls-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        .controls-title {
            font-size: 20px;
            font-weight: 700;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .filters-row {
            display: flex;
            gap: 16px;
            align-items: center;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        .filter-group {
            display: flex;
            gap: 8px;
        }

        .filter-btn {
            padding: 12px 20px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
            border: 2px solid var(--border-light);
            background: white;
            color: var(--text-secondary);
        }

        .filter-btn.active {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            border-color: var(--primary-pink);
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        .filter-btn:hover:not(.active) {
            background: rgba(236, 72, 153, 0.1);
            border-color: var(--primary-pink);
            color: var(--primary-pink);
        }

        .action-buttons {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .action-btn {
            padding: 12px 20px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .action-btn.primary {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        .action-btn.danger {
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
            box-shadow: 0 4px 15px rgba(239, 68, 68, 0.3);
        }

        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px var(--shadow-pink);
        }

        /* Notifications Container */
        .notifications-container {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            overflow: hidden;
            position: relative;
        }

        .notifications-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        .notifications-header {
            padding: 24px 32px;
            border-bottom: 1px solid var(--border-light);
        }

        .notifications-title {
            font-size: 20px;
            font-weight: 700;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .notification-item {
            padding: 24px 32px;
            border-bottom: 1px solid rgba(236, 72, 153, 0.05);
            transition: all 0.3s ease;
            position: relative;
        }

        .notification-item:last-child {
            border-bottom: none;
        }

        .notification-item:hover {
            background: rgba(236, 72, 153, 0.02);
            transform: translateX(4px);
        }

        .notification-item.unread {
            background: linear-gradient(135deg, rgba(236, 72, 153, 0.05), rgba(219, 39, 119, 0.03));
            border-left: 4px solid var(--primary-pink);
        }

        .notification-content {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
        }

        .notification-details {
            flex: 1;
        }

        .notification-title {
            font-size: 16px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .notification-message {
            font-size: 14px;
            color: var(--text-secondary);
            line-height: 1.6;
            margin-bottom: 12px;
        }

        .notification-meta {
            display: flex;
            align-items: center;
            gap: 16px;
            font-size: 12px;
            color: var(--text-light);
        }

        .notification-date {
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .notification-status {
            padding: 4px 8px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .status-unread {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(220, 38, 38, 0.1));
            color: var(--error-color);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .status-read {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(5, 150, 105, 0.1));
            color: var(--success-color);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .notification-actions {
            display: flex;
            gap: 8px;
            flex-shrink: 0;
        }

        .notification-action {
            padding: 8px 12px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
            border: 1px solid var(--border-light);
            background: white;
            color: var(--text-secondary);
        }

        .notification-action:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .notification-action.primary {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            border-color: var(--primary-pink);
        }

        .notification-action.danger {
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
            border-color: var(--error-color);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 64px 32px;
            color: var(--text-light);
        }

        .empty-state i {
            font-size: 64px;
            margin-bottom: 24px;
            color: var(--text-light);
            opacity: 0.5;
        }

        .empty-state h3 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 12px;
            color: var(--text-secondary);
        }

        .empty-state p {
            font-size: 16px;
            line-height: 1.6;
        }

        /* Pagination */
        .pagination-container {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 32px;
            gap: 8px;
        }

        .pagination-btn {
            padding: 12px 16px;
            border: 2px solid var(--border-light);
            border-radius: 12px;
            background: white;
            color: var(--text-secondary);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            min-width: 48px;
            text-align: center;
        }

        .pagination-btn:hover {
            background: rgba(236, 72, 153, 0.1);
            border-color: var(--primary-pink);
            color: var(--primary-pink);
        }

        .pagination-btn.active {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            border-color: var(--primary-pink);
        }

        .pagination-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .pagination-info {
            margin: 0 16px;
            color: var(--text-secondary);
            font-weight: 500;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .sidebar {
                width: 240px;
            }
            
            .stats-grid {
                grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            }
        }

        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                min-height: auto;
                position: fixed;
                top: 0;
                left: -100%;
                z-index: 1000;
                transition: left 0.3s ease;
            }
            
            .sidebar.open {
                left: 0;
            }
            
            .main-content {
                padding: 20px;
                margin-top: 0;
            }
            
            .header-section {
                flex-direction: column;
                gap: 16px;
                text-align: center;
            }
            
            .page-title {
                font-size: 24px;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
                gap: 16px;
            }
            
            .filters-row {
                flex-direction: column;
                align-items: stretch;
                gap: 16px;
            }
            
            .notification-content {
                flex-direction: column;
                gap: 16px;
            }
            
            .notification-actions {
                align-self: flex-start;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(236, 72, 153, 0.1);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--primary-pink-dark), var(--primary-pink));
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <div class="logo-container">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo" class="logo">
            </div>
            <div class="brand-name">AIZCAmble</div>
            <div class="admin-title">Admin Panel</div>
        </div>

        <nav class="nav-menu">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                Dashboard
            </a>
            <a href="orders.php" class="nav-item">
                <i class="fas fa-shopping-bag"></i>
                Manage Orders
            </a>
            <a href="add_product.php" class="nav-item">
                <i class="fas fa-plus-circle"></i>
                Add Product
            </a>
            <a href="stock.php" class="nav-item">
                <i class="fas fa-boxes"></i>
                Stock Management
            </a>
            <a href="sales_analytics.php" class="nav-item">
                <i class="fas fa-chart-bar"></i>
                Sales Analytics
            </a>
            <a href="users.php" class="nav-item">
                <i class="fas fa-users"></i>
                Customers
            </a>
            <a href="ingredients.php" class="nav-item">
                <i class="fas fa-flask"></i>
                Ingredients
            </a>
            <a href="admins.php" class="nav-item">
                <i class="fas fa-user-shield"></i>
                Admins
            </a>
            <a href="shutdown.php" class="nav-item">
                <i class="fas fa-power-off"></i>
                Shutdown Shop
            </a>
            <a href="activity_log.php" class="nav-item">
                <i class="fas fa-history"></i>
                Activity History
            </a>
            <a href="notifications.php" class="nav-item active">
                <i class="fas fa-bell"></i>
                Notifications
                <?php if ($unreadCount > 0): ?>
                    <span class="nav-badge"><?= $unreadCount ?></span>
                <?php endif; ?>
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header-section">
            <h1 class="page-title">
                <i class="fas fa-bell"></i>
                Notification Center
            </h1>
        </div>
        
        <!-- Alert Messages -->
        <?php if (isset($_SESSION['message'])): ?>
            <div class="message success">
                <i class="fas fa-check-circle"></i>
                <?= htmlspecialchars($_SESSION['message']) ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <!-- Statistics Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon total">
                    <i class="fas fa-bell"></i>
                </div>
                <div class="stat-value"><?= number_format($totalNotifications) ?></div>
                <div class="stat-label">Total Notifications</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon unread">
                    <i class="fas fa-exclamation-circle"></i>
                </div>
                <div class="stat-value"><?= number_format($unreadCount) ?></div>
                <div class="stat-label">Unread</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon read">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-value"><?= number_format($readCount) ?></div>
                <div class="stat-label">Read</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon today">
                    <i class="fas fa-calendar-day"></i>
                </div>
                <div class="stat-value"><?= number_format($todayCount) ?></div>
                <div class="stat-label">Today</div>
            </div>
        </div>

        <!-- Controls Section -->
        <div class="controls-section">
            <div class="controls-header">
                <div class="controls-title">
                    <i class="fas fa-filter"></i>
                    Filter & Actions
                </div>
            </div>
            
            <div class="filters-row">
                <div class="filter-group">
                    <a href="?filter=all" class="filter-btn <?= $filter === 'all' ? 'active' : '' ?>">
                        <i class="fas fa-list"></i> All
                    </a>
                    <a href="?filter=unread" class="filter-btn <?= $filter === 'unread' ? 'active' : '' ?>">
                        <i class="fas fa-exclamation-circle"></i> Unread
                    </a>
                    <a href="?filter=read" class="filter-btn <?= $filter === 'read' ? 'active' : '' ?>">
                        <i class="fas fa-check-circle"></i> Read
                    </a>
                </div>
                
                <div class="action-buttons">
                    <?php if ($unreadCount > 0): ?>
                        <a href="notifications.php?mark_read=all" class="action-btn primary">
                            <i class="fas fa-check-double"></i>
                            Mark All Read
                        </a>
                    <?php endif; ?>
                    <?php if ($totalNotifications > 0): ?>
                        <a href="notifications.php?delete=all" class="action-btn danger" 
                           onclick="return confirm('Are you sure you want to delete all notifications? This action cannot be undone.')">
                            <i class="fas fa-trash-alt"></i>
                            Delete All
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Notifications Container -->
        <div class="notifications-container">
            <div class="notifications-header">
                <div class="notifications-title">
                    <i class="fas fa-inbox"></i>
                    Notifications
                    <span style="font-size: 14px; font-weight: 500; color: var(--text-light); margin-left: 8px;">
                        (<?= number_format($total_count) ?> total)
                    </span>
                </div>
            </div>
            
            <?php if (count($notifications) > 0): ?>
                <?php foreach ($notifications as $notif): ?>
                    <div class="notification-item <?= !$notif['IsRead'] ? 'unread' : '' ?>">
                        <div class="notification-content">
                            <div class="notification-details">
                                <div class="notification-title">
                                    <i class="fas fa-<?= !$notif['IsRead'] ? 'exclamation-circle' : 'check-circle' ?>"></i>
                                    <?= htmlspecialchars($notif['Title']) ?>
                                </div>
                                <div class="notification-message">
                                    <?= htmlspecialchars($notif['message']) ?>
                                </div>
                                <div class="notification-meta">
                                    <div class="notification-date">
                                        <i class="fas fa-clock"></i>
                                        <?= date('M d, Y h:i A', strtotime($notif['CreatedAt'])) ?>
                                    </div>
                                    <div class="notification-status <?= !$notif['IsRead'] ? 'status-unread' : 'status-read' ?>">
                                        <?= !$notif['IsRead'] ? 'Unread' : 'Read' ?>
                                    </div>
                                </div>
                            </div>
                            <div class="notification-actions">
                                <?php if (!$notif['IsRead']): ?>
                                    <a href="notifications.php?mark_read=<?= $notif['id'] ?>" class="notification-action primary">
                                        <i class="fas fa-check"></i>
                                        Mark Read
                                    </a>
                                <?php endif; ?>
                                <a href="notifications.php?delete=<?= $notif['id'] ?>" class="notification-action danger" 
                                   onclick="return confirm('Are you sure you want to delete this notification?')">
                                    <i class="fas fa-trash"></i>
                                    Delete
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-inbox"></i>
                    <h3>No Notifications Found</h3>
                    <p>
                        <?php if ($filter === 'unread'): ?>
                            You have no unread notifications at the moment.
                        <?php elseif ($filter === 'read'): ?>
                            You have no read notifications.
                        <?php else: ?>
                            You don't have any notifications yet. They will appear here when you receive them.
                        <?php endif; ?>
                    </p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <div class="pagination-container">
                <?php if ($page > 1): ?>
                    <a href="?filter=<?= urlencode($filter) ?>&page=<?= $page - 1 ?>" class="pagination-btn">
                        <i class="fas fa-chevron-left"></i>
                    </a>
                <?php endif; ?>
                
                <?php
                $start = max(1, $page - 2);
                $end = min($total_pages, $page + 2);
                
                for ($i = $start; $i <= $end; $i++):
                ?>
                    <a href="?filter=<?= urlencode($filter) ?>&page=<?= $i ?>" 
                       class="pagination-btn <?= $i == $page ? 'active' : '' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                    <a href="?filter=<?= urlencode($filter) ?>&page=<?= $page + 1 ?>" class="pagination-btn">
                        <i class="fas fa-chevron-right"></i>
                    </a>
                <?php endif; ?>
                
                <div class="pagination-info">
                    Page <?= $page ?> of <?= $total_pages ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // Enhanced notification interactions
        document.querySelectorAll('.notification-item').forEach(item => {
            item.addEventListener('mouseenter', function() {
                this.style.transform = 'translateX(8px)';
                this.style.boxShadow = '0 8px 25px rgba(236, 72, 153, 0.15)';
            });
            
            item.addEventListener('mouseleave', function() {
                this.style.transform = 'translateX(4px)';
                this.style.boxShadow = 'none';
            });
        });

        // Stat card animations
        document.querySelectorAll('.stat-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-8px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(-5px) scale(1)';
            });
        });

        // Enhanced button interactions
        document.querySelectorAll('.action-btn, .notification-action').forEach(btn => {
            btn.addEventListener('click', function(e) {
                // Add ripple effect
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.cssText = `
                    width: ${size}px;
                    height: ${size}px;
                    left: ${x}px;
                    top: ${y}px;
                    position: absolute;
                    border-radius: 50%;
                    background: rgba(255, 255, 255, 0.4);
                    transform: scale(0);
                    animation: rippleEffect 0.6s ease-out;
                    pointer-events: none;
                `;
                
                this.style.position = 'relative';
                this.style.overflow = 'hidden';
                this.appendChild(ripple);
                
                setTimeout(() => ripple.remove(), 600);
            });
        });

        // Add ripple animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes rippleEffect {
                0% {
                    transform: scale(0);
                    opacity: 1;
                }
                100% {
                    transform: scale(4);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);

        // Mobile sidebar toggle
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('open');
        }

        // Add mobile menu button if needed
        if (window.innerWidth <= 768) {
            const header = document.querySelector('.header-section');
            const menuBtn = document.createElement('button');
            menuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            menuBtn.className = 'btn btn-primary';
            menuBtn.onclick = toggleSidebar;
            menuBtn.style.position = 'absolute';
            menuBtn.style.top = '20px';
            menuBtn.style.left = '20px';
            menuBtn.style.zIndex = '1001';
            document.body.appendChild(menuBtn);
        }

        // Auto-refresh notifications every 30 seconds
        setInterval(function() {
            if (!document.hidden) {
                // Check for new notifications without full page reload
                fetch('notifications.php?ajax=check')
                    .then(response => response.json())
                    .then(data => {
                        if (data.newCount && data.newCount > 0) {
                            // Show notification for new notifications
                            const notification = document.createElement('div');
                            notification.className = 'message success';
                            notification.innerHTML = `
                                <i class="fas fa-bell"></i>
                                You have ${data.newCount} new notification${data.newCount > 1 ? 's' : ''}!
                                <a href="javascript:location.reload()" style="margin-left: 12px; color: var(--primary-pink); font-weight: 700;">Refresh</a>
                            `;
                            
                            const mainContent = document.querySelector('.main-content');
                            const firstChild = mainContent.firstElementChild.nextElementSibling;
                            mainContent.insertBefore(notification, firstChild);
                            
                            // Auto-remove after 5 seconds
                            setTimeout(() => notification.remove(), 5000);
                        }
                    })
                    .catch(error => console.log('Notification check failed:', error));
            }
        }, 30000);

        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            // 'r' to refresh
            if (e.key === 'r' && !e.ctrlKey && !e.metaKey) {
                const activeElement = document.activeElement;
                if (activeElement.tagName !== 'INPUT' && activeElement.tagName !== 'TEXTAREA') {
                    e.preventDefault();
                    location.reload();
                }
            }
            
            // 'm' to mark all as read
            if (e.key === 'm' && !e.ctrlKey && !e.metaKey) {
                const activeElement = document.activeElement;
                if (activeElement.tagName !== 'INPUT' && activeElement.tagName !== 'TEXTAREA') {
                    const markAllBtn = document.querySelector('a[href*="mark_read=all"]');
                    if (markAllBtn) {
                        e.preventDefault();
                        markAllBtn.click();
                    }
                }
            }
        });

        // Enhanced filter animations
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('mouseenter', function() {
                if (!this.classList.contains('active')) {
                    this.style.transform = 'translateY(-2px)';
                }
            });
            
            btn.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
            });
        });

        // Smooth scroll to top when changing pages
        document.querySelectorAll('.pagination-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });
    </script>
</body>
</html>