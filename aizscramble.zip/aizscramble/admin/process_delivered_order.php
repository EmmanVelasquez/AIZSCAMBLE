<?php
// Include database connection
require_once('../includes/db.php');

/**
 * Process an order that has been marked as delivered
 * Creates sales record and corresponding sale_items records
 * 
 * @param int $order_id The ID of the order that was delivered
 * @return bool True if successful, false otherwise
 */
function processDeliveredOrder($order_id) {
    global $conn;
    
    // Start transaction to ensure data integrity
    $conn->begin_transaction();
    
    try {
        // Check if this order already has a sales record to prevent duplicates
        $check_sql = "SELECT COUNT(*) as count FROM sales WHERE order_id = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("i", $order_id);
        $check_stmt->execute();
        $result = $check_stmt->get_result();
        $row = $result->fetch_assoc();
        
        if ($row['count'] > 0) {
            // Sales record already exists, no need to create another one
            $conn->commit();
            return true;
        }
        
        // Get order details
        $order_sql = "SELECT o.id, o.user_id, o.payment_method, SUM(oi.price * oi.quantity) as total_amount 
                     FROM orders o 
                     JOIN order_items oi ON o.id = oi.order_id 
                     WHERE o.id = ?
                     GROUP BY o.id, o.user_id, o.payment_method";
        
        $order_stmt = $conn->prepare($order_sql);
        $order_stmt->bind_param("i", $order_id);
        $order_stmt->execute();
        $order_result = $order_stmt->get_result();
        
        if ($order_result->num_rows === 0) {
            // Order not found
            throw new Exception("Order #$order_id not found");
        }
        
        $order = $order_result->fetch_assoc();
        
        // Current date for the sale_date
        $current_date = date('Y-m-d H:i:s');
        
        // Insert into sales table
        $sales_sql = "INSERT INTO sales (order_id, user_id, total_amount, sale_date, payment_method, status) 
                      VALUES (?, ?, ?, ?, ?, 'completed')";
        
        $sales_stmt = $conn->prepare($sales_sql);
        $sales_stmt->bind_param("iidsss", 
            $order['id'], 
            $order['user_id'], 
            $order['total_amount'], 
            $current_date, 
            $order['payment_method']
        );
        
        $sales_stmt->execute();
        $sale_id = $conn->insert_id;
        
        // Get all order items
        $items_sql = "SELECT product_id, quantity, price 
                     FROM order_items 
                     WHERE order_id = ?";
        
        $items_stmt = $conn->prepare($items_sql);
        $items_stmt->bind_param("i", $order_id);
        $items_stmt->execute();
        $items_result = $items_stmt->get_result();
        
        // Insert each order item into sale_items
        while ($item = $items_result->fetch_assoc()) {
            $subtotal = $item['price'] * $item['quantity'];
            
            $sale_items_sql = "INSERT INTO sale_items (sale_id, product_id, quantity, unit_price, subtotal) 
                              VALUES (?, ?, ?, ?, ?)";
            
            $sale_items_stmt = $conn->prepare($sale_items_sql);
            $sale_items_stmt->bind_param("iiddd", 
                $sale_id, 
                $item['product_id'], 
                $item['quantity'], 
                $item['price'], 
                $subtotal
            );
            
            $sale_items_stmt->execute();
        }
        
        // If we got here, everything succeeded
        $conn->commit();
        return true;
        
    } catch (Exception $e) {
        // Something went wrong, rollback the transaction
        $conn->rollback();
        error_log("Error processing delivered order #$order_id: " . $e->getMessage());
        return false;
    }
}

/**
 * Update order status and process sales records if status is 'delivered'
 * 
 * @param int $order_id The order ID to update
 * @param string $new_status The new status for the order
 * @return bool True if successful, false otherwise
 */
function updateOrderStatus($order_id, $new_status) {
    global $conn;
    
    // Update the order status
    $update_sql = "UPDATE orders SET status = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("si", $new_status, $order_id);
    
    if (!$update_stmt->execute()) {
        return false;
    }
    
    // If the new status is 'delivered', process the order for sales records
    if (strtolower($new_status) === 'delivered') {
        return processDeliveredOrder($order_id);
    }
    
    return true;
}

// Example usage in an order status update page:
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['status'];
    
    if (updateOrderStatus($order_id, $new_status)) {
        // Success message
        $_SESSION['message'] = "Order status updated successfully";
        
        if (strtolower($new_status) === 'delivered') {
            $_SESSION['message'] .= " and sales records created";
        }
    } else {
        // Error message
        $_SESSION['error'] = "Failed to update order status";
    }
    
    // Redirect back to orders page
    header("Location: admin/orders.php");
    exit;
}
?>