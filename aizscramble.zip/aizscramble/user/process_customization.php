<?php
session_start();
include('../includes/db.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Get the product ID from the form
$product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;

// Fetch product details
$product = $conn->query("SELECT * FROM products WHERE id = $product_id")->fetch_assoc();

if (!$product) {
    header("Location: ../index.php");
    exit;
}

// Initialize total price with base product price
$total_price = $product['price'];
$customizations = [];

// Process size selection
if (isset($_POST['size'])) {
    $size = $_POST['size'];
    // Get price for selected size
    $size_query = $conn->query("SELECT price FROM customizable_options 
                              WHERE product_id = $product_id 
                              AND option_name = 'Size' 
                              AND option_value = '".$conn->real_escape_string($size)."'");
    if ($size_row = $size_query->fetch_assoc()) {
        $total_price += $size_row['price'];
    }
    $customizations['Size'] = $size;
}

// Process flavor selection
if (isset($_POST['flavor'])) {
    $flavor = $_POST['flavor'];
    // Get price for selected flavor
    $flavor_query = $conn->query("SELECT price FROM customizable_options 
                                 WHERE product_id = $product_id 
                                 AND option_name = 'Flavor' 
                                 AND option_value = '".$conn->real_escape_string($flavor)."'");
    if ($flavor_row = $flavor_query->fetch_assoc()) {
        $total_price += $flavor_row['price'];
    }
    $customizations['Flavor'] = $flavor;
}

// Process add-ons
if (isset($_POST['add_ons']) && is_array($_POST['add_ons'])) {
    $selected_addons = [];
    foreach ($_POST['add_ons'] as $addon) {
        // Get price for each add-on
        $addon_query = $conn->query("SELECT price FROM customizable_options 
                                    WHERE product_id = $product_id 
                                    AND option_name = 'Add-on' 
                                    AND option_value = '".$conn->real_escape_string($addon)."'");
        if ($addon_row = $addon_query->fetch_assoc()) {
            $total_price += $addon_row['price'];
            $selected_addons[] = $addon;
        }
    }
    if (!empty($selected_addons)) {
        $customizations['Add-ons'] = $selected_addons;
    }
}

// Initialize cart if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Generate unique key for this customization combination
$customization_key = md5(json_encode($customizations));

// Check if this exact product with these customizations already exists in cart
$found = false;
foreach ($_SESSION['cart'] as &$item) {
    if ($item['id'] == $product_id && 
        isset($item['customization_key']) && 
        $item['customization_key'] == $customization_key) {
        $item['quantity']++;
        $found = true;
        break;
    }
}

// If not found, add new item to cart
if (!$found) {
    $_SESSION['cart'][] = [
        'id' => $product_id,
        'name' => $product['name'],
        'price' => $total_price,
        'quantity' => 1,
        'customizations' => $customizations,
        'customization_key' => $customization_key,
        'base_price' => $product['price'] // Store base price for reference
    ];
}

// Redirect to cart with success message
header("Location: cart.php?added=1");
exit;
?>