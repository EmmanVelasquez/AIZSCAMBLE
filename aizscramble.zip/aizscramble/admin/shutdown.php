<?php
session_start();
include('../includes/db.php');
include('../includes/log_activity.php');
require_once('../includes/notify_helper.php');

if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../user/login.php");
    exit;
}

// Get unread notification count for the bell icon
$unreadCount = $conn->query("SELECT COUNT(*) as total FROM AdminNotifications WHERE IsRead = 0")->fetch_assoc()['total'];

// Fetch notifications for the dropdown
$notifQuery = $conn->query("SELECT * FROM AdminNotifications ORDER BY CreatedAt DESC LIMIT 5");

// Handle toggle
if (isset($_POST['status'])) {
    $new = $_POST['status'] == '1' ? 1 : 0;
    $conn->query("UPDATE settings SET value='$new' WHERE name='shutdown'");
    
    // Log the activity
    $status_text = $new == 1 ? 'closed' : 'opened';
    logActivity($conn, $_SESSION['user_id'], 'admin', "Shop status changed: $status_text");
    
    // Set success message
    $_SESSION['message'] = "Shop status successfully " . ($new == 1 ? 'closed' : 'opened') . "!";
    
    header("Location: shutdown.php");
    exit;
}

$setting = $conn->query("SELECT * FROM settings WHERE name='shutdown'")->fetch_assoc();
$current = $setting['value'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <title>Shop Status - AIZCAmble</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --error-color: #EF4444;
            --info-color: #3B82F6;
            --shadow-pink: rgba(236, 72, 153, 0.2);
            --shadow-strong: rgba(0, 0, 0, 0.1);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-gradient-start) 0%, var(--background-gradient-end) 100%);
            min-height: 100vh;
            display: flex;
            color: var(--text-primary);
            position: relative;
            overflow-x: hidden;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, var(--primary-pink) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, var(--accent-purple) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, var(--secondary-pink) 0%, transparent 50%);
            opacity: 0.05;
            z-index: -1;
            animation: backgroundFloat 20s ease-in-out infinite;
        }

        @keyframes backgroundFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(-20px, -20px) scale(1.05); }
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary-pink) 0%, var(--primary-pink-dark) 100%);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--border-light);
            box-shadow: 4px 0 20px var(--shadow-pink);
            padding: 0;
            min-height: 100vh;
            position: relative;
            overflow: hidden;
        }

        .sidebar::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.1) 50%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
        }

        @keyframes shimmer {
            0%, 100% { transform: translateX(-100%); }
            50% { transform: translateX(100%); }
        }

        .logo-section {
            text-align: center;
            padding: 32px 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            position: relative;
            z-index: 2;
        }

        .logo-container {
            position: relative;
            display: inline-block;
            margin-bottom: 16px;
        }

        .logo-container::before {
            content: '';
            position: absolute;
            top: -8px;
            left: -8px;
            right: -8px;
            bottom: -8px;
            background: linear-gradient(45deg, rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0.1));
            border-radius: 50%;
            animation: logoGlow 2s ease-in-out infinite;
        }

        @keyframes logoGlow {
            0%, 100% { transform: scale(1); opacity: 0.7; }
            50% { transform: scale(1.05); opacity: 1; }
        }

        .logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(255, 255, 255, 0.9);
            object-fit: cover;
            position: relative;
            z-index: 2;
            transition: all 0.3s ease;
        }

        .logo:hover {
            transform: scale(1.1) rotate(5deg);
        }

        .brand-name {
            color: white;
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 8px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .admin-title {
            color: rgba(255, 255, 255, 0.9);
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-menu {
            padding: 24px 0;
            position: relative;
            z-index: 2;
        }

        .nav-item {
            display: block;
            padding: 16px 24px;
            margin: 8px 16px;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            border-radius: 16px;
            font-weight: 500;
            font-size: 15px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
        }

        .nav-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .nav-item:hover::before {
            left: 100%;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(8px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item.active {
            background: rgba(255, 255, 255, 0.25);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        .main-content {
            flex: 1;
            padding: 32px;
            overflow-y: auto;
            position: relative;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            padding: 24px 32px;
            border-radius: 20px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            position: relative;
            overflow: hidden;
        }

        .header-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .page-title {
            font-size: 32px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* Notification Bell */
        .notification-bell {
            position: relative;
            display: inline-block;
        }

        .notification-bell button {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border: none;
            border-radius: 50%;
            width: 48px;
            height: 48px;
            color: white;
            font-size: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        .notification-bell button:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 20px var(--shadow-pink);
        }

        .notification-badge {
            position: absolute;
            top: -6px;
            right: -6px;
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
            border-radius: 50%;
            padding: 4px 8px;
            font-size: 12px;
            font-weight: 700;
            min-width: 20px;
            text-align: center;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }

        .notification-dropdown {
            display: none;
            position: absolute;
            right: 0;
            top: 60px;
            background: white;
            width: 350px;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            max-height: 400px;
            overflow: hidden;
            border: 1px solid var(--border-light);
        }

        .notification-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 20px;
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            font-weight: 600;
        }

        .notification-header a {
            color: white;
            font-size: 12px;
            text-decoration: none;
            opacity: 0.9;
            transition: opacity 0.2s;
        }

        .notification-header a:hover {
            opacity: 1;
        }

        .notification-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            max-height: 300px;
            overflow-y: auto;
        }

        .notification-dropdown li {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border-light);
            transition: background-color 0.2s;
        }

        .notification-dropdown li:last-child {
            border-bottom: none;
        }

        .notification-dropdown li:hover {
            background-color: rgba(236, 72, 153, 0.05);
        }

        .notification-footer {
            padding: 16px 20px;
            text-align: center;
            border-top: 1px solid var(--border-light);
            background: rgba(236, 72, 153, 0.05);
        }

        .notification-footer a {
            color: var(--primary-pink);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.2s;
        }

        .notification-footer a:hover {
            color: var(--primary-pink-dark);
        }

        /* Alert Messages */
        .message {
            padding: 16px 20px;
            margin-bottom: 24px;
            border-radius: 12px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .success {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(5, 150, 105, 0.1));
            color: var(--success-color);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        /* Status Card */
        .status-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 60vh;
        }

        .status-card {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 32px;
            padding: 64px 48px;
            box-shadow: 0 16px 64px var(--shadow-pink);
            border: 1px solid var(--border-light);
            text-align: center;
            max-width: 600px;
            width: 100%;
            position: relative;
            overflow: hidden;
            animation: cardEntrance 1s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .status-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        .status-card::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.05) 50%, transparent 70%);
            animation: shimmer 4s ease-in-out infinite;
            pointer-events: none;
            border-radius: 32px;
        }

        @keyframes cardEntrance {
            0% {
                opacity: 0;
                transform: translateY(30px) scale(0.95);
            }
            100% {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .status-icon {
            font-size: 120px;
            margin-bottom: 32px;
            animation: iconFloat 3s ease-in-out infinite;
        }

        @keyframes iconFloat {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }

        .status-title {
            font-size: 36px;
            font-weight: 800;
            margin-bottom: 24px;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .status-text {
            font-size: 24px;
            margin-bottom: 40px;
            color: var(--text-secondary);
            font-weight: 500;
        }

        .current-status {
            display: inline-flex;
            align-items: center;
            gap: 12px;
            padding: 16px 32px;
            border-radius: 20px;
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 40px;
            text-transform: uppercase;
            letter-spacing: 1px;
            animation: statusPulse 2s ease-in-out infinite;
        }

        .status-open {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(5, 150, 105, 0.1));
            color: var(--success-color);
            border: 2px solid rgba(16, 185, 129, 0.3);
        }

        .status-closed {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(220, 38, 38, 0.1));
            color: var(--error-color);
            border: 2px solid rgba(239, 68, 68, 0.3);
        }

        @keyframes statusPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.02); }
        }

        .toggle-button {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            border: none;
            border-radius: 16px;
            padding: 20px 40px;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-family: 'Poppins', sans-serif;
            box-shadow: 0 8px 32px var(--shadow-pink);
            display: inline-flex;
            align-items: center;
            gap: 12px;
        }

        .toggle-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .toggle-button:hover::before {
            left: 100%;
        }

        .toggle-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 16px 48px var(--shadow-pink);
            background: linear-gradient(135deg, var(--primary-pink-dark), var(--accent-purple));
        }

        .toggle-button:active {
            transform: translateY(-1px);
        }

        .toggle-button.close-action {
            background: linear-gradient(135deg, var(--error-color), #DC2626);
        }

        .toggle-button.close-action:hover {
            background: linear-gradient(135deg, #DC2626, #B91C1C);
        }

        .toggle-button.open-action {
            background: linear-gradient(135deg, var(--success-color), #059669);
        }

        .toggle-button.open-action:hover {
            background: linear-gradient(135deg, #059669, #047857);
        }

        /* Status Description */
        .status-description {
            background: rgba(236, 72, 153, 0.05);
            border-radius: 16px;
            padding: 24px;
            margin-top: 32px;
            border: 1px solid var(--border-light);
        }

        .status-description h4 {
            color: var(--primary-pink);
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .status-description p {
            color: var(--text-secondary);
            line-height: 1.6;
            margin-bottom: 8px;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .sidebar {
                width: 240px;
            }
        }

        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                min-height: auto;
                position: fixed;
                top: 0;
                left: -100%;
                z-index: 1000;
                transition: left 0.3s ease;
            }
            
            .sidebar.open {
                left: 0;
            }
            
            .main-content {
                padding: 20px;
                margin-top: 0;
            }
            
            .header-section {
                flex-direction: column;
                gap: 16px;
                text-align: center;
            }
            
            .page-title {
                font-size: 24px;
            }
            
            .status-card {
                padding: 40px 32px;
                margin: 20px;
            }
            
            .status-title {
                font-size: 28px;
            }
            
            .status-text {
                font-size: 20px;
            }
            
            .notification-dropdown {
                width: 300px;
                right: -50px;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(236, 72, 153, 0.1);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--primary-pink-dark), var(--primary-pink));
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <div class="logo-container">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo" class="logo">
            </div>
            <div class="brand-name">AIZCAmble</div>
            <div class="admin-title">Admin Panel</div>
        </div>

        <nav class="nav-menu">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                Dashboard
            </a>
            <a href="orders.php" class="nav-item">
                <i class="fas fa-shopping-bag"></i>
                Manage Orders
            </a>
            <a href="add_product.php" class="nav-item">
                <i class="fas fa-plus-circle"></i>
                Add Product
            </a>
            <a href="stock.php" class="nav-item">
                <i class="fas fa-boxes"></i>
                Stock Management
            </a>
            <a href="sales_analytics.php" class="nav-item">
                <i class="fas fa-chart-bar"></i>
                Sales Analytics
            </a>
            <a href="users.php" class="nav-item">
                <i class="fas fa-users"></i>
                Customers
            </a>
            <a href="ingredients.php" class="nav-item">
                <i class="fas fa-flask"></i>
                Ingredients
            </a>
            <a href="admins.php" class="nav-item">
                <i class="fas fa-user-shield"></i>
                Admins
            </a>
            <a href="shutdown.php" class="nav-item active">
                <i class="fas fa-power-off"></i>
                Shutdown Shop
            </a>
            <a href="activity_log.php" class="nav-item">
                <i class="fas fa-history"></i>
                Activity History
            </a>
            <a href="notifications.php" class="nav-item">
                <i class="fas fa-bell"></i>
                Notifications
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header-section">
            <h1 class="page-title">
                <i class="fas fa-power-off"></i>
                Shop Status Control
            </h1>
            
            <!-- Notification Bell -->
            <div class="notification-bell">
                <button onclick="toggleDropdown()">
                    <i class="fas fa-bell"></i>
                    <?php if ($unreadCount > 0): ?>
                        <span class="notification-badge">
                            <?= $unreadCount ?>
                        </span>
                    <?php endif; ?>
                </button>
                <div id="notifDropdown" class="notification-dropdown">
                    <div class="notification-header">
                        <span>Notifications</span>
                        <?php if ($unreadCount > 0): ?>
                            <a href="shutdown.php?mark_read=all">Mark all as read</a>
                        <?php endif; ?>
                    </div>
                    <ul>
                        <?php if ($notifQuery->num_rows > 0): ?>
                            <?php while ($notif = $notifQuery->fetch_assoc()): ?>
                                <li style="<?= $notif['IsRead'] ? '' : 'background-color: rgba(236, 72, 153, 0.05);' ?>">
                                    <strong><?= htmlspecialchars($notif['Title']) ?></strong><br>
                                    <small><?= htmlspecialchars($notif['message']) ?></small><br>
                                    <small style="color: #888;"><?= date('M d, Y h:i A', strtotime($notif['CreatedAt'])) ?></small>
                                </li>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <li>No notifications yet</li>
                        <?php endif; ?>
                    </ul>
                    <div class="notification-footer">
                        <a href="notifications.php">View All Notifications</a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Alert Messages -->
        <?php if (isset($_SESSION['message'])): ?>
            <div class="message success">
                <i class="fas fa-check-circle"></i>
                <?= htmlspecialchars($_SESSION['message']) ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <!-- Status Card -->
        <div class="status-container">
            <div class="status-card">
                <div class="status-icon">
                    <?= $current == 1 ? '🔴' : '🟢' ?>
                </div>
                
                <h2 class="status-title">Shop Status Control</h2>
                
                <p class="status-text">Current Status:</p>
                
                <div class="current-status <?= $current == 1 ? 'status-closed' : 'status-open' ?>">
                    <i class="fas fa-<?= $current == 1 ? 'times-circle' : 'check-circle' ?>"></i>
                    <?= $current == 1 ? 'SHOP CLOSED' : 'SHOP OPEN' ?>
                </div>

                <form method="POST" id="statusForm">
                    <button type="submit" name="status" value="<?= $current == 1 ? 0 : 1 ?>" 
                            class="toggle-button <?= $current == 1 ? 'open-action' : 'close-action' ?>"
                            onclick="return confirmStatusChange(<?= $current ?>)">
                        <i class="fas fa-<?= $current == 1 ? 'play' : 'stop' ?>"></i>
                        <?= $current == 1 ? 'Open Shop' : 'Close Shop' ?>
                    </button>
                </form>

                <div class="status-description">
                    <h4>
                        <i class="fas fa-info-circle"></i>
                        What does this do?
                    </h4>
                    <?php if ($current == 1): ?>
                        <p><strong>Shop is currently CLOSED:</strong></p>
                        <p>• Customers cannot place new orders</p>
                        <p>• Website shows "Shop Closed" message</p>
                        <p>• Existing orders can still be processed</p>
                        <p>• Admin functions remain accessible</p>
                    <?php else: ?>
                        <p><strong>Shop is currently OPEN:</strong></p>
                        <p>• Customers can browse and place orders</p>
                        <p>• All website features are available</p>
                        <p>• Orders are being accepted normally</p>
                        <p>• Full business operations active</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Notification dropdown toggle
        function toggleDropdown() {
            const dropdown = document.getElementById('notifDropdown');
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        }

        // Close dropdown when clicking outside
        window.addEventListener('click', function(event) {
            const dropdown = document.getElementById('notifDropdown');
            const bell = document.querySelector('.notification-bell button');
            if (!bell.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = 'none';
            }
        });

        // Confirm status change
        function confirmStatusChange(currentStatus) {
            const action = currentStatus == 1 ? 'open' : 'close';
            const message = currentStatus == 1 
                ? 'Are you sure you want to OPEN the shop? Customers will be able to place orders.'
                : 'Are you sure you want to CLOSE the shop? Customers will not be able to place new orders.';
            
            return confirm(message);
        }

        // Enhanced button click effect
        document.querySelector('.toggle-button').addEventListener('click', function(e) {
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.cssText = `
                width: ${size}px;
                height: ${size}px;
                left: ${x}px;
                top: ${y}px;
                position: absolute;
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.4);
                transform: scale(0);
                animation: rippleEffect 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275);
                pointer-events: none;
            `;
            
            this.appendChild(ripple);
            
            setTimeout(() => ripple.remove(), 800);
        });

        // Add ripple animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes rippleEffect {
                0% {
                    transform: scale(0);
                    opacity: 1;
                }
                100% {
                    transform: scale(4);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);

        // Mobile sidebar toggle
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('open');
        }

        // Add mobile menu button if needed
        if (window.innerWidth <= 768) {
            const header = document.querySelector('.header-section');
            const menuBtn = document.createElement('button');
            menuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            menuBtn.className = 'btn btn-primary';
            menuBtn.onclick = toggleSidebar;
            menuBtn.style.position = 'absolute';
            menuBtn.style.top = '20px';
            menuBtn.style.left = '20px';
            menuBtn.style.zIndex = '1001';
            document.body.appendChild(menuBtn);
        }

        // Auto-refresh notifications every 30 seconds
        setInterval(function() {
            if (!document.hidden) {
                fetch('shutdown.php?ajax=notifications')
                    .then(response => response.json())
                    .then(data => {
                        if (data.unreadCount !== undefined) {
                            const badge = document.querySelector('.notification-badge');
                            const bellButton = document.querySelector('.notification-bell button');
                            
                            if (data.unreadCount > 0) {
                                if (!badge) {
                                    const newBadge = document.createElement('span');
                                    newBadge.className = 'notification-badge';
                                    newBadge.textContent = data.unreadCount;
                                    bellButton.appendChild(newBadge);
                                } else {
                                    badge.textContent = data.unreadCount;
                                }
                            } else if (badge) {
                                badge.remove();
                            }
                        }
                    })
                    .catch(error => console.log('Notification refresh failed:', error));
            }
        }, 30000);

        // Enhanced status card animations
        document.addEventListener('DOMContentLoaded', function() {
            const statusCard = document.querySelector('.status-card');
            const statusIcon = document.querySelector('.status-icon');
            
            // Add hover effect to status card
            statusCard.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-5px) scale(1.02)';
                this.style.boxShadow = '0 20px 80px var(--shadow-pink)';
            });
            
            statusCard.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
                this.style.boxShadow = '0 16px 64px var(--shadow-pink)';
            });
            
            // Add click animation to status icon
            statusIcon.addEventListener('click', function() {
                this.style.animation = 'none';
                setTimeout(() => {
                    this.style.animation = 'iconFloat 3s ease-in-out infinite';
                }, 10);
            });
        });
    </script>
</body>
</html>