<?php
session_start();
require_once('../db.php');

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../user/login.php");
    exit;
}

// Get export type and date range
$type = isset($_GET['type']) ? $_GET['type'] : 'sales';
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-7 days'));
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

// Set headers for CSV download
header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename="' . ($type == 'sales' ? 'Sales_Report_' : 'Inventory_Report_') . date('Y-m-d') . '.csv"');

// Create a file pointer connected to the output stream
$output = fopen('php://output', 'w');

// Add UTF-8 BOM to fix Excel display issues with special characters
fputs($output, "\xEF\xBB\xBF");

if ($type == 'sales') {
    // Set column headers for sales report
    fputcsv($output, ['Product Name', 'Date of Sale', 'Total Quantity Sold', 'Number of Transactions', 'Total Sales Amount']);
    
    // Daily Sales Analytics Query
    $sales_query = "
        SELECT 
            p.id AS product_id,
            p.name AS product_name,
            DATE(o.created_at) AS sale_date,
            SUM(oi.quantity) AS total_quantity,
            COUNT(DISTINCT o.id) AS transaction_count,
            SUM(oi.quantity * oi.price) AS total_sales
        FROM 
            products p
        JOIN 
            order_items oi ON p.id = oi.product_id
        JOIN 
            orders o ON oi.order_id = o.id
        WHERE 
            o.status = 'delivered'
            AND DATE(o.created_at) BETWEEN ? AND ?
        GROUP BY 
            p.id, p.name, DATE(o.created_at)
        ORDER BY 
            sale_date DESC, p.name ASC
    ";

    $stmt = $conn->prepare($sales_query);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Output each row of data
    while ($row = $result->fetch_assoc()) {
        fputcsv($output, [
            $row['product_name'],
            $row['sale_date'],
            $row['total_quantity'],
            $row['transaction_count'],
            $row['total_sales']
        ]);
    }
    
} else {
    // Set column headers for inventory report
    fputcsv($output, ['Product Name', 'Initial Stock', 'Total Sold', 'Current QOH', 'Status']);
    
    // Inventory/Stock Query
    $inventory_query = "
        SELECT 
            p.id AS product_id,
            p.name AS product_name,
            p.stock AS initial_stock,
            COALESCE(SUM(oi.quantity), 0) AS total_sold
        FROM 
            products p
        LEFT JOIN 
            order_items oi ON p.id = oi.product_id
        LEFT JOIN 
            orders o ON oi.order_id = o.id AND o.status = 'delivered'
        GROUP BY 
            p.id, p.name, p.stock
        ORDER BY 
            p.name ASC
    ";

    $result = $conn->query($inventory_query);
    
    // Output each row of data
    while ($row = $result->fetch_assoc()) {
        $current_qoh = $row['initial_stock'] - $row['total_sold'];
        
        if ($current_qoh <= 0) {
            $status = 'Out of Stock';
        } elseif ($current_qoh <= 5) {
            $status = 'Low Stock';
        } else {
            $status = 'In Stock';
        }
        
        fputcsv($output, [
            $row['product_name'],
            $row['initial_stock'],
            $row['total_sold'],
            $current_qoh,
            $status
        ]);
    }
}

exit;