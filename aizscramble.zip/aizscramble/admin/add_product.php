<?php
session_start();
include('../includes/db.php');
include('../includes/log_activity.php');

if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../user/login.php");
    exit;
}

$ingredients = [];
$result = $conn->query("SELECT id, name, unit FROM ingredients ORDER BY name");
if ($result) {
    $ingredients = $result->fetch_all(MYSQLI_ASSOC);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $price = floatval($_POST['price']);
    $stock = intval($_POST['stock']);
    $is_customizable = isset($_POST['is_customizable']) ? 1 : 0;
    $description = $_POST['description'] ?? "Product description text here...";

    $image_path = null;
    if (!empty($_FILES['product_image']['name'])) {
        $image_name = basename($_FILES["product_image"]["name"]);
        $target_dir = "../uploads/";
        $unique_name = time() . "_" . $image_name;
        $target_file = $target_dir . $unique_name;

        if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
            $image_path = $target_file;
        }
    }

    try {
        $conn->autocommit(false);

        $stmt = $conn->prepare("INSERT INTO products (name, price, stock, is_customizable, description, image) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sdiiss", $name, $price, $stock, $is_customizable, $description, $image_path);
        $stmt->execute();
        $product_id = $stmt->insert_id;

        if (!empty($_POST['ingredient_id'])) {
            foreach ($_POST['ingredient_id'] as $index => $ingredient_id) {
                $quantity = floatval($_POST['ingredient_quantity'][$index]);
                if ($ingredient_id && $quantity > 0) {
                    $stmt = $conn->prepare("INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES (?, ?, ?)");
                    $stmt->bind_param("iid", $product_id, $ingredient_id, $quantity);
                    $stmt->execute();
                }
            }
        }

        if ($is_customizable) {
            if (!empty($_POST['size_names'])) {
                $stmt = $conn->prepare("INSERT INTO customizable_options (product_id, option_name, option_value, price) VALUES (?, 'Size', ?, ?)");
                foreach ($_POST['size_names'] as $i => $size_name) {
                    if (!empty($size_name) && isset($_POST['size_prices'][$i])) {
                        $stmt->bind_param("isd", $product_id, $size_name, $_POST['size_prices'][$i]);
                        $stmt->execute();
                    }
                }
            }

            if (!empty($_POST['flavor_names'])) {
                $stmt = $conn->prepare("INSERT INTO customizable_options (product_id, option_name, option_value, price) VALUES (?, 'Flavor', ?, ?)");
                foreach ($_POST['flavor_names'] as $i => $flavor_name) {
                    if (!empty($flavor_name) && isset($_POST['flavor_prices'][$i])) {
                        $stmt->bind_param("isd", $product_id, $flavor_name, $_POST['flavor_prices'][$i]);
                        $stmt->execute();
                    }
                }
            }

            if (!empty($_POST['add_on_names'])) {
                $stmt = $conn->prepare("INSERT INTO customizable_options (product_id, option_name, option_value, price) VALUES (?, 'Add-on', ?, ?)");
                foreach ($_POST['add_on_names'] as $i => $add_on_name) {
                    if (!empty($add_on_name) && isset($_POST['add_on_prices'][$i])) {
                        $stmt->bind_param("isd", $product_id, $add_on_name, $_POST['add_on_prices'][$i]);
                        $stmt->execute();
                    }
                }
            }
        }

        $conn->commit();
        logActivity($conn, $_SESSION['user_id'], 'admin', "Added new product: $name");
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                showSuccessMessage('Product added successfully!');
                setTimeout(() => {
                    window.location.reload();
                }, 2000);
            });
        </script>";
    } catch (Exception $e) {
        $conn->rollback();
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                showErrorMessage('Error adding product: " . addslashes($e->getMessage()) . "');
            });
        </script>";
    } finally {
        $conn->autocommit(true);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product - AIZCAmble</title>
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --error-color: #EF4444;
            --info-color: #3B82F6;
            --shadow-pink: rgba(236, 72, 153, 0.2);
            --shadow-strong: rgba(0, 0, 0, 0.1);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-gradient-start) 0%, var(--background-gradient-end) 100%);
            min-height: 100vh;
            display: flex;
            color: var(--text-primary);
            position: relative;
            overflow-x: hidden;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, var(--primary-pink) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, var(--accent-purple) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, var(--secondary-pink) 0%, transparent 50%);
            opacity: 0.05;
            z-index: -1;
            animation: backgroundFloat 20s ease-in-out infinite;
        }

        @keyframes backgroundFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(-20px, -20px) scale(1.05); }
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary-pink) 0%, var(--primary-pink-dark) 100%);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--border-light);
            box-shadow: 4px 0 20px var(--shadow-pink);
            padding: 0;
            min-height: 100vh;
            position: relative;
            overflow: hidden;
        }

        .sidebar::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.1) 50%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
        }

        @keyframes shimmer {
            0%, 100% { transform: translateX(-100%); }
            50% { transform: translateX(100%); }
        }

        .logo-section {
            text-align: center;
            padding: 32px 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            position: relative;
            z-index: 2;
        }

        .logo-container {
            position: relative;
            display: inline-block;
            margin-bottom: 16px;
        }

        .logo-container::before {
            content: '';
            position: absolute;
            top: -8px;
            left: -8px;
            right: -8px;
            bottom: -8px;
            background: linear-gradient(45deg, rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0.1));
            border-radius: 50%;
            animation: logoGlow 2s ease-in-out infinite;
        }

        @keyframes logoGlow {
            0%, 100% { transform: scale(1); opacity: 0.7; }
            50% { transform: scale(1.05); opacity: 1; }
        }

        .logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(255, 255, 255, 0.9);
            object-fit: cover;
            position: relative;
            z-index: 2;
            transition: all 0.3s ease;
        }

        .logo:hover {
            transform: scale(1.1) rotate(5deg);
        }

        .brand-name {
            color: white;
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 8px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .admin-title {
            color: rgba(255, 255, 255, 0.9);
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-menu {
            padding: 24px 0;
            position: relative;
            z-index: 2;
        }

        .nav-item {
            display: block;
            padding: 16px 24px;
            margin: 8px 16px;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            border-radius: 16px;
            font-weight: 500;
            font-size: 15px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
        }

        .nav-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .nav-item:hover::before {
            left: 100%;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(8px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item.active {
            background: rgba(255, 255, 255, 0.25);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        .main-content {
            flex: 1;
            padding: 32px;
            overflow-y: auto;
            position: relative;
        }

        .header-section {
            text-align: center;
            margin-bottom: 40px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            padding: 32px;
            border-radius: 24px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            position: relative;
            overflow: hidden;
        }

        .header-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .page-title {
            font-size: 36px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 12px;
        }

        .page-subtitle {
            color: var(--text-secondary);
            font-size: 18px;
            font-weight: 500;
        }

        /* Form Container */
        .form-container {
            max-width: 800px;
            margin: 0 auto;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            position: relative;
            overflow: hidden;
        }

        .form-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        /* Form Sections */
        .form-section {
            margin-bottom: 32px;
            padding: 24px;
            background: linear-gradient(135deg, rgba(236, 72, 153, 0.05), rgba(139, 92, 246, 0.05));
            border-radius: 16px;
            border: 1px solid var(--border-light);
        }

        .section-title {
            font-size: 20px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .section-title i {
            color: var(--primary-pink);
            font-size: 18px;
        }

        /* Form Elements */
        .form-group {
            margin-bottom: 24px;
        }

        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 24px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--text-primary);
            font-size: 15px;
        }

        .required {
            color: var(--error-color);
        }

        input[type="text"],
        input[type="number"],
        input[type="file"],
        textarea,
        select {
            width: 100%;
            padding: 16px 20px;
            border: 2px solid var(--border-light);
            border-radius: 16px;
            font-size: 15px;
            font-weight: 500;
            background: rgba(255, 255, 255, 0.9);
            transition: all 0.3s ease;
            outline: none;
            font-family: 'Poppins', sans-serif;
        }

        input[type="text"]:focus,
        input[type="number"]:focus,
        input[type="file"]:focus,
        textarea:focus,
        select:focus {
            border-color: var(--primary-pink);
            background: white;
            box-shadow: 0 0 0 4px rgba(236, 72, 153, 0.1);
            transform: translateY(-2px);
        }

        textarea {
            min-height: 120px;
            resize: vertical;
        }

        input::placeholder,
        textarea::placeholder {
            color: var(--text-light);
        }

        /* Checkbox Styling */
        .checkbox-container {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 24px;
            padding: 16px 20px;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 16px;
            border: 2px solid var(--border-light);
            transition: all 0.3s ease;
        }

        .checkbox-container:hover {
            border-color: var(--primary-pink);
            background: white;
        }

        .checkbox-container input[type="checkbox"] {
            width: 20px;
            height: 20px;
            accent-color: var(--primary-pink);
            margin: 0;
        }

        .checkbox-label {
            font-weight: 600;
            color: var(--text-primary);
            margin: 0;
            cursor: pointer;
        }

        /* Custom Options Section */
        .custom-options {
            margin-top: 24px;
            padding: 24px;
            background: linear-gradient(135deg, rgba(139, 92, 246, 0.05), rgba(236, 72, 153, 0.05));
            border-radius: 16px;
            border: 2px dashed var(--border-light);
            transition: all 0.3s ease;
        }

        .custom-options.show {
            border-color: var(--primary-pink);
            background: linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(236, 72, 153, 0.1));
        }

        .option-group {
            margin-bottom: 32px;
        }

        .option-group:last-child {
            margin-bottom: 0;
        }

        .option-item {
            display: flex;
            gap: 12px;
            margin-bottom: 12px;
            align-items: center;
            padding: 16px;
            background: white;
            border-radius: 12px;
            border: 1px solid var(--border-light);
            transition: all 0.3s ease;
        }

        .option-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .option-item input {
            margin: 0;
            flex: 1;
        }

        /* Ingredient Row */
        .ingredient-row {
            display: flex;
            gap: 12px;
            margin-bottom: 12px;
            align-items: center;
            padding: 16px;
            background: white;
            border-radius: 12px;
            border: 1px solid var(--border-light);
            transition: all 0.3s ease;
        }

        .ingredient-row:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .ingredient-row select,
        .ingredient-row input[type="number"] {
            flex: 1;
            margin: 0;
        }

        .ingredient-unit {
            min-width: 80px;
            padding: 8px 12px;
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 600;
            text-align: center;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            border: none;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            font-family: 'Poppins', sans-serif;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            font-size: 16px;
            padding: 16px 32px;
            margin-top: 32px;
            width: 100%;
            justify-content: center;
        }

        .btn-secondary {
            background: linear-gradient(135deg, var(--accent-purple), var(--accent-purple-light));
            color: white;
        }

        .btn-add {
            background: linear-gradient(135deg, var(--success-color), #059669);
            color: white;
            margin-top: 16px;
        }

        .btn-remove {
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
            padding: 8px 12px;
            font-size: 12px;
        }

        /* File Upload Styling */
        .file-upload-container {
            position: relative;
            display: inline-block;
            width: 100%;
        }

        .file-upload-label {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            padding: 24px;
            border: 2px dashed var(--border-light);
            border-radius: 16px;
            background: rgba(255, 255, 255, 0.9);
            cursor: pointer;
            transition: all 0.3s ease;
            color: var(--text-secondary);
            font-weight: 500;
        }

        .file-upload-label:hover {
            border-color: var(--primary-pink);
            background: white;
            color: var(--primary-pink);
        }

        .file-upload-label i {
            font-size: 24px;
        }

        input[type="file"] {
            position: absolute;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }

        .current-image {
            max-width: 200px;
            max-height: 200px;
            display: block;
            margin: 16px 0;
            border-radius: 12px;
            border: 2px solid var(--border-light);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-light);
        }

        .empty-state i {
            font-size: 48px;
            margin-bottom: 16px;
            color: var(--primary-pink);
            opacity: 0.5;
        }

        .empty-state h3 {
            font-size: 18px;
            margin-bottom: 8px;
            color: var(--text-secondary);
        }

        .empty-state p {
            font-size: 14px;
        }

        /* Toast Notifications */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .toast {
            min-width: 350px;
            background: white;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
            overflow: hidden;
            transform: translateX(120%);
            animation: slideIn 0.5s forwards, fadeOut 0.5s 4.5s forwards;
            border: 1px solid var(--border-light);
        }

        .toast-header {
            padding: 16px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
            font-weight: 600;
        }

        .toast-body {
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .toast-icon {
            font-size: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            color: white;
        }

        .toast-content {
            flex: 1;
        }

        .toast-title {
            font-weight: 600;
            margin-bottom: 4px;
            color: var(--text-primary);
        }

        .toast-message {
            font-size: 14px;
            color: var(--text-secondary);
        }

        .toast-close {
            background: none;
            border: none;
            color: white;
            font-size: 18px;
            cursor: pointer;
            opacity: 0.8;
            transition: opacity 0.2s;
            padding: 4px;
            border-radius: 4px;
        }

        .toast-close:hover {
            opacity: 1;
            background: rgba(255, 255, 255, 0.2);
        }

        .toast-progress {
            height: 4px;
            background: rgba(255, 255, 255, 0.3);
            width: 100%;
        }

        .toast-progress-bar {
            height: 100%;
            width: 100%;
            background: rgba(255, 255, 255, 0.8);
            animation: progressShrink 5s linear forwards;
        }

        @keyframes slideIn {
            from { transform: translateX(120%); }
            to { transform: translateX(0); }
        }

        @keyframes fadeOut {
            from { opacity: 1; transform: translateX(0); }
            to { opacity: 0; transform: translateX(120%); }
        }

        @keyframes progressShrink {
            from { width: 100%; }
            to { width: 0%; }
        }

        .toast-success .toast-header {
            background: linear-gradient(135deg, var(--success-color), #059669);
        }

        .toast-error .toast-header {
            background: linear-gradient(135deg, var(--error-color), #DC2626);
        }

        .toast-warning .toast-header {
            background: linear-gradient(135deg, var(--warning-color), #D97706);
        }

        .toast-info .toast-header {
            background: linear-gradient(135deg, var(--info-color), #2563EB);
        }

        /* Loading Animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .sidebar {
                width: 240px;
            }
        }

        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                min-height: auto;
                position: fixed;
                top: 0;
                left: -100%;
                z-index: 1000;
                transition: left 0.3s ease;
            }
            
            .sidebar.open {
                left: 0;
            }
            
            .main-content {
                padding: 20px;
                margin-top: 0;
            }
            
            .header-section {
                padding: 24px 20px;
            }
            
            .form-container {
                padding: 24px 20px;
            }
            
            .form-row {
                grid-template-columns: 1fr;
                gap: 16px;
            }
            
            .option-item,
            .ingredient-row {
                flex-direction: column;
                gap: 12px;
            }
            
            .option-item input,
            .ingredient-row select,
            .ingredient-row input {
                width: 100%;
            }
            
            .toast {
                min-width: 300px;
                right: 10px;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(236, 72, 153, 0.1);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--primary-pink-dark), var(--primary-pink));
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <div class="logo-container">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo" class="logo">
            </div>
            <div class="brand-name">AIZCAmble</div>
            <div class="admin-title">Admin Panel</div>
        </div>

        <nav class="nav-menu">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                Dashboard
            </a>
            <a href="orders.php" class="nav-item">
                <i class="fas fa-shopping-bag"></i>
                Manage Orders
            </a>
            <a href="add_product.php" class="nav-item active">
                <i class="fas fa-plus-circle"></i>
                Add Product
            </a>
            <a href="stock.php" class="nav-item">
                <i class="fas fa-boxes"></i>
                Stock Management
            </a>
            <a href="sales_analytics.php" class="nav-item">
                <i class="fas fa-chart-bar"></i>
                Sales Analytics
            </a>
            <a href="users.php" class="nav-item">
                <i class="fas fa-users"></i>
                Customers
            </a>
            <a href="ingredients.php" class="nav-item">
                <i class="fas fa-flask"></i>
                Ingredients
            </a>
            <a href="admins.php" class="nav-item">
                <i class="fas fa-user-shield"></i>
                Admins
            </a>
            <a href="shutdown.php" class="nav-item">
                <i class="fas fa-power-off"></i>
                Shutdown Shop
            </a>
            <a href="activity_log.php" class="nav-item">
                <i class="fas fa-history"></i>
                Activity History
            </a>
            <a href="notifications.php" class="nav-item">
                <i class="fas fa-bell"></i>
                Notifications
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header-section">
            <h1 class="page-title">Add New Product</h1>
            <p class="page-subtitle">Create and customize products for your menu</p>
        </div>

        <!-- Form Container -->
        <div class="form-container">
            <form method="POST" enctype="multipart/form-data" id="productForm">
                <!-- Basic Information Section -->
                <div class="form-section">
                    <h3 class="section-title">
                        <i class="fas fa-info-circle"></i>
                        Basic Information
                    </h3>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="name">Product Name <span class="required">*</span></label>
                            <input type="text" id="name" name="name" placeholder="Enter product name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="price">Base Price (₱) <span class="required">*</span></label>
                            <input type="number" id="price" step="0.01" name="price" placeholder="0.00" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="stock">Initial Stock <span class="required">*</span></label>
                            <input type="number" id="stock" name="stock" placeholder="Enter stock quantity" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" placeholder="Enter a detailed description of your product..."></textarea>
                    </div>
                </div>

                <!-- Product Image Section -->
                <div class="form-section">
                    <h3 class="section-title">
                        <i class="fas fa-image"></i>
                        Product Image
                    </h3>
                    
                    <div class="form-group">
                        <div class="file-upload-container">
                            <label for="product_image" class="file-upload-label">
                                <i class="fas fa-cloud-upload-alt"></i>
                                <span>Click to upload product image</span>
                            </label>
                            <input type="file" id="product_image" name="product_image" accept="image/*">
                        </div>
                    </div>
                </div>

                <!-- Customization Section -->
                <div class="form-section">
                    <h3 class="section-title">
                        <i class="fas fa-cogs"></i>
                        Customization Options
                    </h3>
                    
                    <div class="checkbox-container">
                        <input type="checkbox" name="is_customizable" id="toggleCustom">
                        <label for="toggleCustom" class="checkbox-label">
                            <i class="fas fa-magic"></i>
                            Enable product customization (sizes, flavors, add-ons)
                        </label>
                    </div>

                    <div id="customOptions" class="custom-options" style="display:none;">
                        <!-- Sizes -->
                        <div class="option-group">
                            <h4 class="section-title">
                                <i class="fas fa-expand-arrows-alt"></i>
                                Sizes
                            </h4>
                            <div id="sizes-container">
                                <div class="option-item">
                                    <input type="text" name="size_names[]" placeholder="Size name (e.g., Small, Medium, Large)">
                                    <input type="number" step="0.01" name="size_prices[]" placeholder="Additional price">
                                </div>
                            </div>
                            <button type="button" class="btn btn-add" onclick="addSize()">
                                <i class="fas fa-plus"></i>
                                Add Size Option
                            </button>
                        </div>

                        <!-- Flavors -->
                        <div class="option-group">
                            <h4 class="section-title">
                                <i class="fas fa-palette"></i>
                                Flavors
                            </h4>
                            <div id="flavors-container">
                                <div class="option-item">
                                    <input type="text" name="flavor_names[]" placeholder="Flavor name (e.g., Vanilla, Chocolate)">
                                    <input type="number" step="0.01" name="flavor_prices[]" placeholder="Additional price">
                                </div>
                            </div>
                            <button type="button" class="btn btn-add" onclick="addFlavor()">
                                <i class="fas fa-plus"></i>
                                Add Flavor Option
                            </button>
                        </div>

                        <!-- Add-ons -->
                        <div class="option-group">
                            <h4 class="section-title">
                                <i class="fas fa-plus-square"></i>
                                Add-ons
                            </h4>
                            <div id="addons-container">
                                <div class="option-item">
                                    <input type="text" name="add_on_names[]" placeholder="Add-on name (e.g., Extra Cheese, Whipped Cream)">
                                    <input type="number" step="0.01" name="add_on_prices[]" placeholder="Additional price">
                                </div>
                            </div>
                            <button type="button" class="btn btn-add" onclick="addAddOn()">
                                <i class="fas fa-plus"></i>
                                Add Add-on Option
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Ingredients Section -->
                <div class="form-section">
                    <h3 class="section-title">
                        <i class="fas fa-flask"></i>
                        Ingredients
                    </h3>
                    
                    <div id="ingredients-container">
                        <?php if (!empty($ingredients)): ?>
                            <div class="ingredient-row">
                                <select name="ingredient_id[]">
                                    <option value="">Select Ingredient</option>
                                    <?php foreach ($ingredients as $ing): ?>
                                        <option value="<?= $ing['id'] ?>"><?= htmlspecialchars($ing['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="number" step="0.01" name="ingredient_quantity[]" placeholder="Quantity needed">
                                <span class="ingredient-unit"></span>
                                <button type="button" class="btn btn-remove" onclick="this.parentNode.remove()">
                                    <i class="fas fa-trash"></i>
                                    Remove
                                </button>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-flask"></i>
                                <h3>No Ingredients Available</h3>
                                <p>Please add ingredients first before creating products.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if (!empty($ingredients)): ?>
                        <button type="button" class="btn btn-add" onclick="addIngredient()">
                            <i class="fas fa-plus"></i>
                            Add Ingredient
                        </button>
                    <?php endif; ?>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="btn btn-primary" id="submitBtn">
                    <i class="fas fa-plus-circle"></i>
                    <span>Add Product</span>
                </button>
            </form>
        </div>
    </div>

    <!-- Toast Notification Container -->
    <div id="toastContainer" class="toast-container"></div>

    <script>
        // Toggle custom options
        document.getElementById('toggleCustom').addEventListener('change', function() {
            const customOptions = document.getElementById('customOptions');
            if (this.checked) {
                customOptions.style.display = 'block';
                customOptions.classList.add('show');
            } else {
                customOptions.style.display = 'none';
                customOptions.classList.remove('show');
            }
        });

        // Add size option
        function addSize() {
            const container = document.getElementById('sizes-container');
            const div = document.createElement('div');
            div.className = 'option-item';
            div.innerHTML = `
                <input type="text" name="size_names[]" placeholder="Size name (e.g., Small, Medium, Large)">
                <input type="number" step="0.01" name="size_prices[]" placeholder="Additional price">
                <button type="button" class="btn btn-remove" onclick="this.parentNode.remove()">
                    <i class="fas fa-trash"></i>
                    Remove
                </button>
            `;
            container.appendChild(div);
        }

        // Add flavor option
        function addFlavor() {
            const container = document.getElementById('flavors-container');
            const div = document.createElement('div');
            div.className = 'option-item';
            div.innerHTML = `
                <input type="text" name="flavor_names[]" placeholder="Flavor name (e.g., Vanilla, Chocolate)">
                <input type="number" step="0.01" name="flavor_prices[]" placeholder="Additional price">
                <button type="button" class="btn btn-remove" onclick="this.parentNode.remove()">
                    <i class="fas fa-trash"></i>
                    Remove
                </button>
            `;
            container.appendChild(div);
        }

        // Add add-on option
        function addAddOn() {
            const container = document.getElementById('addons-container');
            const div = document.createElement('div');
            div.className = 'option-item';
            div.innerHTML = `
                <input type="text" name="add_on_names[]" placeholder="Add-on name (e.g., Extra Cheese, Whipped Cream)">
                <input type="number" step="0.01" name="add_on_prices[]" placeholder="Additional price">
                <button type="button" class="btn btn-remove" onclick="this.parentNode.remove()">
                    <i class="fas fa-trash"></i>
                    Remove
                </button>
            `;
            container.appendChild(div);
        }

        // Add ingredient
        function addIngredient() {
            const container = document.getElementById('ingredients-container');
            const div = document.createElement('div');
            div.className = 'ingredient-row';
            div.innerHTML = `
                <select name="ingredient_id[]">
                    <option value="">Select Ingredient</option>
                    <?php foreach ($ingredients as $ing): ?>
                        <option value="<?= $ing['id'] ?>"><?= htmlspecialchars($ing['name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="number" step="0.01" name="ingredient_quantity[]" placeholder="Quantity needed">
                <span class="ingredient-unit"></span>
                <button type="button" class="btn btn-remove" onclick="this.parentNode.remove()">
                    <i class="fas fa-trash"></i>
                    Remove
                </button>
            `;
            container.appendChild(div);
            
            // Add event listener to update unit when ingredient is selected
            const select = div.querySelector('select');
            select.addEventListener('change', function() {
                const selectedId = this.value;
                const unitSpan = this.parentNode.querySelector('.ingredient-unit');
                <?php foreach ($ingredients as $ing): ?>
                    if (selectedId == "<?= $ing['id'] ?>") {
                        unitSpan.textContent = "<?= htmlspecialchars($ing['unit']) ?>";
                    }
                <?php endforeach; ?>
                if (!selectedId) unitSpan.textContent = '';
            });
        }

        // Initialize unit display for existing ingredient rows
        document.querySelectorAll('#ingredients-container select').forEach(select => {
            select.addEventListener('change', function() {
                const selectedId = this.value;
                const unitSpan = this.parentNode.querySelector('.ingredient-unit');
                <?php foreach ($ingredients as $ing): ?>
                    if (selectedId == "<?= $ing['id'] ?>") {
                        unitSpan.textContent = "<?= htmlspecialchars($ing['unit']) ?>";
                    }
                <?php endforeach; ?>
                if (!selectedId) unitSpan.textContent = '';
            });
            select.dispatchEvent(new Event('change'));
        });

        // File upload preview
        document.getElementById('product_image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const label = document.querySelector('.file-upload-label');
                    label.innerHTML = `
                        <i class="fas fa-check-circle"></i>
                        <span>Image selected: ${file.name}</span>
                    `;
                    label.style.borderColor = 'var(--success-color)';
                    label.style.color = 'var(--success-color)';
                };
                reader.readAsDataURL(file);
            }
        });

        // Form submission with loading state
        document.getElementById('productForm').addEventListener('submit', function(e) {
            const submitBtn = document.getElementById('submitBtn');
            const originalContent = submitBtn.innerHTML;
            
            submitBtn.innerHTML = `
                <div class="loading"></div>
                <span>Adding Product...</span>
            `;
            submitBtn.disabled = true;
            
            // Reset button after 5 seconds if form doesn't redirect
            setTimeout(() => {
                submitBtn.innerHTML = originalContent;
                submitBtn.disabled = false;
            }, 5000);
        });

        // Toast notification functions
        function showSuccessMessage(message) {
            showToast('success', 'Success!', message, '<i class="fas fa-check-circle"></i>');
        }

        function showErrorMessage(message) {
            showToast('error', 'Error!', message, '<i class="fas fa-exclamation-circle"></i>');
        }

        function showToast(type, title, message, icon = '') {
            const toastContainer = document.getElementById('toastContainer');
            
            // Create toast element
            const toast = document.createElement('div');
            toast.className = `toast toast-${type}`;
            
            // Create toast content
            toast.innerHTML = `
                <div class="toast-header">
                    <span>${title}</span>
                    <button class="toast-close" onclick="this.parentElement.parentElement.remove()">×</button>
                </div>
                <div class="toast-body">
                    <div class="toast-icon">${icon}</div>
                    <div class="toast-content">
                        <div class="toast-message">${message}</div>
                    </div>
                </div>
                <div class="toast-progress">
                    <div class="toast-progress-bar"></div>
                </div>
            `;
            
            // Add to container
            toastContainer.appendChild(toast);
            
            // Remove after animation completes
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.remove();
                }
            }, 5000);
        }

        // Mobile sidebar toggle (for responsive design)
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('open');
        }

        // Add mobile menu button if needed
        if (window.innerWidth <= 768) {
            const header = document.querySelector('.header-section');
            const menuBtn = document.createElement('button');
            menuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            menuBtn.className = 'btn btn-secondary';
            menuBtn.onclick = toggleSidebar;
            menuBtn.style.position = 'absolute';
            menuBtn.style.top = '20px';
            menuBtn.style.left = '20px';
            header.appendChild(menuBtn);
        }

        // Form validation
        document.getElementById('productForm').addEventListener('input', function(e) {
            const target = e.target;
            if (target.hasAttribute('required') && target.value.trim() === '') {
                target.style.borderColor = 'var(--error-color)';
            } else {
                target.style.borderColor = 'var(--border-light)';
            }
        });

        // Price formatting
        document.getElementById('price').addEventListener('input', function(e) {
            const value = parseFloat(e.target.value);
            if (value < 0) {
                e.target.value = 0;
            }
        });

        // Stock validation
        document.getElementById('stock').addEventListener('input', function(e) {
            const value = parseInt(e.target.value);
            if (value < 0) {
                e.target.value = 0;
            }
        });
    </script>
</body>
</html>