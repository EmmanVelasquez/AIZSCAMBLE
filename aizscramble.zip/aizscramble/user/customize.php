<?php
session_start();
include('../includes/db.php');


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}


$product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;


$product = $conn->query("SELECT * FROM products WHERE id = $product_id")->fetch_assoc();

if (!$product) {
    header("Location: ../index.php");
    exit;
}


$options_query = $conn->query("
    SELECT option_name, option_value, price 
    FROM customizable_options 
    WHERE product_id = $product_id
    ORDER BY option_name, option_value
");

$customizable_options = [];
$base_price = $product['price'];
$total_price = $base_price;

while ($option = $options_query->fetch_assoc()) {
    $customizable_options[$option['option_name']][] = [
        'value' => $option['option_value'],
        'price' => $option['price']
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customize Product - AIZ Scramble Shop</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: hsl(343, 96%, 89%);
        }
        .navbar {
            background-color: hsl(293, 51%, 74%);
            color: white;
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar h2 {
            margin: 0;
            font-size: 24px;
        }
        .navbar a {
            color: white;
            margin-left: 20px;
            text-decoration: none;
            font-weight: bold;
        }
        .navbar a:hover {
            text-decoration: underline;
        }
        .content {
            padding: 30px;
            text-align: center;
        }
        .product-details {
            background: white;
            padding: 20px;
            margin: 30px auto;
            width: 400px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2d4732;
            font-size: 28px;
        }
        .btn {
            background: hsl(293, 51%, 74%);
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            cursor: pointer;
            margin-top: 10px;
            border: none;
            font-size: 16px;
        }
        .btn:hover {
            background: hsl(293, 51%, 65%);
        }
        .input-group {
            margin: 15px 0;
            text-align: left;
        }
        .input-group label {
            font-size: 16px;
            display: block;
            margin-bottom: 8px;
        }
        .option-item {
            display: flex;
            align-items: center;
            margin: 5px 0;
        }
        .option-item input[type="radio"],
        .option-item input[type="checkbox"] {
            width: auto;
            margin: 0 10px 0 0;
        }
        .option-item label {
            margin: 0;
            font-weight: normal;
            flex-grow: 1;
        }
        .option-price {
            color: #27ae60;
            font-weight: bold;
            margin-left: 10px;
        }
        .price-display {
            font-size: 20px;
            font-weight: bold;
            margin: 20px 0;
            color: #2d4732;
        }
        .base-price {
            color: #7f8c8d;
        }
    </style>
    <script>
        function updateTotalPrice() {
            let total = <?= $base_price ?>;
            
           
            const sizeRadios = document.querySelectorAll('input[name="size"]:checked');
            if (sizeRadios.length > 0) {
                total += parseFloat(sizeRadios[0].dataset.price);
            }
            
            
            const flavorRadios = document.querySelectorAll('input[name="flavor"]:checked');
            if (flavorRadios.length > 0) {
                total += parseFloat(flavorRadios[0].dataset.price);
            }
            
            
            const addOns = document.querySelectorAll('input[name="add_ons[]"]:checked');
            addOns.forEach(addon => {
                total += parseFloat(addon.dataset.price);
            });
            
            document.getElementById('total-price').textContent = '₱' + total.toFixed(2);
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            
            const allOptions = document.querySelectorAll('input[type="radio"], input[type="checkbox"]');
            allOptions.forEach(option => {
                option.addEventListener('change', updateTotalPrice);
            });
            
            
            updateTotalPrice();
        });
    </script>
</head>
<body>

<div class="navbar">
<h2><a href="../home.php" style="text-decoration: none; color: inherit;">AIZ Scramble Shop</a></h2>
    <div>
        <a href="../index.php">Home</a>
        <a href="cart.php">Cart</a>
    </div>
</div>

<div class="content">
    <h1>Customize <?= htmlspecialchars($product['name']) ?></h1>

    <div class="product-details">
        <img src="<?= htmlspecialchars($product['image']) ?>" alt="Product Image" width="100%">
        <div class="price-display">
            <span class="base-price">Base Price: ₱<?= number_format($base_price, 2) ?></span><br>
            Total: <span id="total-price">₱<?= number_format($base_price, 2) ?></span>
        </div>

      
        <form method="POST" action="process_customization.php">
            <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
            
            <?php if (!empty($customizable_options)): ?>
                <?php foreach ($customizable_options as $option_name => $options): ?>
                    <div class="input-group">
                        <label><?= htmlspecialchars($option_name) ?>:</label>
                        
                        <?php if ($option_name == 'Add-on'): ?>
                           
                            <?php foreach ($options as $option): ?>
                                <div class="option-item">
                                    <input type="checkbox" 
                                           name="add_ons[]" 
                                           value="<?= htmlspecialchars($option['value']) ?>" 
                                           id="addon_<?= htmlspecialchars($option['value']) ?>" 
                                           data-price="<?= $option['price'] ?>">
                                    <label for="addon_<?= htmlspecialchars($option['value']) ?>">
                                        <?= htmlspecialchars($option['value']) ?>
                                        <?php if ($option['price'] > 0): ?>
                                            <span class="option-price">+₱<?= number_format($option['price'], 2) ?></span>
                                        <?php endif; ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            
                            <?php foreach ($options as $option): ?>
                                <div class="option-item">
                                    <input type="radio" 
                                           name="<?= strtolower(htmlspecialchars($option_name)) ?>" 
                                           value="<?= htmlspecialchars($option['value']) ?>" 
                                           id="<?= strtolower(htmlspecialchars($option_name)) ?>_<?= htmlspecialchars($option['value']) ?>" 
                                           required
                                           data-price="<?= $option['price'] ?>">
                                    <label for="<?= strtolower(htmlspecialchars($option_name)) ?>_<?= htmlspecialchars($option['value']) ?>">
                                        <?= htmlspecialchars($option['value']) ?>
                                        <?php if ($option['price'] > 0): ?>
                                            <span class="option-price">+₱<?= number_format($option['price'], 2) ?></span>
                                        <?php endif; ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <button type="submit" class="btn">Add to Cart</button>
        </form>
    </div>
</div>

</body>
</html>