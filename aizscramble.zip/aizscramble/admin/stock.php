<?php
session_start();
include('../includes/db.php');
require_once('../includes/notify_helper.php'); // Added notification helper

if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../user/login.php");
    exit;
}

// Define stock thresholds for notifications
define('STOCK_LOW_THRESHOLD', 5);
define('STOCK_CRITICAL_THRESHOLD', 2);

// Handle Excel Export
if (isset($_GET['export']) && $_GET['export'] == 'excel') {
    $type = isset($_GET['type']) ? $_GET['type'] : 'inventory';
    
    // Set headers for Excel download
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="Inventory_Report_' . date('Y-m-d') . '.xls"');
    header('Cache-Control: max-age=0');
    
    // Output the Excel file header
    echo '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <style>
            table {
                border-collapse: collapse;
                width: 100%;
            }
            th, td {
                border: 1px solid #ddd;
                padding: 8px;
                text-align: left;
            }
            th {
                background-color: #f2f2f2;
                font-weight: bold;
            }
            .stock-warning {
                color: red;
                font-weight: bold;
            }
            .stock-low {
                color: orange;
            }
        </style>
    </head>
    <body>
    ';
    
    // Get product availability based on ingredients
    $product_availability = [];
    $ingredient_result = $conn->query("
        SELECT p.id AS product_id, i.id AS ingredient_id, pi.quantity AS required, i.quantity AS available, i.name AS ingredient_name
        FROM products p
        JOIN product_ingredients pi ON p.id = pi.product_id
        JOIN ingredients i ON pi.ingredient_id = i.id
    ");

    while ($row = $ingredient_result->fetch_assoc()) {
        if (!isset($product_availability[$row['product_id']])) {
            $product_availability[$row['product_id']] = [
                'can_make' => PHP_INT_MAX,
                'limiting_ingredient' => null,
                'limiting_available' => 0
            ];
        }
        
        $can_make = floor($row['available'] / $row['required']);
        if ($can_make < $product_availability[$row['product_id']]['can_make']) {
            $product_availability[$row['product_id']]['can_make'] = $can_make;
            $product_availability[$row['product_id']]['limiting_ingredient'] = $row['ingredient_name'];
            $product_availability[$row['product_id']]['limiting_available'] = $row['available'];
        }
    }
    
    // Inventory/Stock Query - Removed product stock references
    $inventory_query = "
        SELECT 
            p.id AS product_id,
            p.name AS product_name,
            COALESCE(SUM(oi.quantity), 0) AS total_sold
        FROM 
            products p
        LEFT JOIN 
            order_items oi ON p.id = oi.product_id
        LEFT JOIN 
            orders o ON oi.order_id = o.id AND o.status = 'delivered'
        GROUP BY 
            p.id, p.name
        ORDER BY 
            p.name ASC
    ";

    $result = $conn->query($inventory_query);
    
    // Output the report title
    echo '
    <h1>Inventory Report</h1>
    <p>Generated on: ' . date('M d, Y') . '</p>
    
    <table>
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Total Sold</th>
                <th>Can Make (Ingredients)</th>
                <th>Limiting Ingredient</th>
                <th>Available QOH</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
    ';
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $total_sold = $row['total_sold'];
            
            // Get the "Can Make" value based on ingredients
            $can_make = isset($product_availability[$row['product_id']]) ? 
                $product_availability[$row['product_id']]['can_make'] : 'N/A';
            
            $limiting_ingredient = isset($product_availability[$row['product_id']]) ? 
                $product_availability[$row['product_id']]['limiting_ingredient'] : 'N/A';
            
            // Available QOH is based purely on ingredients
            $available_qoh = ($can_make !== 'N/A') ? $can_make : 0;
            
            if ($available_qoh <= 0) {
                $status = 'Out of Stock';
                $class = 'stock-warning';
            } elseif ($available_qoh <= 5) {
                $status = 'Low Stock';
                $class = 'stock-low';
            } else {
                $status = 'In Stock';
                $class = '';
            }
            
            echo '<tr>
                <td>' . htmlspecialchars($row['product_name']) . '</td>
                <td>' . $total_sold . '</td>
                <td>' . ($can_make !== 'N/A' ? $can_make : 'N/A') . '</td>
                <td>' . ($limiting_ingredient !== 'N/A' ? htmlspecialchars($limiting_ingredient) : 'N/A') . '</td>
                <td class="' . $class . '">' . $available_qoh . '</td>
                <td class="' . $class . '">' . $status . '</td>
            </tr>';
        }
    } else {
        echo '<tr><td colspan="6" style="text-align: center;">No inventory data found.</td></tr>';
    }
    
    echo '</tbody></table>';
    
    // Add ingredients report
    $ingredients_query = "SELECT * FROM ingredients ORDER BY name ASC";
    $ingredients_result = $conn->query($ingredients_query);
    
    echo '
    <h1>Ingredients Report</h1>
    <p>Generated on: ' . date('M d, Y') . '</p>
    
    <table>
        <thead>
            <tr>
                <th>Ingredient Name</th>
                <th>Current Stock</th>
                <th>Unit</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
    ';
    
    if ($ingredients_result->num_rows > 0) {
        while ($row = $ingredients_result->fetch_assoc()) {
            if ($row['quantity'] <= 0) {
                $status = 'Out of Stock';
                $class = 'stock-warning';
            } elseif ($row['quantity'] <= 5) {
                $status = 'Low Stock';
                $class = 'stock-low';
            } else {
                $status = 'In Stock';
                $class = '';
            }
            
            echo '<tr>
                <td>' . htmlspecialchars($row['name']) . '</td>
                <td class="' . $class . '">' . $row['quantity'] . '</td>
                <td>' . htmlspecialchars($row['unit']) . '</td>
                <td class="' . $class . '">' . $status . '</td>
            </tr>';
        }
    } else {
        echo '<tr><td colspan="4" style="text-align: center;">No ingredients found.</td></tr>';
    }
    
    echo '</tbody></table>';
    
    // Close the HTML document
    echo '
    </body>
    </html>
    ';
    
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['delete_ingredient'])) {
        $id = intval($_POST['id']);
        
        // Get the ingredient name before deletion
        $stmt = $conn->prepare("SELECT name FROM ingredients WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $ingredient = $result->fetch_assoc();
        
        // Check if the ingredient is used in products
        $check = $conn->prepare("SELECT COUNT(*) FROM product_ingredients WHERE ingredient_id=?");
        $check->bind_param("i", $id);
        $check->execute();
        $check->bind_result($count);
        $check->fetch();
        $check->close();
        
        if ($count > 0) {
            $_SESSION['error'] = "Cannot delete ingredient - it's used in one or more products!";
            addAdminNotification($conn, "Failed attempt to delete ingredient '{$ingredient['name']}' which is used in products.", "Deletion Failed");
        } else {
            $stmt = $conn->prepare("DELETE FROM ingredients WHERE id=?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $_SESSION['message'] = "Ingredient deleted successfully!";
            
            // Create notification for ingredient deletion
            addAdminNotification($conn, "Ingredient '{$ingredient['name']}' was deleted from the system.", "Ingredient Deleted");
        }
        
        header("Location: stock.php");
        exit;
    }
    header("Location: stock.php");
    exit;
}

// Check for low stock and create notifications if needed
// This runs on page load to ensure notifications are created even without updates
function checkAndNotifyLowStock($conn) {
    // Check ingredients with low stock
    $low_stock_ingredients = $conn->query("SELECT id, name, quantity FROM ingredients WHERE quantity <= " . STOCK_LOW_THRESHOLD);
    while ($ingredient = $low_stock_ingredients->fetch_assoc()) {
        // Check if a notification already exists for this ingredient
        $check_sql = "SELECT COUNT(*) as count FROM AdminNotifications 
                     WHERE Title LIKE '%Ingredient Alert%' 
                     AND Message LIKE '%{$ingredient['name']}%' 
                     AND CreatedAt > DATE_SUB(NOW(), INTERVAL 24 HOUR)";
        $check_result = $conn->query($check_sql);
        $notification_exists = $check_result->fetch_assoc()['count'] > 0;
        
        if (!$notification_exists) {
            if ($ingredient['quantity'] <= STOCK_CRITICAL_THRESHOLD) {
                $message = "CRITICAL: Ingredient '{$ingredient['name']}' stock is very low ({$ingredient['quantity']} units remaining)!";
                addAdminNotification($conn, $message, "Critical Ingredient Alert");
            } else {
                $message = "Ingredient '{$ingredient['name']}' stock is running low ({$ingredient['quantity']} units remaining).";
                addAdminNotification($conn, $message, "Low Ingredient Alert");
            }
        }
    }
}

// Run the stock check on page load
checkAndNotifyLowStock($conn);

// Get unread notification count for the bell icon
$unreadCount = $conn->query("SELECT COUNT(*) as total FROM AdminNotifications WHERE IsRead = 0")->fetch_assoc()['total'];

// Fetch notifications for the dropdown
$notifQuery = $conn->query("SELECT * FROM AdminNotifications ORDER BY CreatedAt DESC LIMIT 5");

// Determine which tab should be active
$active_tab = 'products';
if (isset($_GET['tab'])) {
    $active_tab = $_GET['tab'];
}

// Get products and ingredients
$products = $conn->query("SELECT * FROM products ORDER BY name ASC");
$ingredients = $conn->query("SELECT * FROM ingredients ORDER BY name ASC");

// Calculate product availability based on ingredients
$product_availability = [];
$ingredient_result = $conn->query("
    SELECT p.id AS product_id, i.id AS ingredient_id, pi.quantity AS required, i.quantity AS available, i.name AS ingredient_name
    FROM products p
    JOIN product_ingredients pi ON p.id = pi.product_id
    JOIN ingredients i ON pi.ingredient_id = i.id
");

while ($row = $ingredient_result->fetch_assoc()) {
    if (!isset($product_availability[$row['product_id']])) {
        $product_availability[$row['product_id']] = [
            'can_make' => PHP_INT_MAX,
            'limiting_ingredient' => null,
            'limiting_available' => 0
        ];
    }
    
    $can_make = floor($row['available'] / $row['required']);
    if ($can_make < $product_availability[$row['product_id']]['can_make']) {
        $product_availability[$row['product_id']]['can_make'] = $can_make;
        $product_availability[$row['product_id']]['limiting_ingredient'] = $row['ingredient_name'];
        $product_availability[$row['product_id']]['limiting_available'] = $row['available'];
    }
}

// Inventory/Stock Query - Removed product stock references
$inventory_query = "
    SELECT 
        p.id AS product_id,
        p.name AS product_name,
        COALESCE(SUM(oi.quantity), 0) AS total_sold
    FROM 
        products p
    LEFT JOIN 
        order_items oi ON p.id = oi.product_id
    LEFT JOIN 
        orders o ON oi.order_id = o.id AND o.status = 'delivered'
    GROUP BY 
        p.id, p.name
    ORDER BY 
        p.name ASC
";

$inventory_result = $conn->query($inventory_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Management - AIZCAmble</title>
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --error-color: #EF4444;
            --info-color: #3B82F6;
            --shadow-pink: rgba(236, 72, 153, 0.2);
            --shadow-strong: rgba(0, 0, 0, 0.1);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-gradient-start) 0%, var(--background-gradient-end) 100%);
            min-height: 100vh;
            display: flex;
            color: var(--text-primary);
            position: relative;
            overflow-x: hidden;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, var(--primary-pink) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, var(--accent-purple) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, var(--secondary-pink) 0%, transparent 50%);
            opacity: 0.05;
            z-index: -1;
            animation: backgroundFloat 20s ease-in-out infinite;
        }

        @keyframes backgroundFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(-20px, -20px) scale(1.05); }
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary-pink) 0%, var(--primary-pink-dark) 100%);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--border-light);
            box-shadow: 4px 0 20px var(--shadow-pink);
            padding: 0;
            min-height: 100vh;
            position: relative;
            overflow: hidden;
        }

        .sidebar::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.1) 50%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
        }

        @keyframes shimmer {
            0%, 100% { transform: translateX(-100%); }
            50% { transform: translateX(100%); }
        }

        .logo-section {
            text-align: center;
            padding: 32px 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            position: relative;
            z-index: 2;
        }

        .logo-container {
            position: relative;
            display: inline-block;
            margin-bottom: 16px;
        }

        .logo-container::before {
            content: '';
            position: absolute;
            top: -8px;
            left: -8px;
            right: -8px;
            bottom: -8px;
            background: linear-gradient(45deg, rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0.1));
            border-radius: 50%;
            animation: logoGlow 2s ease-in-out infinite;
        }

        @keyframes logoGlow {
            0%, 100% { transform: scale(1); opacity: 0.7; }
            50% { transform: scale(1.05); opacity: 1; }
        }

        .logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(255, 255, 255, 0.9);
            object-fit: cover;
            position: relative;
            z-index: 2;
            transition: all 0.3s ease;
        }

        .logo:hover {
            transform: scale(1.1) rotate(5deg);
        }

        .brand-name {
            color: white;
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 8px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .admin-title {
            color: rgba(255, 255, 255, 0.9);
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-menu {
            padding: 24px 0;
            position: relative;
            z-index: 2;
        }

        .nav-item {
            display: block;
            padding: 16px 24px;
            margin: 8px 16px;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            border-radius: 16px;
            font-weight: 500;
            font-size: 15px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
        }

        .nav-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .nav-item:hover::before {
            left: 100%;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(8px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item.active {
            background: rgba(255, 255, 255, 0.25);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        .main-content {
            flex: 1;
            padding: 32px;
            overflow-y: auto;
            position: relative;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            padding: 24px 32px;
            border-radius: 20px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            position: relative;
            overflow: hidden;
        }

        .header-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .page-title {
            font-size: 32px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* Notification Bell */
        .notification-bell {
            position: relative;
            display: inline-block;
        }

        .notification-bell button {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border: none;
            border-radius: 50%;
            width: 48px;
            height: 48px;
            color: white;
            font-size: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        .notification-bell button:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 20px var(--shadow-pink);
        }

        .notification-badge {
            position: absolute;
            top: -6px;
            right: -6px;
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
            border-radius: 50%;
            padding: 4px 8px;
            font-size: 12px;
            font-weight: 700;
            min-width: 20px;
            text-align: center;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }

        .notification-dropdown {
            display: none;
            position: absolute;
            right: 0;
            top: 60px;
            background: white;
            width: 350px;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            max-height: 400px;
            overflow: hidden;
            border: 1px solid var(--border-light);
        }

        .notification-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 20px;
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            font-weight: 600;
        }

        .notification-header a {
            color: white;
            font-size: 12px;
            text-decoration: none;
            opacity: 0.9;
            transition: opacity 0.2s;
        }

        .notification-header a:hover {
            opacity: 1;
        }

        .notification-dropdown ul {
            list-style: none;
            padding: 0;
            margin: 0;
            max-height: 300px;
            overflow-y: auto;
        }

        .notification-dropdown li {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border-light);
            transition: background-color 0.2s;
        }

        .notification-dropdown li:last-child {
            border-bottom: none;
        }

        .notification-dropdown li:hover {
            background-color: rgba(236, 72, 153, 0.05);
        }

        .notification-footer {
            padding: 16px 20px;
            text-align: center;
            border-top: 1px solid var(--border-light);
            background: rgba(236, 72, 153, 0.05);
        }

        .notification-footer a {
            color: var(--primary-pink);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.2s;
        }

        .notification-footer a:hover {
            color: var(--primary-pink-dark);
        }

        /* Alert Messages */
        .message, .error {
            padding: 16px 20px;
            margin-bottom: 24px;
            border-radius: 12px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .message {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(5, 150, 105, 0.1));
            color: var(--success-color);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .error {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(220, 38, 38, 0.1));
            color: var(--error-color);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        /* Tabs */
        .tabs-container {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            overflow: hidden;
            position: relative;
        }

        .tabs-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        .tabs {
            display: flex;
            background: linear-gradient(135deg, rgba(236, 72, 153, 0.05), rgba(139, 92, 246, 0.05));
            border-bottom: 1px solid var(--border-light);
            padding: 8px;
            gap: 8px;
        }

        .tab {
            flex: 1;
            padding: 16px 24px;
            text-align: center;
            cursor: pointer;
            border-radius: 12px;
            font-weight: 600;
            font-size: 15px;
            color: var(--text-secondary);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .tab::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s ease;
        }

        .tab:hover::before {
            left: 100%;
        }

        .tab:hover {
            color: var(--primary-pink);
            background: rgba(236, 72, 153, 0.1);
            transform: translateY(-2px);
        }

        .tab.active {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        .tab-content {
            display: none;
            padding: 32px;
        }

        .tab-content.active {
            display: block;
        }

        /* Filter Section */
        .filter-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            gap: 16px;
            flex-wrap: wrap;
        }

        .search-container {
            position: relative;
            flex: 1;
            max-width: 400px;
        }

        .search-container input {
            width: 100%;
            padding: 12px 16px 12px 48px;
            border: 2px solid var(--border-light);
            border-radius: 12px;
            font-size: 15px;
            font-weight: 500;
            background: white;
            transition: all 0.3s ease;
            outline: none;
        }

        .search-container input:focus {
            border-color: var(--primary-pink);
            box-shadow: 0 0 0 4px rgba(236, 72, 153, 0.1);
        }

        .search-container i {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
            font-size: 16px;
        }

        .export-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 20px;
            background: linear-gradient(135deg, var(--success-color), #059669);
            color: white;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.2);
        }

        .export-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(16, 185, 129, 0.3);
        }

        /* Tables */
        .table-container {
            background: white;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--border-light);
            max-height: 600px;
            overflow-y: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            padding: 16px 20px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        td {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border-light);
            font-size: 14px;
            font-weight: 500;
        }

        tr:hover {
            background: rgba(236, 72, 153, 0.02);
        }

        tr:last-child td {
            border-bottom: none;
        }

        /* Product Info */
        .product-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .product-info img {
            width: 48px;
            height: 48px;
            object-fit: cover;
            border-radius: 8px;
            border: 2px solid var(--border-light);
        }

        .product-details h4 {
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 4px;
        }

        .product-details small {
            color: var(--text-secondary);
            font-size: 12px;
        }

        /* Stock Status */
        .stock-ok {
            color: var(--success-color);
            font-weight: 600;
        }

        .stock-low {
            color: var(--warning-color);
            font-weight: 600;
        }

        .stock-warning {
            color: var(--error-color);
            font-weight: 600;
        }

        .stock-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stock-badge.in-stock {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success-color);
        }

        .stock-badge.low-stock {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning-color);
        }

        .stock-badge.out-of-stock {
            background: rgba(239, 68, 68, 0.1);
            color: var(--error-color);
        }

        /* Action Buttons */
        .actions {
            display: flex;
            gap: 8px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 12px;
            border: none;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .btn-edit {
            background: linear-gradient(135deg, var(--info-color), #2563EB);
            color: white;
        }

        .btn-delete {
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 2000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(5px);
        }

        .modal-content {
            background: white;
            margin: 10% auto;
            padding: 32px;
            border-radius: 20px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            position: relative;
            animation: modalSlideIn 0.3s ease-out;
        }

        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            padding-bottom: 16px;
            border-bottom: 2px solid var(--border-light);
        }

        .modal-header h3 {
            font-size: 20px;
            font-weight: 700;
            color: var(--text-primary);
        }

        .close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: var(--text-light);
            transition: color 0.2s;
            padding: 4px;
            border-radius: 4px;
        }

        .close:hover {
            color: var(--error-color);
            background: rgba(239, 68, 68, 0.1);
        }

        .modal-body p {
            color: var(--text-secondary);
            margin-bottom: 24px;
            font-size: 16px;
        }

        .modal-actions {
            display: flex;
            gap: 12px;
            justify-content: flex-end;
        }

        .btn-modal {
            padding: 12px 24px;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-modal.btn-danger {
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
        }

        .btn-modal.btn-secondary {
            background: var(--text-light);
            color: white;
        }

        .btn-modal:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .sidebar {
                width: 240px;
            }
        }

        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                min-height: auto;
                position: fixed;
                top: 0;
                left: -100%;
                z-index: 1000;
                transition: left 0.3s ease;
            }
            
            .sidebar.open {
                left: 0;
            }
            
            .main-content {
                padding: 20px;
                margin-top: 0;
            }
            
            .header-section {
                flex-direction: column;
                gap: 16px;
                text-align: center;
            }
            
            .page-title {
                font-size: 24px;
            }
            
            .tabs {
                flex-direction: column;
            }
            
            .filter-section {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-container {
                max-width: none;
            }
            
            .table-container {
                overflow-x: auto;
            }
            
            table {
                min-width: 600px;
            }
            
            .notification-dropdown {
                width: 300px;
                right: -50px;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(236, 72, 153, 0.1);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--primary-pink-dark), var(--primary-pink));
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <div class="logo-container">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo" class="logo">
            </div>
            <div class="brand-name">AIZCAmble</div>
            <div class="admin-title">Admin Panel</div>
        </div>

        <nav class="nav-menu">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                Dashboard
            </a>
            <a href="orders.php" class="nav-item">
                <i class="fas fa-shopping-bag"></i>
                Manage Orders
            </a>
            <a href="add_product.php" class="nav-item">
                <i class="fas fa-plus-circle"></i>
                Add Product
            </a>
            <a href="stock.php" class="nav-item active">
                <i class="fas fa-boxes"></i>
                Stock Management
            </a>
            <a href="sales_analytics.php" class="nav-item">
                <i class="fas fa-chart-bar"></i>
                Sales Analytics
            </a>
            <a href="users.php" class="nav-item">
                <i class="fas fa-users"></i>
                Customers
            </a>
            <a href="ingredients.php" class="nav-item">
                <i class="fas fa-flask"></i>
                Ingredients
            </a>
            <a href="admins.php" class="nav-item">
                <i class="fas fa-user-shield"></i>
                Admins
            </a>
            <a href="shutdown.php" class="nav-item">
                <i class="fas fa-power-off"></i>
                Shutdown Shop
            </a>
            <a href="activity_log.php" class="nav-item">
                <i class="fas fa-history"></i>
                Activity History
            </a>
            <a href="notifications.php" class="nav-item">
                <i class="fas fa-bell"></i>
                Notifications
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header-section">
            <h1 class="page-title">
                <i class="fas fa-boxes"></i>
                Stock Management
            </h1>
            
            <!-- Notification Bell -->
            <div class="notification-bell">
                <button onclick="toggleDropdown()">
                    <i class="fas fa-bell"></i>
                    <?php if ($unreadCount > 0): ?>
                        <span class="notification-badge">
                            <?= $unreadCount ?>
                        </span>
                    <?php endif; ?>
                </button>
                <div id="notifDropdown" class="notification-dropdown">
                    <div class="notification-header">
                        <span>Notifications</span>
                        <?php if ($unreadCount > 0): ?>
                            <a href="stock.php?mark_read=all">Mark all as read</a>
                        <?php endif; ?>
                    </div>
                    <ul>
                        <?php if ($notifQuery->num_rows > 0): ?>
                            <?php while ($notif = $notifQuery->fetch_assoc()): ?>
                                <li style="<?= $notif['IsRead'] ? '' : 'background-color: rgba(236, 72, 153, 0.05);' ?>">
                                    <strong><?= htmlspecialchars($notif['Title']) ?></strong><br>
                                    <small><?= htmlspecialchars($notif['message']) ?></small><br>
                                    <small style="color: #888;"><?= date('M d, Y h:i A', strtotime($notif['CreatedAt'])) ?></small>
                                </li>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <li>No notifications yet</li>
                        <?php endif; ?>
                    </ul>
                    <div class="notification-footer">
                        <a href="notifications.php">View All Notifications</a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Alert Messages -->
        <?php if (isset($_SESSION['message'])): ?>
            <div class="message">
                <i class="fas fa-check-circle"></i>
                <?= $_SESSION['message'] ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error">
                <i class="fas fa-exclamation-circle"></i>
                <?= $_SESSION['error'] ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <!-- Tabs Container -->
        <div class="tabs-container">
            <div class="tabs">
                <div class="tab <?= $active_tab == 'products' ? 'active' : '' ?>" onclick="switchTab('products')">
                    <i class="fas fa-box"></i>
                    Products
                </div>
                <div class="tab <?= $active_tab == 'ingredients' ? 'active' : '' ?>" onclick="switchTab('ingredients')">
                    <i class="fas fa-flask"></i>
                    Ingredients
                </div>
                <div class="tab <?= $active_tab == 'inventory' ? 'active' : '' ?>" onclick="switchTab('inventory')">
                    <i class="fas fa-chart-bar"></i>
                    Inventory Report
                </div>
            </div>
            
            <!-- Products Tab -->
            <div id="products-tab" class="tab-content <?= $active_tab == 'products' ? 'active' : '' ?>">
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th><i class="fas fa-box"></i> Product</th>
                                <th><i class="fas fa-calculator"></i> Can Make</th>
                                <th><i class="fas fa-warehouse"></i> Available QOH</th>
                                <th><i class="fas fa-cogs"></i> Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            // Reset the products result pointer
                            $products->data_seek(0);
                            
                            while ($row = $products->fetch_assoc()): 
                                $availability = $product_availability[$row['id']] ?? ['can_make' => 'N/A', 'limiting_ingredient' => null];
                                
                                // Available QOH is based purely on ingredients
                                $available_qoh = ($availability['can_make'] !== 'N/A') ? $availability['can_make'] : 0;
                                
                                $qoh_class = '';
                                if ($available_qoh <= 0) {
                                    $qoh_class = 'stock-warning';
                                } elseif ($available_qoh <= 5) {
                                    $qoh_class = 'stock-low';
                                } else {
                                    $qoh_class = 'stock-ok';
                                }
                            ?>
                            <tr>
                                <td>
                                    <div class="product-info">
                                        <?php if (!empty($row['image'])): ?>
                                            <img src="<?= htmlspecialchars($row['image']) ?>" alt="Product Image">
                                        <?php else: ?>
                                            <div style="width: 48px; height: 48px; background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark)); border-radius: 8px; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                                                <?= strtoupper(substr($row['name'], 0, 2)) ?>
                                            </div>
                                        <?php endif; ?>
                                        <div class="product-details">
                                            <h4><?= htmlspecialchars($row['name']) ?></h4>
                                            <?php if ($row['is_customizable']): ?>
                                                <small><i class="fas fa-magic"></i> Customizable</small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($availability['can_make'] !== 'N/A'): ?>
                                        <div>
                                            <span class="<?= $availability['can_make'] == 0 ? 'stock-warning' : ($availability['can_make'] < 5 ? 'stock-low' : 'stock-ok') ?>">
                                                <strong><?= $availability['can_make'] ?></strong>
                                            </span>
                                            <?php if ($availability['limiting_ingredient']): ?>
                                                <br><small style="color: var(--text-secondary);">
                                                    <i class="fas fa-exclamation-triangle"></i>
                                                    Limited by <?= htmlspecialchars($availability['limiting_ingredient']) ?>
                                                </small>
                                            <?php endif; ?>
                                        </div>
                                    <?php else: ?>
                                        <span style="color: var(--text-light);">
                                            <i class="fas fa-question-circle"></i>
                                            N/A (No ingredients)
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="<?= $qoh_class ?>">
                                        <strong><?= $available_qoh ?></strong>
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <a href="edit_product.php?id=<?= $row['id'] ?>" class="btn btn-edit">
                                            <i class="fas fa-edit"></i>
                                            Edit
                                        </a>
                                        <a href="delete_product.php?id=<?= $row['id'] ?>" class="btn btn-delete" onclick="return confirm('Delete this product?')">
                                            <i class="fas fa-trash"></i>
                                            Delete
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Ingredients Tab -->
            <div id="ingredients-tab" class="tab-content <?= $active_tab == 'ingredients' ? 'active' : '' ?>">
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th><i class="fas fa-flask"></i> Ingredient</th>
                                <th><i class="fas fa-warehouse"></i> Current Stock</th>
                                <th><i class="fas fa-balance-scale"></i> Unit</th>
                                <th><i class="fas fa-traffic-light"></i> Status</th>
                                <th><i class="fas fa-cogs"></i> Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            // Reset the ingredients result pointer
                            $ingredients->data_seek(0);
                            
                            while ($ingredient = $ingredients->fetch_assoc()): 
                                $stock_class = '';
                                $status = '';
                                $badge_class = '';
                                
                                if ($ingredient['quantity'] == 0) {
                                    $stock_class = 'stock-warning';
                                    $status = 'Out of Stock';
                                    $badge_class = 'out-of-stock';
                                } elseif ($ingredient['quantity'] < 5) {
                                    $stock_class = 'stock-low';
                                    $status = 'Low Stock';
                                    $badge_class = 'low-stock';
                                } else {
                                    $stock_class = 'stock-ok';
                                    $status = 'In Stock';
                                    $badge_class = 'in-stock';
                                }
                            ?>
                            <tr>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 12px;">
                                        <div style="width: 40px; height: 40px; background: linear-gradient(135deg, var(--accent-purple), var(--accent-purple-light)); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 14px;">
                                            <i class="fas fa-flask"></i>
                                        </div>
                                        <strong><?= htmlspecialchars($ingredient['name']) ?></strong>
                                    </div>
                                </td>
                                <td>
                                    <span class="<?= $stock_class ?>">
                                        <strong><?= $ingredient['quantity'] ?></strong>
                                    </span>
                                </td>
                                <td>
                                    <span style="color: var(--text-secondary); font-weight: 500;">
                                        <?= htmlspecialchars($ingredient['unit']) ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="stock-badge <?= $badge_class ?>">
                                        <?php if ($badge_class == 'in-stock'): ?>
                                            <i class="fas fa-check-circle"></i>
                                        <?php elseif ($badge_class == 'low-stock'): ?>
                                            <i class="fas fa-exclamation-triangle"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times-circle"></i>
                                        <?php endif; ?>
                                        <?= $status ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <a href="ingredients.php?id=<?= $ingredient['id'] ?>" class="btn btn-edit">
                                            <i class="fas fa-edit"></i>
                                            Edit
                                        </a>
                                        <button class="btn btn-delete" onclick="confirmDeleteIngredient(<?= $ingredient['id'] ?>)">
                                            <i class="fas fa-trash"></i>
                                            Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Inventory Report Tab -->
            <div id="inventory-tab" class="tab-content <?= $active_tab == 'inventory' ? 'active' : '' ?>">
                <div class="filter-section">
                    <div class="search-container">
                        <i class="fas fa-search"></i>
                        <input type="text" id="inventorySearch" placeholder="Search products..." onkeyup="searchInventory()">
                    </div>
                    <a href="stock.php?export=excel&type=inventory" class="export-btn">
                        <i class="fas fa-file-excel"></i>
                        Export to Excel
                    </a>
                </div>
                
                <div class="table-container">
                    <table id="inventory-table">
                        <thead>
                            <tr>
                                <th><i class="fas fa-box"></i> Product Name</th>
                                <th><i class="fas fa-chart-line"></i> Total Sold</th>
                                <th><i class="fas fa-calculator"></i> Can Make</th>
                                <th><i class="fas fa-exclamation-triangle"></i> Limiting Ingredient</th>
                                <th><i class="fas fa-warehouse"></i> Available QOH</th>
                                <th><i class="fas fa-traffic-light"></i> Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($inventory_result->num_rows > 0): ?>
                                <?php while ($row = $inventory_result->fetch_assoc()): 
                                    $total_sold = $row['total_sold'];
                                    
                                    // Get the "Can Make" value based on ingredients
                                    $can_make = isset($product_availability[$row['product_id']]) ? 
                                        $product_availability[$row['product_id']]['can_make'] : 'N/A';
                                    
                                    $limiting_ingredient = isset($product_availability[$row['product_id']]) ? 
                                        $product_availability[$row['product_id']]['limiting_ingredient'] : 'N/A';
                                    
                                    // Available QOH is based purely on ingredients
                                    $available_qoh = ($can_make !== 'N/A') ? $can_make : 0;
                                    
                                    if ($available_qoh <= 0) {
                                        $status = 'Out of Stock';
                                        $class = 'stock-warning';
                                        $badge_class = 'out-of-stock';
                                    } elseif ($available_qoh <= 5) {
                                        $status = 'Low Stock';
                                        $class = 'stock-low';
                                        $badge_class = 'low-stock';
                                    } else {
                                        $status = 'In Stock';
                                        $class = 'stock-ok';
                                        $badge_class = 'in-stock';
                                    }
                                ?>
                                    <tr>
                                        <td>
                                            <strong><?= htmlspecialchars($row['product_name']) ?></strong>
                                        </td>
                                        <td>
                                            <span style="color: var(--text-secondary); font-weight: 600;">
                                                <?= $total_sold ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="<?= $class ?>">
                                                <strong><?= ($can_make !== 'N/A' ? $can_make : 'N/A') ?></strong>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($limiting_ingredient !== 'N/A'): ?>
                                                <span style="color: var(--text-secondary);">
                                                    <i class="fas fa-flask"></i>
                                                    <?= htmlspecialchars($limiting_ingredient) ?>
                                                </span>
                                            <?php else: ?>
                                                <span style="color: var(--text-light);">N/A</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="<?= $class ?>">
                                                <strong><?= $available_qoh ?></strong>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="stock-badge <?= $badge_class ?>">
                                                <?php if ($badge_class == 'in-stock'): ?>
                                                    <i class="fas fa-check-circle"></i>
                                                <?php elseif ($badge_class == 'low-stock'): ?>
                                                    <i class="fas fa-exclamation-triangle"></i>
                                                <?php else: ?>
                                                    <i class="fas fa-times-circle"></i>
                                                <?php endif; ?>
                                                <?= $status ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" style="text-align: center; padding: 40px; color: var(--text-light);">
                                        <i class="fas fa-box-open" style="font-size: 48px; margin-bottom: 16px; display: block;"></i>
                                        No inventory data found.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Ingredient Modal -->
    <div id="deleteIngredientModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>
                    <i class="fas fa-exclamation-triangle" style="color: var(--error-color);"></i>
                    Confirm Deletion
                </h3>
                <button class="close" onclick="closeDeleteIngredientModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this ingredient? This action cannot be undone.</p>
            </div>
            <form id="deleteIngredientForm" method="POST">
                <input type="hidden" name="id" id="deleteIngredientId">
                <div class="modal-actions">
                    <button type="button" class="btn-modal btn-secondary" onclick="closeDeleteIngredientModal()">
                        <i class="fas fa-times"></i>
                        Cancel
                    </button>
                    <button type="submit" name="delete_ingredient" class="btn-modal btn-danger">
                        <i class="fas fa-trash"></i>
                        Delete Ingredient
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Tab switching functionality
        function switchTab(tabName) {
            // Remove active class from all tabs and content
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Add active class to selected tab and content
            document.getElementById(`${tabName}-tab`).classList.add('active');
            document.querySelector(`.tab[onclick="switchTab('${tabName}')"]`).classList.add('active');
            
            // Update URL with the active tab (for browser history)
            const url = new URL(window.location.href);
            url.searchParams.set('tab', tabName);
            window.history.replaceState({}, '', url);
        }

        // Delete ingredient modal functions
        function confirmDeleteIngredient(id) {
            document.getElementById('deleteIngredientId').value = id;
            document.getElementById('deleteIngredientModal').style.display = 'block';
        }

        function closeDeleteIngredientModal() {
            document.getElementById('deleteIngredientModal').style.display = 'none';
        }

        // Search functionality for inventory table
        function searchInventory() {
            const input = document.getElementById('inventorySearch');
            const filter = input.value.toUpperCase();
            const table = document.getElementById('inventory-table');
            const tr = table.getElementsByTagName('tr');
            
            for (let i = 1; i < tr.length; i++) { // Start from 1 to skip header row
                const td = tr[i].getElementsByTagName('td')[0]; // Product name column
                if (td) {
                    const txtValue = td.textContent || td.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = '';
                    } else {
                        tr[i].style.display = 'none';
                    }
                }
            }
        }

        // Notification dropdown toggle
        function toggleDropdown() {
            const dropdown = document.getElementById('notifDropdown');
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        }

        // Close dropdown and modal when clicking outside
        window.onclick = function(event) {
            const dropdown = document.getElementById('notifDropdown');
            const bell = document.querySelector('.notification-bell button');
            const modal = document.getElementById('deleteIngredientModal');
            
            // Close modal if clicking outside
            if (event.target == modal) {
                closeDeleteIngredientModal();
            }
            
            // Close notification dropdown if clicking outside
            if (dropdown && bell && !bell.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = 'none';
            }
        }

        // Mobile sidebar toggle
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('open');
        }

        // Add mobile menu button if needed
        if (window.innerWidth <= 768) {
            const header = document.querySelector('.header-section');
            const menuBtn = document.createElement('button');
            menuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            menuBtn.className = 'btn btn-edit';
            menuBtn.onclick = toggleSidebar;
            menuBtn.style.position = 'absolute';
            menuBtn.style.top = '20px';
            menuBtn.style.left = '20px';
            menuBtn.style.zIndex = '1001';
            document.body.appendChild(menuBtn);
        }

        // Auto-refresh notifications every 30 seconds
        setInterval(function() {
            // Only refresh if page is visible
            if (!document.hidden) {
                fetch('stock.php?ajax=notifications')
                    .then(response => response.json())
                    .then(data => {
                        if (data.unreadCount !== undefined) {
                            const badge = document.querySelector('.notification-badge');
                            const bellButton = document.querySelector('.notification-bell button');
                            
                            if (data.unreadCount > 0) {
                                if (!badge) {
                                    const newBadge = document.createElement('span');
                                    newBadge.className = 'notification-badge';
                                    newBadge.textContent = data.unreadCount;
                                    bellButton.appendChild(newBadge);
                                } else {
                                    badge.textContent = data.unreadCount;
                                }
                            } else if (badge) {
                                badge.remove();
                            }
                        }
                    })
                    .catch(error => console.log('Notification refresh failed:', error));
            }
        }, 30000);

        // Add smooth scrolling to tables
        document.querySelectorAll('.table-container').forEach(container => {
            container.addEventListener('scroll', function() {
                const scrollTop = this.scrollTop;
                const thead = this.querySelector('thead');
                if (thead) {
                    thead.style.transform = `translateY(${scrollTop}px)`;
                }
            });
        });

        // Add loading animation for export button
        document.querySelector('.export-btn')?.addEventListener('click', function(e) {
            const btn = e.target.closest('.export-btn');
            const originalContent = btn.innerHTML;
            
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
            btn.style.pointerEvents = 'none';
            
            // Reset after 3 seconds
            setTimeout(() => {
                btn.innerHTML = originalContent;
                btn.style.pointerEvents = 'auto';
            }, 3000);
        });

        // Initialize tooltips for stock status badges
        document.querySelectorAll('.stock-badge').forEach(badge => {
            badge.addEventListener('mouseenter', function() {
                const status = this.textContent.trim();
                let tooltip = document.createElement('div');
                tooltip.className = 'tooltip';
                tooltip.style.cssText = `
                    position: absolute;
                    background: rgba(0, 0, 0, 0.8);
                    color: white;
                    padding: 8px 12px;
                    border-radius: 6px;
                    font-size: 12px;
                    z-index: 1000;
                    pointer-events: none;
                    white-space: nowrap;
                `;
                
                if (status.includes('Out of Stock')) {
                    tooltip.textContent = 'No ingredients available to make this product';
                } else if (status.includes('Low Stock')) {
                    tooltip.textContent = 'Limited ingredients available - restock soon';
                } else {
                    tooltip.textContent = 'Sufficient ingredients available';
                }
                
                document.body.appendChild(tooltip);
                
                const rect = this.getBoundingClientRect();
                tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
                tooltip.style.top = rect.top - tooltip.offsetHeight - 8 + 'px';
                
                this.tooltip = tooltip;
            });
            
            badge.addEventListener('mouseleave', function() {
                if (this.tooltip) {
                    this.tooltip.remove();
                    this.tooltip = null;
                }
            });
        });
    </script>
</body>
</html>