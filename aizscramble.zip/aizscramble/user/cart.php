<?php
session_start();
require '../includes/db.php';

$cart = $_SESSION['cart'] ?? [];

// Enrich cart data with product information including images
$enrichedCart = [];
if (!empty($cart)) {
    foreach ($cart as $item) {
        // Get fresh product data from database
        $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->bind_param("i", $item['id']);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($product) {
            // Merge cart item data with fresh product data
            $enrichedItem = array_merge($item, [
                'name' => $product['name'],
                'price' => $product['price'],
                'image' => $product['image'], // This is the key addition!
                'stock' => $product['stock'],
                'description' => $product['description']
            ]);
            $enrichedCart[] = $enrichedItem;
        }
    }
}

// Update the cart variable to use enriched data
$cart = $enrichedCart;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['clear']) && $_POST['clear'] == 'true') {
        unset($_SESSION['cart']);
        echo 'success';
        exit;
    }
    
    if (isset($_POST['update_quantity'])) {
        $productId = $_POST['product_id'];
        $customizationKey = $_POST['customization_key'] ?? '';
        $action = $_POST['action'];

        // Check ingredient availability
        $ingredientAvailability = checkIngredientAvailability($productId, $conn);
        
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['id'] == $productId && 
                (empty($customizationKey) || 
                (isset($item['customization_key']) && $item['customization_key'] == $customizationKey))) {
                
                if ($action == 'add') {
                    // Check if we have enough ingredients for one more
                    $canAddMore = true;
                    $limitingIngredient = '';
                    
                    foreach ($ingredientAvailability as $ingredient) {
                        $needed = $ingredient['quantity'] * ($item['quantity'] + 1);
                        if ($needed > $ingredient['available']) {
                            $canAddMore = false;
                            $limitingIngredient = $ingredient['name'];
                            break;
                        }
                    }
                    
                    if (!$canAddMore) {
                        echo json_encode([
                            'success' => false, 
                            'error' => 'Cannot add more - limited by ' . $limitingIngredient,
                            'max_reached' => true
                        ]);
                        exit;
                    }
                    
                    $item['quantity']++;
                } elseif ($action == 'subtract' && $item['quantity'] > 1) {
                    $item['quantity']--;
                } elseif ($action == 'manual') {
                    // Handle manual quantity update
                    $new_qty = intval($_POST['new_qty']);
                    
                    // Validate minimum quantity
                    if ($new_qty < 1) {
                        echo json_encode([
                            'success' => false,
                            'error' => 'Quantity must be at least 1',
                            'current_qty' => $item['quantity']
                        ]);
                        exit;
                    }
                    
                    // If increasing quantity, check ingredient availability
                    if ($new_qty > $item['quantity']) {
                        $canSetQty = true;
                        $limitingIngredient = '';
                        
                        foreach ($ingredientAvailability as $ingredient) {
                            $needed = $ingredient['quantity'] * $new_qty;
                            if ($needed > $ingredient['available']) {
                                $canSetQty = false;
                                $limitingIngredient = $ingredient['name'];
                                $maxPossible = floor($ingredient['available'] / $ingredient['quantity']);
                                break;
                            }
                        }
                        
                        if (!$canSetQty) {
                            echo json_encode([
                                'success' => false,
                                'error' => 'Cannot set quantity to ' . $new_qty . ' - limited by ' . $limitingIngredient,
                                'max_reached' => true,
                                'current_qty' => $item['quantity'],
                                'max_possible' => $maxPossible ?? $item['quantity']
                            ]);
                            exit;
                        }
                    }
                    
                    // Update quantity
                    $item['quantity'] = $new_qty;
                }
                
                echo json_encode([
                    'success' => true, 
                    'new_quantity' => $item['quantity'],
                    'ingredients' => $ingredientAvailability
                ]);
                exit;
            }
        }
        
        echo json_encode(['success' => false, 'error' => 'Item not found']);
        exit;
    }
    
    if (isset($_POST['remove_item'])) {
        $productId = $_POST['product_id'];
        $customizationKey = $_POST['customization_key'] ?? '';
        
        foreach ($_SESSION['cart'] as $key => $item) {
            if ($item['id'] == $productId) {
                if (empty($customizationKey) || 
                    (!empty($item['customization_key']) && $item['customization_key'] == $customizationKey)) {
                    unset($_SESSION['cart'][$key]);
                    $_SESSION['cart'] = array_values($_SESSION['cart']);
                    echo json_encode(['success' => true]);
                    exit;
                }
            }
        }
        
        echo json_encode(['success' => false, 'error' => 'Item not found in cart']);
        exit;
    }
}

// Check checkout availability based on ingredient inventory
$canCheckout = true;
$outOfStockItems = [];
if (!empty($cart)) {
    foreach ($cart as $item) {
        $productId = $item['id'];
        $ingredientAvailability = checkIngredientAvailability($productId, $conn);
        
        foreach ($ingredientAvailability as $ingredient) {
            $needed = $ingredient['quantity'] * $item['quantity'];
            if ($needed > $ingredient['available']) {
                $canCheckout = false;
                $outOfStockItems[] = [
                    'product' => $item['name'],
                    'ingredient' => $ingredient['name'],
                    'available' => $ingredient['available'],
                    'needed' => $needed
                ];
                break;
            }
        }
    }
}

// Function to check ingredient availability
function checkIngredientAvailability($productId, $conn) {
    $ingredients = [];
    
    $stmt = $conn->prepare("
        SELECT i.id, i.name, i.quantity as available, pi.quantity 
        FROM product_ingredients pi
        JOIN ingredients i ON pi.ingredient_id = i.id
        WHERE pi.product_id = ?
    ");
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        // Calculate dynamic QOH for this ingredient
        $qoh_stmt = $conn->prepare("
            SELECT 
                GREATEST(0, COALESCE(SUM(restock_quantity), 0) - COALESCE(SUM(sales_quantity), 0)) as current_qoh
            FROM ingredient_movements 
            WHERE ingredient_id = ?
        ");
        $qoh_stmt->bind_param("i", $row['id']);
        $qoh_stmt->execute();
        $qoh_result = $qoh_stmt->get_result();
        $qoh_row = $qoh_result->fetch_assoc();
        $current_qoh = $qoh_row['current_qoh'] ?? 0;
        $qoh_stmt->close();
        
        $ingredients[] = [
            'id' => $row['id'],
            'name' => $row['name'],
            'available' => $current_qoh,
            'quantity' => $row['quantity']
        ];
    }
    
    $stmt->close();
    
    // If no ingredients defined, check product stock directly
    if (empty($ingredients)) {
        $available = 0; // Initialize the variable
        $stmt = $conn->prepare("SELECT stock as available FROM products WHERE id = ?");
        $stmt->bind_param("i", $productId);
        $stmt->execute();
        $stmt->bind_result($available);
        $stmt->fetch();
        $stmt->close();
        
        $ingredients[] = [
            'id' => 0,
            'name' => 'Product stock',
            'available' => $available,
            'quantity' => 1
        ];
    }
    
    return $ingredients;
}

$isLoggedIn = isset($_SESSION['user_id']);

// Calculate cart statistics
$totalItems = 0;
$grandTotal = 0;
foreach ($cart as $item) {
    $totalItems += $item['quantity'];
    $grandTotal += $item['price'] * $item['quantity'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <title>Shopping Cart - AIZCAmble | Your Delicious Treats</title>
    
    <!-- Meta Tags -->
    <meta name="description" content="Review and manage your AIZCAmble cart. Fresh ice scramble and mini donuts ready for checkout.">
    <meta name="keywords" content="AIZCAmble cart, shopping cart, ice scramble order, mini donuts checkout">
    <meta name="author" content="AIZCAmble Team">
    
    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --accent-gold: #F59E0B;
            --accent-gold-light: #FCD34D;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --background-deep-start: #831843;
            --background-deep-end: #BE185D;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --error-color: #EF4444;
            --shadow-pink: rgba(236, 72, 153, 0.3);
            --shadow-strong: rgba(0, 0, 0, 0.25);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-deep-start) 0%, var(--background-deep-end) 50%, var(--primary-pink-dark) 100%);
            color: var(--text-primary);
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: fixed;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, var(--primary-pink) 1px, transparent 1px);
            background-size: 50px 50px;
            animation: backgroundMove 20s linear infinite;
            opacity: 0.1;
            z-index: -2;
        }

        body::after {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(circle at 20% 80%, var(--primary-pink) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, var(--accent-purple) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, var(--secondary-pink) 0%, transparent 50%);
            opacity: 0.15;
            animation: gradientShift 15s ease-in-out infinite;
            z-index: -1;
        }

        @keyframes backgroundMove {
            0% { transform: translate(0, 0) rotate(0deg); }
            100% { transform: translate(50px, 50px) rotate(360deg); }
        }

        @keyframes gradientShift {
            0%, 100% { opacity: 0.15; }
            50% { opacity: 0.25; }
        }

        /* Navigation */
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: var(--surface-white);
            backdrop-filter: blur(25px);
            border-bottom: 1px solid var(--border-light);
            box-shadow: 0 8px 32px var(--shadow-pink);
            z-index: 1000;
            padding: 0;
            transition: all 0.3s ease;
        }

        .navbar.scrolled {
            background: rgba(255, 255, 255, 0.98);
            box-shadow: 0 12px 48px var(--shadow-pink);
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 32px;
        }

        .nav-brand {
            display: flex;
            align-items: center;
            gap: 16px;
            text-decoration: none;
            color: var(--text-primary);
        }

        .nav-logo {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            border: 3px solid var(--primary-pink);
            object-fit: cover;
            transition: all 0.3s ease;
            position: relative;
        }

        .nav-logo::before {
            content: '';
            position: absolute;
            top: -6px;
            left: -6px;
            right: -6px;
            bottom: -6px;
            background: linear-gradient(45deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            border-radius: 50%;
            z-index: -1;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .nav-brand:hover .nav-logo::before {
            opacity: 1;
        }

        .nav-brand:hover .nav-logo {
            transform: scale(1.1) rotate(5deg);
        }

        .brand-text {
            display: flex;
            flex-direction: column;
        }

        .brand-name {
            font-size: 28px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            line-height: 1;
        }

        .brand-tagline {
            font-size: 12px;
            color: var(--text-light);
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 24px;
        }

        .nav-link {
            text-decoration: none;
            color: var(--text-secondary);
            font-weight: 600;
            font-size: 16px;
            padding: 12px 20px;
            border-radius: 12px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-link::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(236, 72, 153, 0.1), transparent);
            transition: left 0.5s ease;
        }

        .nav-link:hover::before {
            left: 100%;
        }

        .nav-link:hover {
            color: var(--primary-pink);
            background: rgba(236, 72, 153, 0.1);
            transform: translateY(-2px);
        }

        .nav-link.active {
            color: var(--primary-pink);
            background: rgba(236, 72, 153, 0.1);
        }

        /* Mobile Menu Toggle */
        .mobile-toggle {
            display: none;
            background: none;
            border: none;
            font-size: 24px;
            color: var(--primary-pink);
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .mobile-toggle:hover {
            background: rgba(236, 72, 153, 0.1);
        }

        /* Main Container */
        .main-container {
            padding: 120px 32px 80px;
            max-width: 1400px;
            margin: 0 auto;
        }

        /* Page Header */
        .page-header {
            text-align: center;
            margin-bottom: 48px;
        }

        .page-title {
            font-size: 48px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 16px;
            line-height: 1.1;
        }

        .page-subtitle {
            font-size: 20px;
            color: rgba(255, 255, 255, 0.9);
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        /* Cart Stats */
        .cart-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 24px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 24px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
            text-align: center;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 16px 48px var(--shadow-pink);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 16px;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            margin: 0 auto 16px;
        }

        .stat-value {
            font-size: 32px;
            font-weight: 800;
            color: var(--text-primary);
            margin-bottom: 8px;
        }

        .stat-label {
            font-size: 14px;
            color: var(--text-secondary);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Alerts */
        .alert {
            padding: 20px 24px;
            border-radius: 16px;
            margin-bottom: 32px;
            font-weight: 500;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            animation: slideIn 0.5s ease;
        }

        .alert-success {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(5, 150, 105, 0.1));
            color: var(--success-color);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .alert-warning {
            background: linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(217, 119, 6, 0.1));
            color: var(--warning-color);
            border: 1px solid rgba(245, 158, 11, 0.2);
        }

        @keyframes slideIn {
            0% { transform: translateY(-20px); opacity: 0; }
            100% { transform: translateY(0); opacity: 1; }
        }

        .alert ul {
            margin-top: 12px;
            margin-left: 20px;
        }

        .alert li {
            margin-bottom: 8px;
        }

        /* Cart Container */
        .cart-container {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            box-shadow: 0 16px 48px var(--shadow-pink);
            border: 1px solid var(--border-light);
            overflow: hidden;
            position: relative;
        }

        .cart-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        /* Cart Items */
        .cart-items {
            padding: 32px;
        }

        .cart-item {
            display: grid;
            grid-template-columns: 80px 1fr auto auto auto auto;
            gap: 24px;
            align-items: center;
            padding: 24px;
            border-radius: 16px;
            margin-bottom: 16px;
            background: white;
            border: 1px solid var(--border-light);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .cart-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(236, 72, 153, 0.05), transparent);
            transition: left 0.5s ease;
        }

        .cart-item:hover::before {
            left: 100%;
        }

        .cart-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px var(--shadow-pink);
        }

        .cart-item:last-child {
            margin-bottom: 0;
        }

        .item-image {
            width: 80px;
            height: 80px;
            border-radius: 12px;
            overflow: hidden;
            border: 2px solid var(--border-light);
        }

        .item-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: all 0.3s ease;
        }

        .cart-item:hover .item-image img {
            transform: scale(1.1);
        }

        .item-details {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .item-name {
            font-size: 18px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 4px;
        }

        .item-customizations {
            font-size: 14px;
            color: var(--text-secondary);
            background: rgba(236, 72, 153, 0.05);
            padding: 8px 12px;
            border-radius: 8px;
            border: 1px solid var(--border-light);
        }

        .customization-item {
            margin-bottom: 4px;
        }

        .customization-item:last-child {
            margin-bottom: 0;
        }

        .stock-warning {
            color: var(--error-color);
            font-size: 12px;
            font-weight: 600;
            margin-top: 8px;
            padding: 6px 10px;
            background: rgba(239, 68, 68, 0.1);
            border-radius: 6px;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .item-price {
            font-size: 20px;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        /* Quantity Controls */
        .quantity-control {
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(236, 72, 153, 0.05);
            padding: 8px;
            border-radius: 12px;
            border: 1px solid var(--border-light);
        }

        .quantity-btn {
            width: 36px;
            height: 36px;
            border-radius: 8px;
            border: none;
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            font-weight: 700;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .quantity-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .quantity-btn:hover::before {
            left: 100%;
        }

        .quantity-btn:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        .quantity-btn:disabled {
            background: linear-gradient(135deg, #9CA3AF, #6B7280);
            cursor: not-allowed;
            transform: none !important;
            box-shadow: none !important;
        }

        .quantity-input {
            width: 60px;
            text-align: center;
            font-size: 16px;
            font-weight: 600;
            border: 2px solid var(--border-light);
            border-radius: 8px;
            padding: 8px 4px;
            background: white;
            color: var(--text-primary);
            transition: all 0.3s ease;
        }

        .quantity-input:focus {
            outline: none;
            border-color: var(--primary-pink);
            box-shadow: 0 0 0 3px rgba(236, 72, 153, 0.1);
        }

        .item-total {
            font-size: 22px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .remove-btn {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            border: none;
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .remove-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .remove-btn:hover::before {
            left: 100%;
        }

        .remove-btn:hover {
            transform: translateY(-2px) scale(1.05);
            box-shadow: 0 4px 15px rgba(239, 68, 68, 0.3);
        }

        /* Cart Summary */
        .cart-summary {
            background: linear-gradient(135deg, rgba(236, 72, 153, 0.05), rgba(139, 92, 246, 0.05));
            padding: 32px;
            border-top: 1px solid var(--border-light);
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            font-size: 18px;
        }

        .summary-row:last-child {
            margin-bottom: 0;
            padding-top: 16px;
            border-top: 2px solid var(--border-light);
        }

        .summary-label {
            font-weight: 600;
            color: var(--text-secondary);
        }

        .summary-value {
            font-weight: 700;
            color: var(--text-primary);
        }

        .grand-total {
            font-size: 28px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        /* Cart Actions */
        .cart-actions {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 32px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 16px 32px;
            border-radius: 16px;
            text-decoration: none;
            font-weight: 700;
            font-size: 16px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border: none;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            box-shadow: 0 4px 15px var(--shadow-pink);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px var(--shadow-pink);
        }

        .btn-secondary {
            background: linear-gradient(135deg, var(--text-light), var(--text-secondary));
            color: white;
            box-shadow: 0 4px 15px rgba(107, 114, 128, 0.3);
        }

        .btn-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(107, 114, 128, 0.4);
        }

        .btn:disabled {
            background: linear-gradient(135deg, #9CA3AF, #6B7280);
            color: white;
            cursor: not-allowed;
            transform: none !important;
            box-shadow: none !important;
        }

        .btn:disabled::before {
            display: none;
        }

        /* Empty Cart */
        .empty-cart {
            text-align: center;
            padding: 80px 32px;
            color: var(--text-secondary);
        }

        .empty-cart-icon {
            font-size: 80px;
            color: var(--text-light);
            margin-bottom: 24px;
            opacity: 0.5;
        }

        .empty-cart h3 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 16px;
            color: var(--text-primary);
        }

        .empty-cart p {
            font-size: 18px;
            line-height: 1.6;
            margin-bottom: 32px;
        }

        .empty-cart .btn {
            margin: 0 auto;
        }

        /* Floating particles */
        .floating-element {
            position: absolute;
            border-radius: 50%;
            background: linear-gradient(45deg, var(--primary-pink), var(--secondary-pink));
            animation: float 20s infinite linear;
            pointer-events: none;
            opacity: 0.6;
        }

        .floating-element.pink {
            background: linear-gradient(45deg, var(--secondary-pink), var(--primary-pink-light));
            animation: floatPink 25s infinite linear;
            opacity: 0.4;
        }

        @keyframes float {
            0% {
                transform: translateY(100vh) rotate(0deg) scale(0);
                opacity: 0;
            }
            10% {
                opacity: 0.6;
                transform: translateY(90vh) rotate(36deg) scale(1);
            }
            90% {
                opacity: 0.6;
                transform: translateY(-10vh) rotate(324deg) scale(1);
            }
            100% {
                transform: translateY(-100vh) rotate(360deg) scale(0);
                opacity: 0;
            }
        }

        @keyframes floatPink {
            0% {
                transform: translateY(100vh) rotate(0deg) scale(0);
                opacity: 0;
            }
            15% {
                opacity: 0.4;
                transform: translateY(85vh) rotate(54deg) scale(1);
            }
            85% {
                opacity: 0.4;
                transform: translateY(-15vh) rotate(306deg) scale(1);
            }
            100% {
                transform: translateY(-100vh) rotate(360deg) scale(0);
                opacity: 0;
            }
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .cart-item {
                grid-template-columns: 70px 1fr auto auto auto auto;
                gap: 16px;
            }
            
            .item-image {
                width: 70px;
                height: 70px;
            }
        }

        @media (max-width: 768px) {
            .mobile-toggle {
                display: block;
            }
            
            .nav-links {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: var(--surface-white);
                backdrop-filter: blur(25px);
                flex-direction: column;
                padding: 20px;
                box-shadow: 0 8px 32px var(--shadow-pink);
                border-top: 1px solid var(--border-light);
                gap: 8px;
            }
            
            .nav-links.open {
                display: flex;
            }
            
            .main-container {
                padding: 100px 20px 60px;
            }
            
            .page-title {
                font-size: 36px;
            }
            
            .cart-item {
                grid-template-columns: 1fr;
                gap: 16px;
                text-align: center;
            }
            
            .cart-actions {
                flex-direction: column;
                align-items: center;
            }
            
            .btn {
                width: 100%;
                max-width: 300px;
            }
        }

        @media (max-width: 480px) {
            .nav-container {
                padding: 12px 20px;
            }
            
            .page-title {
                font-size: 28px;
            }
            
            .cart-stats {
                grid-template-columns: 1fr;
                gap: 16px;
            }
            
            .cart-items {
                padding: 20px;
            }
            
            .cart-summary {
                padding: 20px;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(236, 72, 153, 0.1);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--primary-pink-dark), var(--primary-pink));
        }

        /* Loading Animation */
        .loading {
            opacity: 0;
            animation: fadeIn 0.6s ease forwards;
        }

        @keyframes fadeIn {
            to { opacity: 1; }
        }
    </style>
</head>
<body>
    <!-- Floating Elements -->
    <div class="floating-element" style="left: 5%; width: 6px; height: 6px; animation-delay: 0s;"></div>
    <div class="floating-element pink" style="left: 15%; width: 4px; height: 4px; animation-delay: 3s;"></div>
    <div class="floating-element" style="left: 25%; width: 8px; height: 8px; animation-delay: 6s;"></div>
    <div class="floating-element pink" style="left: 35%; width: 5px; height: 5px; animation-delay: 9s;"></div>
    <div class="floating-element" style="left: 45%; width: 7px; height: 7px; animation-delay: 12s;"></div>
    <div class="floating-element pink" style="left: 55%; width: 4px; height: 4px; animation-delay: 15s;"></div>
    <div class="floating-element" style="left: 65%; width: 6px; height: 6px; animation-delay: 18s;"></div>
    <div class="floating-element pink" style="left: 75%; width: 5px; height: 5px; animation-delay: 21s;"></div>
    <div class="floating-element" style="left: 85%; width: 7px; height: 7px; animation-delay: 24s;"></div>
    <div class="floating-element pink" style="left: 95%; width: 4px; height: 4px; animation-delay: 27s;"></div>

    <!-- Navigation -->
    <nav class="navbar" id="navbar">
        <div class="nav-container">
            <a href="../index.php" class="nav-brand">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo" class="nav-logo">
                <div class="brand-text">
                    <div class="brand-name">AIZCAmble</div>
                    <div class="brand-tagline">Your Cart</div>
                </div>
            </a>
            
            <div class="nav-links" id="navLinks">
                <a href="../index.php" class="nav-link">
                    <i class="fas fa-home"></i>
                    Home
                </a>
                <a href="../Home.php" class="nav-link">
                    <i class="fas fa-store"></i>
                    Shop
                </a>
                <a href="cart.php" class="nav-link active">
                    <i class="fas fa-shopping-cart"></i>
                    Cart
                </a>
                <a href="orders.php" class="nav-link">
                    <i class="fas fa-receipt"></i>
                    My Orders
                </a>
                <a href="../logout.php" class="nav-link">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
            
            <button class="mobile-toggle" id="mobileToggle">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </nav>

    <!-- Main Container -->
    <div class="main-container">
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-title">Shopping Cart</h1>
            <p class="page-subtitle">Review your delicious treats before checkout</p>
        </div>

        <?php if (isset($_GET['added'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <div>
                    <strong>Success!</strong> Item added to cart successfully!
                </div>
            </div>
        <?php endif; ?>

        <?php if (!empty($cart)): ?>
            <!-- Cart Statistics -->
            <div class="cart-stats">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-shopping-bag"></i>
                    </div>
                    <div class="stat-value"><?= count($cart) ?></div>
                    <div class="stat-label">Unique Items</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-layer-group"></i>
                    </div>
                    <div class="stat-value"><?= $totalItems ?></div>
                    <div class="stat-label">Total Quantity</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-peso-sign"></i>
                    </div>
                    <div class="stat-value">₱<?= number_format($grandTotal, 2) ?></div>
                    <div class="stat-label">Total Amount</div>
                </div>
            </div>

            <?php if (!empty($outOfStockItems)): ?>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <div>
                        <strong>Inventory Issues:</strong> Some items cannot be checked out due to insufficient ingredients:
                        <ul>
                            <?php foreach ($outOfStockItems as $item): ?>
                                <li>
                                    <strong><?= htmlspecialchars($item['product']) ?></strong> - 
                                    Needs <?= $item['needed'] ?> <?= htmlspecialchars($item['ingredient']) ?> 
                                    (only <?= $item['available'] ?> available)
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Cart Container -->
            <div class="cart-container">
                <div class="cart-items">
                    <?php foreach ($cart as $item): 
                        $productId = $item['id'];
                        $ingredientAvailability = checkIngredientAvailability($productId, $conn);
                        
                        $item_total = $item['price'] * $item['quantity'];
                        
                        // Check if this item has ingredient issues
                        $hasIngredientIssue = false;
                        $ingredientMessage = '';
                        foreach ($ingredientAvailability as $ingredient) {
                            $needed = $ingredient['quantity'] * $item['quantity'];
                            if ($needed > $ingredient['available']) {
                                $hasIngredientIssue = true;
                                $ingredientMessage = "⚠️ Needs {$needed} {$ingredient['name']} (only {$ingredient['available']} available)";
                                break;
                            }
                        }
                    ?>
                        <div class="cart-item loading" data-item-id="<?= $item['id'] ?>" data-customization-key="<?= htmlspecialchars($item['customization_key'] ?? '') ?>">
                            <div class="item-image">
                                <?php if (!empty($item['image'])): ?>
                                    <img src="<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                                <?php else: ?>
                                    <img src="/placeholder.svg?height=80&width=80&query=<?= urlencode($item['name']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                                <?php endif; ?>
                            </div>
                            
                            <div class="item-details">
                                <h3 class="item-name"><?= htmlspecialchars($item['name']) ?></h3>
                                
                                <?php if (!empty($item['customizations'])): ?>
                                    <div class="item-customizations">
                                        <?php 
                                        $customizations = is_array($item['customizations']) ? 
                                            $item['customizations'] : 
                                            json_decode($item['customizations'], true);
                                        
                                        foreach ($customizations as $option => $value): ?>
                                            <div class="customization-item">
                                                <strong><?= htmlspecialchars($option) ?>:</strong> 
                                                <?php if (is_array($value)): ?>
                                                    <?= htmlspecialchars(implode(', ', $value)) ?>
                                                <?php else: ?>
                                                    <?= htmlspecialchars($value) ?>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="item-customizations">Standard</div>
                                <?php endif; ?>
                                
                                <?php if ($hasIngredientIssue): ?>
                                    <div class="stock-warning"><?= $ingredientMessage ?></div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="item-price">₱<?= number_format($item['price'], 2) ?></div>
                            
                            <div class="quantity-control">
                                <button class="quantity-btn" data-action="subtract" 
                                    data-id="<?= $item['id'] ?>" 
                                    data-customization="<?= htmlspecialchars($item['customization_key'] ?? '') ?>"
                                    <?= $item['quantity'] == 1 ? 'disabled' : '' ?>>
                                    <i class="fas fa-minus"></i>
                                </button>
                                <input type="number" min="1" class="quantity-input" 
                                    value="<?= $item['quantity'] ?>"
                                    data-id="<?= $item['id'] ?>"
                                    data-customization="<?= htmlspecialchars($item['customization_key'] ?? '') ?>"
                                    data-original="<?= $item['quantity'] ?>">
                                <button class="quantity-btn" data-action="add" 
                                    data-id="<?= $item['id'] ?>"
                                    data-customization="<?= htmlspecialchars($item['customization_key'] ?? '') ?>"
                                    <?= $hasIngredientIssue ? 'disabled' : '' ?>>
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                            
                            <div class="item-total">₱<?= number_format($item_total, 2) ?></div>
                            
                            <button class="remove-btn" 
                                data-id="<?= $item['id'] ?>"
                                data-customization="<?= htmlspecialchars($item['customization_key'] ?? '') ?>"
                                title="Remove item">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="cart-summary">
                    <div class="summary-row">
                        <span class="summary-label">Subtotal:</span>
                        <span class="summary-value">₱<?= number_format($grandTotal, 2) ?></span>
                    </div>
                    <div class="summary-row">
                        <span class="summary-label">Items:</span>
                        <span class="summary-value"><?= $totalItems ?> item<?= $totalItems != 1 ? 's' : '' ?></span>
                    </div>
                    <div class="summary-row">
                        <span class="summary-label">Grand Total:</span>
                        <span class="summary-value grand-total">₱<?= number_format($grandTotal, 2) ?></span>
                    </div>
                    
                    <div class="cart-actions">
                        <button id="clearCartBtn" class="btn btn-secondary">
                            <i class="fas fa-trash-alt"></i>
                            Clear Cart
                        </button>
                        <?php if ($canCheckout): ?>
                            <a href="checkout.php" class="btn btn-primary">
                                <i class="fas fa-credit-card"></i>
                                Proceed to Checkout
                            </a>
                        <?php else: ?>
                            <button class="btn btn-primary" disabled>
                                <i class="fas fa-ban"></i>
                                Fix Quantity Issues First
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <!-- Empty Cart -->
            <div class="cart-container">
                <div class="empty-cart">
                    <div class="empty-cart-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <h3>Your cart is empty</h3>
                    <p>Looks like you haven't added any delicious treats to your cart yet.<br>
                    Browse our fresh ice scramble and mini donuts to get started!</p>
                    <a href="../Home.php" class="btn btn-primary">
                        <i class="fas fa-store"></i>
                        Continue Shopping
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Mobile menu toggle
        const mobileToggle = document.getElementById('mobileToggle');
        const navLinks = document.getElementById('navLinks');

        mobileToggle.addEventListener('click', function() {
            navLinks.classList.toggle('open');
            const icon = this.querySelector('i');
            if (navLinks.classList.contains('open')) {
                icon.className = 'fas fa-times';
            } else {
                icon.className = 'fas fa-bars';
            }
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!navLinks.contains(event.target) && !mobileToggle.contains(event.target)) {
                navLinks.classList.remove('open');
                mobileToggle.querySelector('i').className = 'fas fa-bars';
            }
        });

        // Parallax effect for floating elements
        document.addEventListener('mousemove', function(e) {
            const mouseX = e.clientX / window.innerWidth;
            const mouseY = e.clientY / window.innerHeight;
            
            // Move floating elements based on mouse position
            document.querySelectorAll('.floating-element').forEach((element, index) => {
                const speed = (index % 3 + 1) * 0.5;
                const x = (mouseX - 0.5) * speed * 20;
                const y = (mouseY - 0.5) * speed * 20;
                element.style.transform = `translate(${x}px, ${y}px)`;
            });
        });

        // Loading animations
        window.addEventListener('load', function() {
            document.querySelectorAll('.cart-item.loading').forEach((item, index) => {
                setTimeout(() => {
                    item.classList.remove('loading');
                    item.style.opacity = '1';
                    item.style.transform = 'translateY(0)';
                }, index * 100);
            });
        });

        // Enhanced brand interaction
        document.querySelector('.nav-brand').addEventListener('mouseenter', function() {
            this.querySelector('.brand-name').style.transform = 'scale(1.05)';
            this.querySelector('.brand-tagline').style.color = 'var(--primary-pink)';
        });

        document.querySelector('.nav-brand').addEventListener('mouseleave', function() {
            this.querySelector('.brand-name').style.transform = 'scale(1)';
            this.querySelector('.brand-tagline').style.color = 'var(--text-light)';
        });

        document.addEventListener('DOMContentLoaded', function() {
            // Quantity control handlers
            document.querySelectorAll('.quantity-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const action = this.dataset.action;
                    const productId = this.dataset.id;
                    const customizationKey = this.dataset.customization || '';
                    
                    // Add loading state
                    this.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
                    this.disabled = true;
                    
                    fetch('cart.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `update_quantity=true&product_id=${productId}&action=${action}&customization_key=${encodeURIComponent(customizationKey)}`
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            const row = document.querySelector(`[data-item-id="${productId}"][data-customization-key="${customizationKey}"]`);
                            const quantityInput = row.querySelector('.quantity-input');
                            const newQty = data.new_quantity;
                            quantityInput.value = newQty;
                            quantityInput.dataset.original = newQty;
                            
                            // Update item total
                            const priceText = row.querySelector('.item-price').textContent;
                            const price = parseFloat(priceText.replace('₱', '').replace(',', ''));
                            const itemTotal = row.querySelector('.item-total');
                            itemTotal.textContent = '₱' + (price * newQty).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                            
                            // Update grand total and stats
                            updateCartStats();
                            
                            // Update button states
                            const subtractBtn = row.querySelector('[data-action="subtract"]');
                            subtractBtn.disabled = newQty === 1;
                            subtractBtn.innerHTML = '<i class="fas fa-minus"></i>';
                            
                            // Check ingredient availability for add button
                            const addBtn = row.querySelector('[data-action="add"]');
                            addBtn.innerHTML = '<i class="fas fa-plus"></i>';
                            addBtn.disabled = false;
                            
                            if (data.ingredients) {
                                let canAddMore = true;
                                data.ingredients.forEach(ingredient => {
                                    const needed = ingredient.quantity * (newQty + 1);
                                    if (needed > ingredient.available) {
                                        canAddMore = false;
                                        // Update warning message
                                        let warning = row.querySelector('.stock-warning');
                                        if (!warning) {
                                            warning = document.createElement('div');
                                            warning.className = 'stock-warning';
                                            row.querySelector('.item-details').appendChild(warning);
                                        }
                                        warning.textContent = `⚠️ Needs ${needed} ${ingredient.name} (only ${ingredient.available} available)`;
                                    }
                                });
                                addBtn.disabled = !canAddMore;
                            }
                            
                            // Check overall checkout status
                            checkCheckoutStatus();
                        } else {
                            alert(data.error || 'Failed to update quantity');
                            if (data.max_reached) {
                                const addBtn = document.querySelector(`[data-item-id="${productId}"] [data-action="add"]`);
                                if (addBtn) addBtn.disabled = true;
                            }
                        }
                        
                        // Reset button
                        this.innerHTML = action === 'add' ? '<i class="fas fa-plus"></i>' : '<i class="fas fa-minus"></i>';
                        this.disabled = false;
                    })
                    .catch(error => {
                        alert('Error updating quantity');
                        console.error(error);
                        // Reset button
                        this.innerHTML = action === 'add' ? '<i class="fas fa-plus"></i>' : '<i class="fas fa-minus"></i>';
                        this.disabled = false;
                    });
                });
            });
            
            // Manual quantity input handlers
            document.querySelectorAll('.quantity-input').forEach(input => {
                // Save original value on focus
                input.addEventListener('focus', function() {
                    this.dataset.original = this.value;
                });
                
                // Handle blur event (when input loses focus)
                input.addEventListener('blur', function() {
                    const newQty = parseInt(this.value);
                    const originalQty = parseInt(this.dataset.original);
                    
                    // If quantity didn't change or is invalid, reset to original
                    if (isNaN(newQty) || newQty === originalQty || newQty < 1) {
                        this.value = originalQty;
                        return;
                    }
                    
                    const productId = this.dataset.id;
                    const customizationKey = this.dataset.customization || '';
                    
                    // Send AJAX request to update quantity
                    fetch('cart.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `update_quantity=true&product_id=${productId}&action=manual&new_qty=${newQty}&customization_key=${encodeURIComponent(customizationKey)}`
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            const row = document.querySelector(`[data-item-id="${productId}"][data-customization-key="${customizationKey}"]`);
                            const newQty = data.new_quantity;
                            this.value = newQty;
                            this.dataset.original = newQty;
                            
                            // Update item total
                            const priceText = row.querySelector('.item-price').textContent;
                            const price = parseFloat(priceText.replace('₱', '').replace(',', ''));
                            const itemTotal = row.querySelector('.item-total');
                            itemTotal.textContent = '₱' + (price * newQty).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                            
                            // Update grand total and stats
                            updateCartStats();
                            
                            // Update button states
                            const subtractBtn = row.querySelector('[data-action="subtract"]');
                            subtractBtn.disabled = newQty === 1;
                            
                            // Check ingredient availability for add button
                            const addBtn = row.querySelector('[data-action="add"]');
                            if (data.ingredients) {
                                let canAddMore = true;
                                let warningMessage = '';
                                
                                data.ingredients.forEach(ingredient => {
                                    const needed = ingredient.quantity * (newQty + 1);
                                    if (needed > ingredient.available) {
                                        canAddMore = false;
                                        warningMessage = `⚠️ Needs ${needed} ${ingredient.name} (only ${ingredient.available} available)`;
                                    }
                                });
                                
                                addBtn.disabled = !canAddMore;
                                
                                // Update or remove warning message
                                let warning = row.querySelector('.stock-warning');
                                if (warningMessage) {
                                    if (!warning) {
                                        warning = document.createElement('div');
                                        warning.className = 'stock-warning';
                                        row.querySelector('.item-details').appendChild(warning);
                                    }
                                    warning.textContent = warningMessage;
                                } else if (warning) {
                                    warning.remove();
                                }
                            }
                            
                            // Check overall checkout status
                            checkCheckoutStatus();
                        } else {
                            // Reset to original value on error
                            this.value = this.dataset.original;
                            alert(data.error || 'Failed to update quantity');
                            
                            if (data.max_reached && data.max_possible) {
                                alert(`Maximum possible quantity is ${data.max_possible}`);
                            }
                        }
                    })
                    .catch(error => {
                        this.value = this.dataset.original;
                        alert('Error updating quantity');
                        console.error(error);
                    });
                });
                
                // Handle Enter key press
                input.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        this.blur(); // Trigger the blur event to process the change
                    }
                });
            });
            
            // Remove item handler
            document.querySelectorAll('.remove-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    if (!confirm('Remove this item from your cart?')) return;
                    
                    const productId = this.dataset.id;
                    const customizationKey = this.dataset.customization || '';
                    
                    // Add loading state
                    this.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
                    this.disabled = true;
                    
                    fetch('cart.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `remove_item=true&product_id=${productId}&customization_key=${encodeURIComponent(customizationKey)}`
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            const row = document.querySelector(`[data-item-id="${productId}"][data-customization-key="${customizationKey}"]`);
                            
                            // Animate removal
                            row.style.transform = 'translateX(-100%)';
                            row.style.opacity = '0';
                            
                            setTimeout(() => {
                                row.remove();
                                updateCartStats();
                                checkCheckoutStatus();
                                
                                // If cart is now empty, refresh to show empty message
                                if (document.querySelectorAll('.cart-item').length === 0) {
                                    window.location.reload();
                                }
                            }, 300);
                        } else {
                            alert(data.error || 'Failed to remove item');
                            // Reset button
                            this.innerHTML = '<i class="fas fa-trash"></i>';
                            this.disabled = false;
                        }
                    })
                    .catch(error => {
                        alert('Error removing item');
                        console.error(error);
                        // Reset button
                        this.innerHTML = '<i class="fas fa-trash"></i>';
                        this.disabled = false;
                    });
                });
            });
            
            // Clear cart handler
            document.getElementById('clearCartBtn')?.addEventListener('click', function() {
                if (!confirm('Clear your entire cart? This action cannot be undone.')) return;
                
                // Add loading state
                this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Clearing...';
                this.disabled = true;
                
                fetch('cart.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'clear=true'
                })
                .then(response => response.text())
                .then(data => {
                    if (data === 'success') {
                        // Animate all items out
                        document.querySelectorAll('.cart-item').forEach((item, index) => {
                            setTimeout(() => {
                                item.style.transform = 'translateX(-100%)';
                                item.style.opacity = '0';
                            }, index * 100);
                        });
                        
                        setTimeout(() => {
                            window.location.reload();
                        }, 500);
                    } else {
                        // Reset button
                        this.innerHTML = '<i class="fas fa-trash-alt"></i> Clear Cart';
                        this.disabled = false;
                        alert('Failed to clear cart');
                    }
                })
                .catch(error => {
                    alert('Error clearing cart');
                    console.error(error);
                    // Reset button
                    this.innerHTML = '<i class="fas fa-trash-alt"></i> Clear Cart';
                    this.disabled = false;
                });
            });
            
            // Update cart statistics
            function updateCartStats() {
                let totalItems = 0;
                let grandTotal = 0;
                
                document.querySelectorAll('.cart-item').forEach(item => {
                    const quantity = parseInt(item.querySelector('.quantity-input').value);
                    const priceText = item.querySelector('.item-price').textContent;
                    const price = parseFloat(priceText.replace('₱', '').replace(',', ''));
                    
                    totalItems += quantity;
                    grandTotal += price * quantity;
                });
                
                // Update stat cards
                const statCards = document.querySelectorAll('.stat-card');
                if (statCards.length >= 3) {
                    statCards[0].querySelector('.stat-value').textContent = document.querySelectorAll('.cart-item').length;
                    statCards[1].querySelector('.stat-value').textContent = totalItems;
                    statCards[2].querySelector('.stat-value').textContent = '₱' + grandTotal.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                }
                
                // Update summary
                const summaryRows = document.querySelectorAll('.summary-row');
                if (summaryRows.length >= 3) {
                    summaryRows[0].querySelector('.summary-value').textContent = '₱' + grandTotal.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    summaryRows[1].querySelector('.summary-value').textContent = totalItems + ' item' + (totalItems !== 1 ? 's' : '');
                    summaryRows[2].querySelector('.summary-value').textContent = '₱' + grandTotal.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                }
            }
            
            // Check checkout status (enable/disable button)
            function checkCheckoutStatus() {
                let canCheckout = true;
                document.querySelectorAll('.stock-warning').forEach(warning => {
                    if (warning.textContent.includes('Needs')) {
                        canCheckout = false;
                    }
                });
                
                const checkoutBtn = document.querySelector('.cart-actions a.btn-primary');
                const disabledBtn = document.querySelector('.cart-actions button[disabled]');
                
                if (checkoutBtn && !canCheckout) {
                    const newDisabledBtn = document.createElement('button');
                    newDisabledBtn.className = 'btn btn-primary';
                    newDisabledBtn.disabled = true;
                    newDisabledBtn.innerHTML = '<i class="fas fa-ban"></i> Fix Quantity Issues First';
                    checkoutBtn.replaceWith(newDisabledBtn);
                } else if (disabledBtn && canCheckout) {
                    const newEnabledBtn = document.createElement('a');
                    newEnabledBtn.className = 'btn btn-primary';
                    newEnabledBtn.href = 'checkout.php';
                    newEnabledBtn.innerHTML = '<i class="fas fa-credit-card"></i> Proceed to Checkout';
                    disabledBtn.replaceWith(newEnabledBtn);
                }
            }
        });

        // Enhanced button interactions
        document.querySelectorAll('.btn:not(:disabled)').forEach(btn => {
            btn.addEventListener('click', function(e) {
                // Add ripple effect
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.cssText = `
                    width: ${size}px;
                    height: ${size}px;
                    left: ${x}px;
                    top: ${y}px;
                    position: absolute;
                    border-radius: 50%;
                    background: rgba(255, 255, 255, 0.4);
                    transform: scale(0);
                    animation: rippleEffect 0.6s ease-out;
                    pointer-events: none;
                `;
                
                this.style.position = 'relative';
                this.style.overflow = 'hidden';
                this.appendChild(ripple);
                
                setTimeout(() => ripple.remove(), 600);
            });
        });

        // Add ripple animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes rippleEffect {
                0% {
                    transform: scale(0);
                    opacity: 1;
                }
                100% {
                    transform: scale(4);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Dynamic background color shifts
        setInterval(() => {
            const hue = Math.random() * 30 + 320; // Pink to purple range
            document.documentElement.style.setProperty('--dynamic-bg', `hsl(${hue}, 70%, 15%)`);
        }, 5000);

        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            // 'c' to clear cart
            if (e.key === 'c' && e.ctrlKey) {
                const clearBtn = document.getElementById('clearCartBtn');
                if (clearBtn) {
                    e.preventDefault();
                    clearBtn.click();
                }
            }
            
            // 'Enter' to checkout
            if (e.key === 'Enter' && e.ctrlKey) {
                const checkoutBtn = document.querySelector('.cart-actions a.btn-primary');
                if (checkoutBtn) {
                    e.preventDefault();
                    window.location.href = checkoutBtn.href;
                }
            }
        });
    </script>
</body>
</html>
