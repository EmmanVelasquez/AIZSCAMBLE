<?php
session_start();
require('../includes/db.php');
require_once('../includes/notify_helper.php'); // Added notification helper

if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../user/login.php");
    exit;
}

// Mark notifications as read if requested
if (isset($_GET['mark_read']) && $_GET['mark_read'] == 'all') {
    $conn->query("UPDATE AdminNotifications SET IsRead = 1 WHERE IsRead = 0");
    header("Location: orders.php");
    exit;
}

// Fetch notifications for the dropdown
$notifQuery = $conn->query("SELECT * FROM AdminNotifications ORDER BY CreatedAt DESC LIMIT 5");
$unreadCount = $conn->query("SELECT COUNT(*) as total FROM AdminNotifications WHERE IsRead = 0")->fetch_assoc()['total'];

// Handle AJAX requests for filtering
if (isset($_GET['ajax']) && $_GET['ajax'] == 'true') {
    // Build the SQL query with filters
    $sql = "SELECT o.*, u.name as customer_name, 
            TIMESTAMPDIFF(SECOND, o.status_updated_at, NOW()) as status_duration 
            FROM orders o
            JOIN users u ON o.user_id = u.id
            WHERE 1=1";
    
    $params = [];
    $types = "";
    
    // Apply status filter if provided
    if (isset($_GET['status']) && !empty($_GET['status'])) {
        $sql .= " AND o.status = ?";
        $params[] = $_GET['status'];
        $types .= "s";
    }
    
    // Apply date filters if provided
    if (isset($_GET['date_filter']) && !empty($_GET['date_filter'])) {
        switch ($_GET['date_filter']) {
            case 'today':
                $sql .= " AND DATE(o.created_at) = CURDATE()";
                break;
            case 'week':
                $sql .= " AND YEARWEEK(o.created_at) = YEARWEEK(NOW())";
                break;
            case 'month':
                $sql .= " AND MONTH(o.created_at) = MONTH(NOW()) AND YEAR(o.created_at) = YEAR(NOW())";
                break;
            case 'year':
                $sql .= " AND YEAR(o.created_at) = YEAR(NOW())";
                break;
        }
    }
    
    // Apply search term if provided
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $search = '%' . $_GET['search'] . '%';
        $sql .= " AND (o.id LIKE ? OR u.name LIKE ? OR o.payment_method LIKE ? OR o.area LIKE ? OR o.landmark LIKE ?)";
        $params[] = $search;
        $params[] = $search;
        $params[] = $search;
        $params[] = $search;
        $params[] = $search;
        $types .= "sssss";
    }
    
    // Order by created_at DESC
    $sql .= " ORDER BY o.created_at DESC";
    
    // Prepare and execute the query
    $stmt = $conn->prepare($sql);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    
    $orders = [];
    while ($order = $result->fetch_assoc()) {
        $orders[] = $order;
    }
    
    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'orders' => $orders]);
    exit;
}

// Regular page load - fetch all orders by default
$sql = "SELECT o.*, u.name as customer_name, 
        TIMESTAMPDIFF(SECOND, o.status_updated_at, NOW()) as status_duration 
        FROM orders o
        JOIN users u ON o.user_id = u.id
        ORDER BY o.created_at DESC";
$result = $conn->query($sql);
$orders = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders - AIZCAmble</title>
    <link rel="icon" href="/assets/FavLogo.jpg" alt="brand-logo">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.all.min.js"></script>
    <style>
        :root {
            --primary-pink: #EC4899;
            --primary-pink-dark: #DB2777;
            --primary-pink-light: #F472B6;
            --secondary-pink: #F9A8D4;
            --accent-purple: #8B5CF6;
            --accent-purple-light: #A78BFA;
            --background-gradient-start: #FDF2F8;
            --background-gradient-end: #FCE7F3;
            --surface-white: rgba(255, 255, 255, 0.95);
            --surface-glass: rgba(255, 255, 255, 0.1);
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #9CA3AF;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --error-color: #EF4444;
            --info-color: #3B82F6;
            --shadow-pink: rgba(236, 72, 153, 0.2);
            --shadow-strong: rgba(0, 0, 0, 0.1);
            --border-light: rgba(236, 72, 153, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-gradient-start) 0%, var(--background-gradient-end) 100%);
            min-height: 100vh;
            display: flex;
            color: var(--text-primary);
            position: relative;
            overflow-x: hidden;
        }

        /* Animated background elements */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, var(--primary-pink) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, var(--accent-purple) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, var(--secondary-pink) 0%, transparent 50%);
            opacity: 0.05;
            z-index: -1;
            animation: backgroundFloat 20s ease-in-out infinite;
        }

        @keyframes backgroundFloat {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(-20px, -20px) scale(1.05); }
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary-pink) 0%, var(--primary-pink-dark) 100%);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--border-light);
            box-shadow: 4px 0 20px var(--shadow-pink);
            padding: 0;
            min-height: 100vh;
            position: relative;
            overflow: hidden;
        }

        .sidebar::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.1) 50%, transparent 70%);
            animation: shimmer 3s ease-in-out infinite;
        }

        @keyframes shimmer {
            0%, 100% { transform: translateX(-100%); }
            50% { transform: translateX(100%); }
        }

        .logo-section {
            text-align: center;
            padding: 32px 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            position: relative;
            z-index: 2;
        }

        .logo-container {
            position: relative;
            display: inline-block;
            margin-bottom: 16px;
        }

        .logo-container::before {
            content: '';
            position: absolute;
            top: -8px;
            left: -8px;
            right: -8px;
            bottom: -8px;
            background: linear-gradient(45deg, rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0.1));
            border-radius: 50%;
            animation: logoGlow 2s ease-in-out infinite;
        }

        @keyframes logoGlow {
            0%, 100% { transform: scale(1); opacity: 0.7; }
            50% { transform: scale(1.05); opacity: 1; }
        }

        .logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(255, 255, 255, 0.9);
            object-fit: cover;
            position: relative;
            z-index: 2;
            transition: all 0.3s ease;
        }

        .logo:hover {
            transform: scale(1.1) rotate(5deg);
        }

        .brand-name {
            color: white;
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 8px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .admin-title {
            color: rgba(255, 255, 255, 0.9);
            font-size: 14px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-menu {
            padding: 24px 0;
            position: relative;
            z-index: 2;
        }

        .nav-item {
            display: block;
            padding: 16px 24px;
            margin: 8px 16px;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            border-radius: 16px;
            font-weight: 500;
            font-size: 15px;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
        }

        .nav-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .nav-item:hover::before {
            left: 100%;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(8px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item.active {
            background: rgba(255, 255, 255, 0.25);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .nav-item i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        .main-content {
            flex: 1;
            padding: 32px;
            overflow-y: auto;
            position: relative;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            padding: 24px 32px;
            border-radius: 24px;
            box-shadow: 0 8px 32px var(--shadow-pink);
            border: 1px solid var(--border-light);
        }

        .page-title {
            font-size: 32px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-pink), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin: 0;
        }

        .page-subtitle {
            color: var(--text-secondary);
            font-size: 16px;
            font-weight: 500;
            margin-top: 4px;
        }

        /* Notification Bell */
        .notification-bell {
            position: relative;
            display: inline-block;
        }

        .notification-btn {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border: none;
            border-radius: 16px;
            padding: 16px;
            color: white;
            font-size: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 8px 25px var(--shadow-pink);
            position: relative;
            overflow: hidden;
        }

        .notification-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s ease;
        }

        .notification-btn:hover::before {
            left: 100%;
        }

        .notification-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 35px var(--shadow-pink);
        }

        .notification-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: linear-gradient(135deg, var(--error-color), #DC2626);
            color: white;
            border-radius: 50%;
            padding: 6px 8px;
            font-size: 12px;
            font-weight: 700;
            min-width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }

        .notification-dropdown {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            margin-top: 8px;
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            width: 380px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
            border: 1px solid var(--border-light);
            z-index: 1000;
            overflow: hidden;
            animation: dropdownSlide 0.3s ease-out;
        }

        @keyframes dropdownSlide {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .notification-header {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            padding: 20px 24px;
            font-weight: 600;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .notification-list {
            max-height: 400px;
            overflow-y: auto;
            padding: 0;
            margin: 0;
            list-style: none;
        }

        .notification-item {
            padding: 20px 24px;
            border-bottom: 1px solid var(--border-light);
            transition: background 0.2s ease;
        }

        .notification-item:hover {
            background: rgba(236, 72, 153, 0.05);
        }

        .notification-item:last-child {
            border-bottom: none;
        }

        .notification-item.unread {
            background: linear-gradient(90deg, rgba(236, 72, 153, 0.1), transparent);
            border-left: 4px solid var(--primary-pink);
        }

        .notification-footer {
            padding: 16px 24px;
            text-align: center;
            border-top: 1px solid var(--border-light);
            background: rgba(236, 72, 153, 0.02);
        }

        .notification-footer a {
            color: var(--primary-pink);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.2s ease;
        }

        .notification-footer a:hover {
            color: var(--primary-pink-dark);
        }

        /* Orders Container */
        .orders-container {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 32px;
            border: 1px solid var(--border-light);
            box-shadow: 0 8px 32px var(--shadow-pink);
            position: relative;
            overflow: hidden;
        }

        .orders-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-pink), var(--accent-purple), var(--secondary-pink));
            background-size: 200% 100%;
            animation: gradientFlow 3s ease-in-out infinite;
        }

        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        /* Filter Section */
        .filter-container {
            background: linear-gradient(135deg, rgba(236, 72, 153, 0.05), rgba(139, 92, 246, 0.05));
            border-radius: 20px;
            padding: 24px;
            margin-bottom: 32px;
            border: 1px solid var(--border-light);
        }

        .search-filters {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            align-items: center;
        }

        .search-box {
            flex: 2;
            min-width: 300px;
        }

        .filter-options {
            display: flex;
            gap: 16px;
            flex: 1;
            min-width: 300px;
        }

        .search-input, .filter-select {
            width: 100%;
            padding: 16px 20px;
            border: 2px solid var(--border-light);
            border-radius: 16px;
            font-size: 15px;
            font-weight: 500;
            background: rgba(255, 255, 255, 0.9);
            transition: all 0.3s ease;
            outline: none;
            font-family: 'Poppins', sans-serif;
        }

        .search-input:focus, .filter-select:focus {
            border-color: var(--primary-pink);
            background: white;
            box-shadow: 0 0 0 4px rgba(236, 72, 153, 0.1);
            transform: translateY(-2px);
        }

        .search-input::placeholder {
            color: var(--text-light);
        }

        /* Table Styles */
        .table-container {
            overflow-x: auto;
            border-radius: 20px;
            border: 1px solid var(--border-light);
            background: white;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }

        th {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            padding: 20px 24px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        th:first-child {
            border-top-left-radius: 20px;
        }

        th:last-child {
            border-top-right-radius: 20px;
        }

        td {
            padding: 20px 24px;
            border-bottom: 1px solid var(--border-light);
            font-weight: 500;
            vertical-align: middle;
        }

        tr:hover {
            background: linear-gradient(90deg, rgba(236, 72, 153, 0.05), transparent);
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:last-child td:first-child {
            border-bottom-left-radius: 20px;
        }

        tr:last-child td:last-child {
            border-bottom-right-radius: 20px;
        }

        /* Status Badges */
        .status-badge {
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .status-pending {
            background: linear-gradient(135deg, #FEF3C7, #FDE68A);
            color: #92400E;
            box-shadow: 0 2px 8px rgba(251, 191, 36, 0.3);
        }

        .status-approved {
            background: linear-gradient(135deg, #F3E8FF, #E9D5FF);
            color: #7C3AED;
            box-shadow: 0 2px 8px rgba(139, 92, 246, 0.3);
        }

        .status-preparing {
            background: linear-gradient(135deg, #FEF3C7, #FDE68A);
            color: #D97706;
            box-shadow: 0 2px 8px rgba(245, 158, 11, 0.3);
        }

        .status-out_for_delivery {
            background: linear-gradient(135deg, #CFFAFE, #A5F3FC);
            color: #0891B2;
            box-shadow: 0 2px 8px rgba(6, 182, 212, 0.3);
        }

        .status-delivered {
            background: linear-gradient(135deg, #D1FAE5, #A7F3D0);
            color: #065F46;
            box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3);
        }

        .status-rejected {
            background: linear-gradient(135deg, #FEE2E2, #FECACA);
            color: #991B1B;
            box-shadow: 0 2px 8px rgba(239, 68, 68, 0.3);
        }

        .status-canceled {
            background: linear-gradient(135deg, #F3F4F6, #E5E7EB);
            color: #374151;
            box-shadow: 0 2px 8px rgba(107, 114, 128, 0.3);
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            padding: 8px 16px;
            border: none;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            color: white;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .btn i {
            margin-right: 6px;
        }

        .btn-view {
            background: linear-gradient(135deg, var(--info-color), #2563EB);
        }

        .btn-approve {
            background: linear-gradient(135deg, var(--success-color), #059669);
        }

        .btn-reject {
            background: linear-gradient(135deg, var(--error-color), #DC2626);
        }

        .btn-prepare {
            background: linear-gradient(135deg, var(--warning-color), #D97706);
        }

        .btn-deliver {
            background: linear-gradient(135deg, #06B6D4, #0891B2);
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 2000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(5px);
            animation: modalFadeIn 0.3s ease-out;
        }

        @keyframes modalFadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-content {
            background: var(--surface-white);
            backdrop-filter: blur(20px);
            margin: 3% auto;
            padding: 0;
            border-radius: 24px;
            width: 90%;
            max-width: 900px;
            max-height: 90vh;
            overflow: hidden;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            border: 1px solid var(--border-light);
            animation: modalSlideIn 0.3s ease-out;
        }

        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: translateY(-50px) scale(0.9);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .modal-header {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            color: white;
            padding: 24px 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-title {
            font-size: 24px;
            font-weight: 700;
            margin: 0;
        }

        .close {
            background: none;
            border: none;
            color: white;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            padding: 0;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .close:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: scale(1.1);
        }

        .modal-body {
            padding: 32px;
            max-height: 70vh;
            overflow-y: auto;
        }

        .order-details {
            margin-top: 0;
        }

        .order-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 24px;
            margin-bottom: 32px;
            padding: 24px;
            background: linear-gradient(135deg, rgba(236, 72, 153, 0.05), rgba(139, 92, 246, 0.05));
            border-radius: 16px;
            border: 1px solid var(--border-light);
        }

        .order-info p {
            margin: 8px 0;
            font-weight: 500;
        }

        .order-info strong {
            color: var(--text-primary);
            font-weight: 700;
        }

        .section-title {
            font-size: 20px;
            font-weight: 700;
            color: var(--text-primary);
            margin: 32px 0 16px 0;
            padding-bottom: 12px;
            border-bottom: 2px solid var(--border-light);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .section-title i {
            color: var(--primary-pink);
        }

        .items-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .item {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            padding: 20px;
            margin-bottom: 12px;
            background: white;
            border-radius: 16px;
            border: 1px solid var(--border-light);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
        }

        .item:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .item:last-child {
            margin-bottom: 0;
        }

        .item-details {
            flex: 1;
        }

        .item-name {
            font-weight: 600;
            font-size: 16px;
            color: var(--text-primary);
            margin-bottom: 8px;
        }

        .item-options {
            font-size: 14px;
            color: var(--text-secondary);
            margin-top: 6px;
            padding: 8px 12px;
            background: rgba(236, 72, 153, 0.05);
            border-radius: 8px;
            border-left: 3px solid var(--primary-pink);
        }

        .item-price {
            font-weight: 700;
            font-size: 16px;
            color: var(--primary-pink);
            text-align: right;
        }

        .receipt-image {
            max-width: 300px;
            width: 100%;
            border-radius: 16px;
            border: 2px solid var(--border-light);
            margin-top: 16px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .receipt-image:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        .order-actions {
            margin-top: 32px;
            padding-top: 24px;
            border-top: 1px solid var(--border-light);
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        /* Loading and Empty States */
        .loading-indicator {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-light);
            font-size: 16px;
            font-weight: 500;
        }

        .loading-indicator::before {
            content: '';
            display: block;
            width: 40px;
            height: 40px;
            margin: 0 auto 20px;
            border: 4px solid var(--border-light);
            border-top: 4px solid var(--primary-pink);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .no-results {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-light);
        }

        .no-results i {
            font-size: 48px;
            margin-bottom: 16px;
            color: var(--primary-pink);
            opacity: 0.5;
        }

        .no-results h3 {
            font-size: 18px;
            margin-bottom: 8px;
            color: var(--text-secondary);
        }

        .no-results p {
            font-size: 14px;
        }

        /* Toast Notifications */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .toast {
            min-width: 350px;
            background: white;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
            overflow: hidden;
            transform: translateX(120%);
            animation: slideIn 0.5s forwards, fadeOut 0.5s 4.5s forwards;
            border: 1px solid var(--border-light);
        }

        .toast-header {
            padding: 16px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
            font-weight: 600;
        }

        .toast-body {
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .toast-icon {
            font-size: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            color: white;
        }

        .toast-content {
            flex: 1;
        }

        .toast-title {
            font-weight: 600;
            margin-bottom: 4px;
            color: var(--text-primary);
        }

        .toast-message {
            font-size: 14px;
            color: var(--text-secondary);
        }

        .toast-close {
            background: none;
            border: none;
            color: white;
            font-size: 18px;
            cursor: pointer;
            opacity: 0.8;
            transition: opacity 0.2s;
            padding: 4px;
            border-radius: 4px;
        }

        .toast-close:hover {
            opacity: 1;
            background: rgba(255, 255, 255, 0.2);
        }

        .toast-progress {
            height: 4px;
            background: rgba(255, 255, 255, 0.3);
            width: 100%;
        }

        .toast-progress-bar {
            height: 100%;
            width: 100%;
            background: rgba(255, 255, 255, 0.8);
            animation: progressShrink 5s linear forwards;
        }

        @keyframes slideIn {
            from { transform: translateX(120%); }
            to { transform: translateX(0); }
        }

        @keyframes fadeOut {
            from { opacity: 1; transform: translateX(0); }
            to { opacity: 0; transform: translateX(120%); }
        }

        @keyframes progressShrink {
            from { width: 100%; }
            to { width: 0%; }
        }

        .toast-success .toast-header {
            background: linear-gradient(135deg, var(--success-color), #059669);
        }

        .toast-error .toast-header {
            background: linear-gradient(135deg, var(--error-color), #DC2626);
        }

        .toast-warning .toast-header {
            background: linear-gradient(135deg, var(--warning-color), #D97706);
        }

        .toast-info .toast-header {
            background: linear-gradient(135deg, var(--info-color), #2563EB);
        }

        .toast-approved .toast-header {
            background: linear-gradient(135deg, var(--accent-purple), #7C3AED);
        }

        .toast-preparing .toast-header {
            background: linear-gradient(135deg, var(--warning-color), #D97706);
        }

        .toast-out_for_delivery .toast-header {
            background: linear-gradient(135deg, #06B6D4, #0891B2);
        }

        .toast-delivered .toast-header {
            background: linear-gradient(135deg, var(--success-color), #059669);
        }

        .toast-rejected .toast-header {
            background: linear-gradient(135deg, var(--error-color), #DC2626);
        }

        .toast-canceled .toast-header {
            background: linear-gradient(135deg, #6B7280, #4B5563);
        }

        /* Confetti Animation */
        .confetti-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 9998;
            overflow: hidden;
        }

        .confetti {
            position: absolute;
            width: 10px;
            height: 10px;
            background-color: var(--primary-pink);
            opacity: 0.8;
            animation: confettiFall 5s ease-in-out forwards;
        }

        @keyframes confettiFall {
            0% {
                transform: translateY(-100px) rotate(0deg);
                opacity: 1;
            }
            100% {
                transform: translateY(100vh) rotate(360deg);
                opacity: 0;
            }
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .sidebar {
                width: 240px;
            }
            
            .search-filters {
                flex-direction: column;
            }
            
            .search-box, .filter-options {
                width: 100%;
                min-width: auto;
            }
        }

        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                min-height: auto;
                position: fixed;
                top: 0;
                left: -100%;
                z-index: 1000;
                transition: left 0.3s ease;
            }
            
            .sidebar.open {
                left: 0;
            }
            
            .main-content {
                padding: 20px;
                margin-top: 0;
            }
            
            .header-section {
                flex-direction: column;
                gap: 16px;
                text-align: center;
                padding: 20px;
            }
            
            .orders-container {
                padding: 20px;
            }
            
            .filter-container {
                padding: 20px;
            }
            
            .modal-content {
                width: 95%;
                margin: 5% auto;
            }
            
            .modal-body {
                padding: 20px;
            }
            
            .order-info {
                grid-template-columns: 1fr;
                gap: 16px;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .toast {
                min-width: 300px;
                right: 10px;
            }
            
            .table-container {
                font-size: 14px;
            }
            
            th, td {
                padding: 12px 8px;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(236, 72, 153, 0.1);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, var(--primary-pink), var(--primary-pink-dark));
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, var(--primary-pink-dark), var(--primary-pink));
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <div class="logo-container">
                <img src="/assets/FavLogo.jpg" alt="AIZCAmble Logo" class="logo">
            </div>
            <div class="brand-name">AIZCAmble</div>
            <div class="admin-title">Admin Panel</div>
        </div>

        <nav class="nav-menu">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                Dashboard
            </a>
            <a href="orders.php" class="nav-item active">
                <i class="fas fa-shopping-bag"></i>
                Manage Orders
            </a>
            <a href="add_product.php" class="nav-item">
                <i class="fas fa-plus-circle"></i>
                Add Product
            </a>
            <a href="stock.php" class="nav-item">
                <i class="fas fa-boxes"></i>
                Stock Management
            </a>
            <a href="sales_analytics.php" class="nav-item">
                <i class="fas fa-chart-bar"></i>
                Sales Analytics
            </a>
            <a href="users.php" class="nav-item">
                <i class="fas fa-users"></i>
                Customers
            </a>
            <a href="ingredients.php" class="nav-item">
                <i class="fas fa-flask"></i>
                Ingredients
            </a>
            <a href="admins.php" class="nav-item">
                <i class="fas fa-user-shield"></i>
                Admins
            </a>
            <a href="shutdown.php" class="nav-item">
                <i class="fas fa-power-off"></i>
                Shutdown Shop
            </a>
            <a href="activity_log.php" class="nav-item">
                <i class="fas fa-history"></i>
                Activity History
            </a>
            <a href="notifications.php" class="nav-item">
                <i class="fas fa-bell"></i>
                Notifications
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header-section">
            <div>
                <h1 class="page-title">Order Management</h1>
                <p class="page-subtitle">Monitor and manage all customer orders efficiently</p>
            </div>
            
            <!-- Notification Bell -->
            <div class="notification-bell">
                <button class="notification-btn" onclick="toggleDropdown()">
                    <i class="fas fa-bell"></i>
                    <?php if ($unreadCount > 0): ?>
                        <span class="notification-badge"><?= $unreadCount ?></span>
                    <?php endif; ?>
                </button>
                
                <div id="notifDropdown" class="notification-dropdown">
                    <div class="notification-header">
                        <span><i class="fas fa-bell"></i> Notifications</span>
                        <?php if ($unreadCount > 0): ?>
                            <a href="orders.php?mark_read=all" style="color: white; font-size: 12px;">
                                <i class="fas fa-check-double"></i> Mark all read
                            </a>
                        <?php endif; ?>
                    </div>
                    
                    <ul class="notification-list">
                        <?php if ($notifQuery->num_rows > 0): ?>
                            <?php while ($notif = $notifQuery->fetch_assoc()): ?>
                                <li class="notification-item <?= $notif['IsRead'] ? '' : 'unread' ?>">
                                    <strong><?= htmlspecialchars($notif['Title']) ?></strong><br>
                                    <small style="color: var(--text-secondary);"><?= htmlspecialchars($notif['message']) ?></small><br>
                                    <small style="color: var(--text-light);">
                                        <i class="fas fa-clock"></i> 
                                        <?= date('M d, Y h:i A', strtotime($notif['CreatedAt'])) ?>
                                    </small>
                                </li>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <li class="notification-item">
                                <div style="text-align: center; padding: 20px;">
                                    <i class="fas fa-bell-slash" style="font-size: 24px; color: var(--text-light); margin-bottom: 8px;"></i>
                                    <p style="color: var(--text-light); margin: 0;">No notifications yet</p>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                    
                    <div class="notification-footer">
                        <a href="notifications.php">
                            <i class="fas fa-external-link-alt"></i> View All Notifications
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Orders Container -->
        <div class="orders-container">
            <!-- Filter Section -->
            <div class="filter-container">
                <div class="search-filters">
                    <div class="search-box">
                        <input type="text" id="order-search" placeholder="🔍 Search orders by ID, customer name, or location..." class="search-input">
                    </div>
                    <div class="filter-options">
                        <select id="status-filter" class="filter-select">
                            <option value="">📋 All Statuses</option>
                            <option value="pending">⏳ Pending</option>
                            <option value="approved">✅ Approved</option>
                            <option value="preparing">👨‍🍳 Preparing</option>
                            <option value="out_for_delivery">🚚 Out for Delivery</option>
                            <option value="delivered">📦 Delivered</option>
                            <option value="rejected">❌ Rejected</option>
                            <option value="canceled">🚫 Canceled</option>
                        </select>
                        <select id="date-filter" class="filter-select">
                            <option value="">📅 All Time</option>
                            <option value="today">📅 Today</option>
                            <option value="week">📅 This Week</option>
                            <option value="month">📅 This Month</option>
                            <option value="year">📅 This Year</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Orders Table -->
            <div id="orders-table-container">
                <div class="table-container">
                    <table id="orders-table">
                        <thead>
                            <tr>
                                <th><i class="fas fa-hashtag"></i> Order ID</th>
                                <th><i class="fas fa-user"></i> Customer</th>
                                <th><i class="fas fa-peso-sign"></i> Amount</th>
                                <th><i class="fas fa-calendar"></i> Date</th>
                                <th><i class="fas fa-info-circle"></i> Status</th>
                                <th><i class="fas fa-cogs"></i> Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $order): ?>
                                <tr data-order-id="<?= $order['id'] ?>">
                                    <td><strong>#<?= $order['id'] ?></strong></td>
                                    <td><?= htmlspecialchars($order['customer_name']) ?></td>
                                    <td><strong>₱<?= number_format($order['total_amount'], 2) ?></strong></td>
                                    <td><?= date('M j, Y h:i A', strtotime($order['created_at'])) ?></td>
                                    <td>
                                        <span class="status-badge status-<?= $order['status'] ?>">
                                            <?php
                                            $statusIcons = [
                                                'pending' => '⏳',
                                                'approved' => '✅',
                                                'preparing' => '👨‍🍳',
                                                'out_for_delivery' => '🚚',
                                                'delivered' => '📦',
                                                'rejected' => '❌',
                                                'canceled' => '🚫'
                                            ];
                                            echo $statusIcons[$order['status']] ?? '';
                                            ?>
                                            <?= ucfirst(str_replace('_', ' ', $order['status'])) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <button class="btn btn-view" onclick="viewOrder(<?= $order['id'] ?>)">
                                                <i class="fas fa-eye"></i> View
                                            </button>
                                            
                                            <?php if ($order['status'] == 'pending'): ?>
                                                <button class="btn btn-approve" onclick="updateOrderStatus(<?= $order['id'] ?>, 'approved')">
                                                    <i class="fas fa-check"></i> Approve
                                                </button>
                                                <button class="btn btn-reject" onclick="updateOrderStatus(<?= $order['id'] ?>, 'rejected')">
                                                    <i class="fas fa-times"></i> Reject
                                                </button>
                                            <?php elseif ($order['status'] == 'approved'): ?>
                                                <button class="btn btn-prepare" onclick="updateOrderStatus(<?= $order['id'] ?>, 'preparing')">
                                                    <i class="fas fa-utensils"></i> Prepare
                                                </button>
                                            <?php elseif ($order['status'] == 'preparing'): ?>
                                                <button class="btn btn-deliver" onclick="updateOrderStatus(<?= $order['id'] ?>, 'out_for_delivery')">
                                                    <i class="fas fa-truck"></i> Deliver
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Order Details Modal -->
    <div id="orderModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title"><i class="fas fa-receipt"></i> Order Details</h3>
                <button class="close" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                <div id="orderDetails" class="order-details">
                    <div class="loading-indicator">Loading order details...</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast Notification Container -->
    <div id="toastContainer" class="toast-container"></div>
    
    <!-- Confetti Container for Celebrations -->
    <div id="confettiContainer" class="confetti-container"></div>

    <script>
        document.addEventListener("DOMContentLoaded", () => {
            // Get filter elements
            const searchInput = document.getElementById("order-search");
            const statusFilter = document.getElementById("status-filter");
            const dateFilter = document.getElementById("date-filter");
            
            // Add event listeners for filters
            searchInput.addEventListener("input", debounce(filterOrders, 300));
            statusFilter.addEventListener("change", filterOrders);
            dateFilter.addEventListener("change", filterOrders);
            
            // Function to filter orders
            function filterOrders() {
                const searchTerm = searchInput.value.trim();
                const statusValue = statusFilter.value;
                const dateValue = dateFilter.value;
                
                // Show loading indicator
                const tableContainer = document.getElementById("orders-table-container");
                let loadingIndicator = tableContainer.querySelector(".loading-indicator");
                
                if (!loadingIndicator) {
                    loadingIndicator = document.createElement("div");
                    loadingIndicator.className = "loading-indicator";
                    loadingIndicator.textContent = "Loading orders...";
                    tableContainer.appendChild(loadingIndicator);
                }
                
                // Hide the table while loading
                const table = document.getElementById("orders-table");
                table.style.display = "none";
                
                // Build query parameters
                const params = new URLSearchParams();
                params.append("ajax", "true");
                
                if (searchTerm) params.append("search", searchTerm);
                if (statusValue) params.append("status", statusValue);
                if (dateValue) params.append("date_filter", dateValue);
                
                // Fetch filtered orders
                fetch(`orders.php?${params.toString()}`)
                    .then(response => response.json())
                    .then(data => {
                        // Remove loading indicator
                        if (loadingIndicator) {
                            tableContainer.removeChild(loadingIndicator);
                        }
                        
                        // Show the table again
                        table.style.display = "table";
                        
                        // Get the table body
                        const tableBody = table.querySelector("tbody");
                        
                        // Clear existing rows
                        tableBody.innerHTML = "";
                        
                        // Check if we have orders
                        if (data.success && data.orders && data.orders.length > 0) {
                            // Add new rows
                            data.orders.forEach(order => {
                                const row = document.createElement("tr");
                                row.setAttribute("data-order-id", order.id);
                                
                                // Format the date
                                const orderDate = new Date(order.created_at);
                                const formattedDate = orderDate.toLocaleDateString('en-US', {
                                    month: 'short',
                                    day: 'numeric',
                                    year: 'numeric',
                                    hour: 'numeric',
                                    minute: 'numeric',
                                    hour12: true
                                });
                                
                                // Format the status for display
                                const displayStatus = order.status.charAt(0).toUpperCase() + 
                                                     order.status.slice(1).replace('_', ' ');
                                
                                // Status icons
                                const statusIcons = {
                                    'pending': '⏳',
                                    'approved': '✅',
                                    'preparing': '👨‍🍳',
                                    'out_for_delivery': '🚚',
                                    'delivered': '📦',
                                    'rejected': '❌',
                                    'canceled': '🚫'
                                };
                                
                                row.innerHTML = `
                                    <td><strong>#${order.id}</strong></td>
                                    <td>${escapeHtml(order.customer_name)}</td>
                                    <td><strong>₱${parseFloat(order.total_amount).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</strong></td>
                                    <td>${formattedDate}</td>
                                    <td>
                                        <span class="status-badge status-${order.status}">
                                            ${statusIcons[order.status] || ''} ${displayStatus}
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <button class="btn btn-view" onclick="viewOrder(${order.id})">
                                                <i class="fas fa-eye"></i> View
                                            </button>
                                            
                                            ${order.status === 'pending' ? `
                                                <button class="btn btn-approve" onclick="updateOrderStatus(${order.id}, 'approved')">
                                                    <i class="fas fa-check"></i> Approve
                                                </button>
                                                <button class="btn btn-reject" onclick="updateOrderStatus(${order.id}, 'rejected')">
                                                    <i class="fas fa-times"></i> Reject
                                                </button>
                                            ` : ''}
                                            
                                            ${order.status === 'approved' ? `
                                                <button class="btn btn-prepare" onclick="updateOrderStatus(${order.id}, 'preparing')">
                                                    <i class="fas fa-utensils"></i> Prepare
                                                </button>
                                            ` : ''}
                                            
                                            ${order.status === 'preparing' ? `
                                                <button class="btn btn-deliver" onclick="updateOrderStatus(${order.id}, 'out_for_delivery')">
                                                    <i class="fas fa-truck"></i> Deliver
                                                </button>
                                            ` : ''}
                                        </div>
                                    </td>
                                `;
                                
                                tableBody.appendChild(row);
                            });
                        } else {
                            // No orders found
                            const noResultsRow = document.createElement("tr");
                            noResultsRow.innerHTML = `
                                <td colspan="6" class="no-results">
                                    <i class="fas fa-search"></i>
                                    <h3>No Orders Found</h3>
                                    <p>No orders match your search criteria. Try adjusting your filters.</p>
                                </td>
                            `;
                            tableBody.appendChild(noResultsRow);
                        }
                    })
                    .catch(error => {
                        console.error("Error fetching orders:", error);
                        
                        // Remove loading indicator
                        if (loadingIndicator) {
                            tableContainer.removeChild(loadingIndicator);
                        }
                        
                        // Show the table again
                        table.style.display = "table";
                        
                        // Show error message
                        const tableBody = table.querySelector("tbody");
                        tableBody.innerHTML = `
                            <tr>
                                <td colspan="6" class="no-results">
                                    <i class="fas fa-exclamation-triangle"></i>
                                    <h3>Error Loading Orders</h3>
                                    <p>Something went wrong. Please try again.</p>
                                </td>
                            </tr>
                        `;
                    });
            }
        });

        // Helper function to escape HTML
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        // Debounce function to limit how often a function can be called
        function debounce(func, delay) {
            let timeout;
            return function() {
                const context = this;
                const args = arguments;
                clearTimeout(timeout);
                timeout = setTimeout(() => func.apply(context, args), delay);
            };
        }

        // Function to view order details
        function viewOrder(orderId) {
            const modal = document.getElementById("orderModal");
            const orderDetails = document.getElementById("orderDetails");
            
            // Show modal
            modal.style.display = "block";
            
            // Show loading indicator
            orderDetails.innerHTML = '<div class="loading-indicator">Loading order details...</div>';
            
            // Fetch order details
            fetch(`get_order_details.php?order_id=${orderId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const order = data.order;
                        
                        // Format the date
                        const orderDate = new Date(order.created_at);
                        const formattedDate = orderDate.toLocaleDateString('en-US', {
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric',
                            hour: 'numeric',
                            minute: 'numeric',
                            hour12: true
                        });
                        
                        // Format the status for display
                        const displayStatus = order.status.charAt(0).toUpperCase() + 
                                             order.status.slice(1).replace('_', ' ');
                        
                        // Status icons
                        const statusIcons = {
                            'pending': '⏳',
                            'approved': '✅',
                            'preparing': '👨‍🍳',
                            'out_for_delivery': '🚚',
                            'delivered': '📦',
                            'rejected': '❌',
                            'canceled': '🚫'
                        };
                        
                        // Build HTML for order details
                        let html = `
                            <div class="order-info">
                                <div>
                                    <p><strong><i class="fas fa-hashtag"></i> Order ID:</strong> #${order.id}</p>
                                    <p><strong><i class="fas fa-user"></i> Customer:</strong> ${escapeHtml(order.customer_name)}</p>
                                    <p><strong><i class="fas fa-calendar"></i> Date:</strong> ${formattedDate}</p>
                                </div>
                                <div>
                                    <p><strong><i class="fas fa-info-circle"></i> Status:</strong> 
                                        <span class="status-badge status-${order.status}">
                                            ${statusIcons[order.status] || ''} ${displayStatus}
                                        </span>
                                    </p>
                                    <p><strong><i class="fas fa-credit-card"></i> Payment Method:</strong> ${order.payment_method.toUpperCase()}</p>
                                    <p><strong><i class="fas fa-peso-sign"></i> Total Amount:</strong> ₱${parseFloat(order.total_amount).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
                                </div>
                                <div>
                                    <p><strong><i class="fas fa-map-marker-alt"></i> Delivery Area:</strong> ${escapeHtml(order.area)}</p>
                                    ${order.landmark ? `<p><strong><i class="fas fa-landmark"></i> Landmark:</strong> ${escapeHtml(order.landmark)}</p>` : ''}
                                </div>
                            </div>
                        `;
                        
                        // Add order items
                        if (order.items && order.items.length > 0) {
                            html += `
                                <h3 class="section-title">
                                    <i class="fas fa-shopping-cart"></i>
                                    Order Items
                                </h3>
                                <ul class="items-list">
                            `;
                            
                            order.items.forEach(item => {
                                html += `
                                    <li class="item">
                                        <div class="item-details">
                                            <div class="item-name">
                                                <i class="fas fa-utensils"></i>
                                                ${escapeHtml(item.name)} x ${item.quantity}
                                            </div>
                                `;
                                
                                if (item.customizations) {
                                    const customizations = JSON.parse(item.customizations);
                                    if (customizations && Object.keys(customizations).length > 0) {
                                        html += '<div class="item-options">';
                                        html += '<i class="fas fa-cog"></i> ';
                                        
                                        for (const [key, value] of Object.entries(customizations)) {
                                            const displayValue = Array.isArray(value) ? value.join('/') : value;
                                            html += `${escapeHtml(key)}: ${escapeHtml(displayValue)}, `;
                                        }
                                        
                                        // Remove trailing comma and space
                                        html = html.slice(0, -2);
                                        html += '</div>';
                                    }
                                }
                                
                                html += `
                                        </div>
                                        <div class="item-price">₱${parseFloat(item.price * item.quantity).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                                    </li>
                                `;
                            });
                            
                            html += '</ul>';
                        }
                        
                        // Add payment receipt if available
                        if (order.payment_method === 'gcash') {
                            html += '<h3 class="section-title"><i class="fas fa-receipt"></i> Payment Details</h3>';
                            
                            if (order.transaction_id) {
                                html += `<p><strong><i class="fas fa-hashtag"></i> Transaction ID:</strong> ${escapeHtml(order.transaction_id)}</p>`;
                            }
                            
                            if (order.receipt_image) {
                                html += `
                                    <p><strong><i class="fas fa-image"></i> Payment Receipt:</strong></p>
                                    <img src="${order.receipt_image}" alt="GCASH Receipt" class="receipt-image">
                                `;
                            }
                        }
                        
                        // Add action buttons based on status
                        html += '<div class="order-actions">';
                        
                        if (order.status === 'pending') {
                            html += `
                                <button class="btn btn-approve" onclick="updateOrderStatus(${order.id}, 'approved')">
                                    <i class="fas fa-check"></i> Approve Order
                                </button>
                                <button class="btn btn-reject" onclick="updateOrderStatus(${order.id}, 'rejected')">
                                    <i class="fas fa-times"></i> Reject Order
                                </button>
                            `;
                        } else if (order.status === 'approved') {
                            html += `
                                <button class="btn btn-prepare" onclick="updateOrderStatus(${order.id}, 'preparing')">
                                    <i class="fas fa-utensils"></i> Start Preparing
                                </button>
                            `;
                        } else if (order.status === 'preparing') {
                            html += `
                                <button class="btn btn-deliver" onclick="updateOrderStatus(${order.id}, 'out_for_delivery')">
                                    <i class="fas fa-truck"></i> Out for Delivery
                                </button>
                            `;
                        }
                        
                        html += '</div>';
                        
                        // Update the modal content
                        orderDetails.innerHTML = html;
                    } else {
                        orderDetails.innerHTML = `
                            <div class="no-results">
                                <i class="fas fa-exclamation-triangle"></i>
                                <h3>Error Loading Order</h3>
                                <p>Unable to load order details. Please try again.</p>
                            </div>
                        `;
                    }
                })
                .catch(error => {
                    console.error("Error fetching order details:", error);
                    orderDetails.innerHTML = `
                        <div class="no-results">
                            <i class="fas fa-exclamation-triangle"></i>
                            <h3>Error Loading Order</h3>
                            <p>Something went wrong. Please try again.</p>
                        </div>
                    `;
                });
        }

        // Function to update order status
        function updateOrderStatus(orderId, newStatus) {
            // Get customer name from the row
            const orderRow = document.querySelector(`tr[data-order-id="${orderId}"]`);
            const customerName = orderRow ? orderRow.querySelector('td:nth-child(2)').textContent : 'Customer';
            const orderAmount = orderRow ? orderRow.querySelector('td:nth-child(3)').textContent : '';
            
            // Configure SweetAlert based on status
            let icon, title, text, confirmButtonColor, showConfetti = false;
            
            switch(newStatus) {
                case 'approved':
                    icon = 'success';
                    title = '✅ Approve Order?';
                    text = `Are you sure you want to approve Order #${orderId} from ${customerName}?`;
                    confirmButtonColor = '#10B981';
                    showConfetti = true;
                    break;
                case 'preparing':
                    icon = 'info';
                    title = '👨‍🍳 Start Preparing?';
                    text = `Are you sure you want to start preparing Order #${orderId}?`;
                    confirmButtonColor = '#F59E0B';
                    break;
                case 'out_for_delivery':
                    icon = 'info';
                    title = '🚚 Out for Delivery?';
                    text = `Are you sure you want to mark Order #${orderId} as out for delivery?`;
                    confirmButtonColor = '#06B6D4';
                    break;
                case 'delivered':
                    icon = 'success';
                    title = '📦 Mark as Delivered?';
                    text = `Are you sure you want to mark Order #${orderId} as delivered?`;
                    confirmButtonColor = '#10B981';
                    break;
                case 'rejected':
                    icon = 'warning';
                    title = '❌ Reject Order?';
                    text = `Are you sure you want to reject Order #${orderId} from ${customerName}?`;
                    confirmButtonColor = '#EF4444';
                    break;
                default:
                    icon = 'question';
                    title = 'Update Status?';
                    text = `Are you sure you want to change Order #${orderId} status to ${newStatus.replace('_', ' ')}?`;
                    confirmButtonColor = '#EC4899';
            }
            
            // Show SweetAlert confirmation
            Swal.fire({
                title: title,
                html: `
                    <div style="text-align: left; margin-bottom: 15px; padding: 20px; background: linear-gradient(135deg, rgba(236, 72, 153, 0.05), rgba(139, 92, 246, 0.05)); border-radius: 12px; border: 1px solid rgba(236, 72, 153, 0.1);">
                        <p style="margin-bottom: 12px; font-size: 16px;">${text}</p>
                        <p style="margin: 8px 0;"><strong><i class="fas fa-user"></i> Customer:</strong> ${customerName}</p>
                        <p style="margin: 8px 0;"><strong><i class="fas fa-peso-sign"></i> Amount:</strong> ${orderAmount}</p>
                    </div>
                `,
                icon: icon,
                showCancelButton: true,
                confirmButtonColor: confirmButtonColor,
                cancelButtonColor: '#6B7280',
                confirmButtonText: '✨ Yes, proceed!',
                cancelButtonText: '❌ Cancel',
                customClass: {
                    popup: 'swal-custom-popup',
                    confirmButton: 'swal-custom-confirm',
                    cancelButton: 'swal-custom-cancel'
                },
                showClass: {
                    popup: 'animate__animated animate__fadeInDown'
                },
                hideClass: {
                    popup: 'animate__animated animate__fadeOutUp'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // Show loading state
                    Swal.fire({
                        title: '⚡ Processing...',
                        html: `
                            <div style="text-align: center; padding: 20px;">
                                <div style="margin-bottom: 16px;">
                                    <i class="fas fa-spinner fa-spin" style="font-size: 32px; color: #EC4899;"></i>
                                </div>
                                <p>Updating order status to <strong>${newStatus.replace('_', ' ')}</strong></p>
                            </div>
                        `,
                        allowOutsideClick: false,
                        showConfirmButton: false,
                        customClass: {
                            popup: 'swal-loading-popup'
                        }
                    });
                    
                    // Update in modal if open
                    const modal = document.getElementById("orderModal");
                    if (modal.style.display === "block") {
                        const modalActions = modal.querySelector('.order-actions');
                        if (modalActions) {
                            modalActions.innerHTML = `
                                <div style="text-align: center; padding: 20px; color: #6B7280;">
                                    <i class="fas fa-spinner fa-spin" style="margin-right: 8px;"></i>
                                    Updating status...
                                </div>
                            `;
                        }
                    }
                    
                    // Send update request
                    fetch('update_order_status.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `order_id=${orderId}&status=${newStatus}`
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Close modal if open
                            closeModal();
                            
                            // Configure success message based on status
                            let successIcon, successTitle, successText;
                            
                            switch(newStatus) {
                                case 'approved':
                                    successIcon = 'success';
                                    successTitle = '🎉 Order Approved!';
                                    successText = `Order #${orderId} from ${customerName} has been approved and is ready for preparation.`;
                                    break;
                                case 'preparing':
                                    successIcon = 'info';
                                    successTitle = '👨‍🍳 Order In Preparation!';
                                    successText = `Order #${orderId} is now being prepared in the kitchen.`;
                                    break;
                                case 'out_for_delivery':
                                    successIcon = 'info';
                                    successTitle = '🚚 Order Out for Delivery!';
                                    successText = `Order #${orderId} is now out for delivery.`;
                                    break;
                                case 'delivered':
                                    successIcon = 'success';
                                    successTitle = '📦 Order Delivered!';
                                    successText = `Order #${orderId} has been successfully delivered.`;
                                    break;
                                case 'rejected':
                                    successIcon = 'error';
                                    successTitle = '❌ Order Rejected';
                                    successText = `Order #${orderId} from ${customerName} has been rejected.`;
                                    break;
                                default:
                                    successIcon = 'success';
                                    successTitle = '✅ Status Updated!';
                                    successText = `Order #${orderId} status has been updated to ${newStatus.replace('_', ' ')}.`;
                            }
                            
                            // Show success message with confetti for approved orders
                            if (showConfetti) {
                                Swal.fire({
                                    title: successTitle,
                                    text: successText,
                                    icon: successIcon,
                                    confirmButtonColor: confirmButtonColor,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        popup: 'swal-success-popup'
                                    },
                                    didOpen: () => {
                                        // Add confetti effect
                                        const confettiScript = document.createElement('script');
                                        confettiScript.src = 'https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js';
                                        document.head.appendChild(confettiScript);
                                        
                                        confettiScript.onload = () => {
                                            const duration = 3 * 1000;
                                            const end = Date.now() + duration;
                                            
                                            (function frame() {
                                                confetti({
                                                    particleCount: 7,
                                                    angle: 60,
                                                    spread: 55,
                                                    origin: { x: 0 },
                                                    colors: ['#EC4899', '#8B5CF6', '#F59E0B']
                                                });
                                                confetti({
                                                    particleCount: 7,
                                                    angle: 120,
                                                    spread: 55,
                                                    origin: { x: 1 },
                                                    colors: ['#10B981', '#3B82F6', '#EC4899']
                                                });
                                                
                                                if (Date.now() < end) {
                                                    requestAnimationFrame(frame);
                                                }
                                            }());
                                        };
                                    }
                                });
                            } else {
                                Swal.fire({
                                    title: successTitle,
                                    text: successText,
                                    icon: successIcon,
                                    confirmButtonColor: confirmButtonColor,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    customClass: {
                                        popup: 'swal-success-popup'
                                    }
                                });
                            }
                            
                            // Refresh the orders list
                            setTimeout(() => {
                                filterOrders();
                            }, 1000);
                        } else {
                            throw new Error(data.message || 'Failed to update order status');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire({
                            title: '❌ Error!',
                            text: error.message || 'Something went wrong while updating the order status.',
                            icon: 'error',
                            confirmButtonColor: '#EF4444',
                            customClass: {
                                popup: 'swal-error-popup'
                            }
                        });
                        
                        // Refresh to show current state
                        filterOrders();
                    });
                }
            });
        }

        // Function to close the modal
        function closeModal() {
            const modal = document.getElementById("orderModal");
            modal.style.display = "none";
        }

        // Close modal when clicking outside of it
        window.onclick = function(event) {
            const modal = document.getElementById("orderModal");
            if (event.target === modal) {
                modal.style.display = "none";
            }
        }

        // Global function to filter orders (for use in event handlers)
        function filterOrders() {
            const searchInput = document.getElementById("order-search");
            const statusFilter = document.getElementById("status-filter");
            const dateFilter = document.getElementById("date-filter");
            
            const searchTerm = searchInput.value.trim();
            const statusValue = statusFilter.value;
            const dateValue = dateFilter.value;
            
            // Show loading indicator
            const tableContainer = document.getElementById("orders-table-container");
            let loadingIndicator = tableContainer.querySelector(".loading-indicator");
            
            if (!loadingIndicator) {
                loadingIndicator = document.createElement("div");
                loadingIndicator.className = "loading-indicator";
                loadingIndicator.textContent = "Loading orders...";
                tableContainer.appendChild(loadingIndicator);
            }
            
            // Hide the table while loading
            const table = document.getElementById("orders-table");
            table.style.display = "none";
            
            // Build query parameters
            const params = new URLSearchParams();
            params.append("ajax", "true");
            
            if (searchTerm) params.append("search", searchTerm);
            if (statusValue) params.append("status", statusValue);
            if (dateValue) params.append("date_filter", dateValue);
            
            // Fetch filtered orders
            fetch(`orders.php?${params.toString()}`)
                .then(response => response.json())
                .then(data => {
                    // Remove loading indicator
                    if (loadingIndicator) {
                        tableContainer.removeChild(loadingIndicator);
                    }
                    
                    // Show the table again
                    table.style.display = "table";
                    
                    // Get the table body
                    const tableBody = table.querySelector("tbody");
                    
                    // Clear existing rows
                    tableBody.innerHTML = "";
                    
                    // Check if we have orders
                    if (data.success && data.orders && data.orders.length > 0) {
                        // Add new rows
                        data.orders.forEach(order => {
                            const row = document.createElement("tr");
                            row.setAttribute("data-order-id", order.id);
                            
                            // Format the date
                            const orderDate = new Date(order.created_at);
                            const formattedDate = orderDate.toLocaleDateString('en-US', {
                                month: 'short',
                                day: 'numeric',
                                year: 'numeric',
                                hour: 'numeric',
                                minute: 'numeric',
                                hour12: true
                            });
                            
                            // Format the status for display
                            const displayStatus = order.status.charAt(0).toUpperCase() + 
                                                 order.status.slice(1).replace('_', ' ');
                            
                            // Status icons
                            const statusIcons = {
                                'pending': '⏳',
                                'approved': '✅',
                                'preparing': '👨‍🍳',
                                'out_for_delivery': '🚚',
                                'delivered': '📦',
                                'rejected': '❌',
                                'canceled': '🚫'
                            };
                            
                            row.innerHTML = `
                                <td><strong>#${order.id}</strong></td>
                                <td>${escapeHtml(order.customer_name)}</td>
                                <td><strong>₱${parseFloat(order.total_amount).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</strong></td>
                                <td>${formattedDate}</td>
                                <td>
                                    <span class="status-badge status-${order.status}">
                                        ${statusIcons[order.status] || ''} ${displayStatus}
                                    </span>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="btn btn-view" onclick="viewOrder(${order.id})">
                                            <i class="fas fa-eye"></i> View
                                        </button>
                                        
                                        ${order.status === 'pending' ? `
                                            <button class="btn btn-approve" onclick="updateOrderStatus(${order.id}, 'approved')">
                                                <i class="fas fa-check"></i> Approve
                                            </button>
                                            <button class="btn btn-reject" onclick="updateOrderStatus(${order.id}, 'rejected')">
                                                <i class="fas fa-times"></i> Reject
                                            </button>
                                        ` : ''}
                                        
                                        ${order.status === 'approved' ? `
                                            <button class="btn btn-prepare" onclick="updateOrderStatus(${order.id}, 'preparing')">
                                                <i class="fas fa-utensils"></i> Prepare
                                            </button>
                                        ` : ''}
                                        
                                        ${order.status === 'preparing' ? `
                                            <button class="btn btn-deliver" onclick="updateOrderStatus(${order.id}, 'out_for_delivery')">
                                                <i class="fas fa-truck"></i> Deliver
                                            </button>
                                        ` : ''}
                                    </div>
                                </td>
                            `;
                            
                            tableBody.appendChild(row);
                        });
                    } else {
                        // No orders found
                        const noResultsRow = document.createElement("tr");
                        noResultsRow.innerHTML = `
                            <td colspan="6" class="no-results">
                                <i class="fas fa-search"></i>
                                <h3>No Orders Found</h3>
                                <p>No orders match your search criteria. Try adjusting your filters.</p>
                            </td>
                        `;
                        tableBody.appendChild(noResultsRow);
                    }
                })
                .catch(error => {
                    console.error("Error fetching orders:", error);
                    
                    // Remove loading indicator
                    if (loadingIndicator) {
                        tableContainer.removeChild(loadingIndicator);
                    }
                    
                    // Show the table again
                    table.style.display = "table";
                    
                    // Show error message
                    const tableBody = table.querySelector("tbody");
                    tableBody.innerHTML = `
                        <tr>
                            <td colspan="6" class="no-results">
                                <i class="fas fa-exclamation-triangle"></i>
                                <h3>Error Loading Orders</h3>
                                <p>Something went wrong. Please try again.</p>
                            </td>
                        </tr>
                    `;
                });
        }

        // Notification dropdown toggle
        function toggleDropdown() {
            const dropdown = document.getElementById('notifDropdown');
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        }

        // Close dropdown when clicking outside
        window.addEventListener('click', function(event) {
            const dropdown = document.getElementById('notifDropdown');
            const bell = document.querySelector('.notification-btn');
            if (!bell.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = 'none';
            }
        });

        // Toast notification system
        function showToast(type, title, message, icon = '') {
            const toastContainer = document.getElementById('toastContainer');
            
            // Create toast element
            const toast = document.createElement('div');
            toast.className = `toast toast-${type}`;
            
            // Create toast content
            toast.innerHTML = `
                <div class="toast-header">
                    <span>${title}</span>
                    <button class="toast-close" onclick="this.parentElement.parentElement.remove()">×</button>
                </div>
                <div class="toast-body">
                    <div class="toast-icon">${icon}</div>
                    <div class="toast-content">
                        <div class="toast-message">${message}</div>
                    </div>
                </div>
                <div class="toast-progress">
                    <div class="toast-progress-bar"></div>
                </div>
            `;
            
            // Add to container
            toastContainer.appendChild(toast);
            
            // Remove after animation completes
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.remove();
                }
            }, 5000);
            
            // If it's an approval, show confetti
            if (type === 'approved') {
                showConfetti();
            }
        }
        
        // Create confetti celebration effect
        function showConfetti() {
            const confettiContainer = document.getElementById('confettiContainer');
            confettiContainer.innerHTML = ''; // Clear any existing confetti
            
            const colors = ['#EC4899', '#8B5CF6', '#F59E0B', '#10B981', '#3B82F6', '#F472B6'];
            
            // Create 100 confetti pieces
            for (let i = 0; i < 100; i++) {
                const confetti = document.createElement('div');
                confetti.className = 'confetti';
                
                // Randomize confetti properties
                const size = Math.random() * 10 + 5;
                const color = colors[Math.floor(Math.random() * colors.length)];
                const left = Math.random() * 100;
                const delay = Math.random() * 3;
                const rotation = Math.random() * 360;
                
                // Apply styles
                confetti.style.width = `${size}px`;
                confetti.style.height = `${size}px`;
                confetti.style.backgroundColor = color;
                confetti.style.left = `${left}%`;
                confetti.style.animationDelay = `${delay}s`;
                confetti.style.transform = `rotate(${rotation}deg)`;
                
                // Some confetti can be different shapes
                if (i % 3 === 0) {
                    confetti.style.borderRadius = '50%'; // Circle
                } else if (i % 5 === 0) {
                    confetti.style.width = `${size}px`;
                    confetti.style.height = `${size/2}px`;
                    confetti.style.borderRadius = `${size/4}px`;
                }
                
                confettiContainer.appendChild(confetti);
            }
            
            // Remove confetti after animation completes
            setTimeout(() => {
                confettiContainer.innerHTML = '';
            }, 5000);
        }

        // Mobile sidebar toggle (for responsive design)
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('open');
        }

        // Add mobile menu button if needed
        if (window.innerWidth <= 768) {
            const header = document.querySelector('.header-section');
            const menuBtn = document.createElement('button');
            menuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            menuBtn.className = 'btn';
            menuBtn.onclick = toggleSidebar;
            menuBtn.style.order = '-1';
            header.insertBefore(menuBtn, header.firstChild);
        }

        // Add custom SweetAlert styles
        const swalStyles = document.createElement('style');
        swalStyles.textContent = `
            .swal-custom-popup {
                border-radius: 20px !important;
                border: 2px solid rgba(236, 72, 153, 0.2) !important;
            }
            .swal-custom-confirm {
                border-radius: 12px !important;
                font-weight: 600 !important;
                padding: 12px 24px !important;
            }
            .swal-custom-cancel {
                border-radius: 12px !important;
                font-weight: 600 !important;
                padding: 12px 24px !important;
            }
            .swal-loading-popup {
                border-radius: 20px !important;
            }
            .swal-success-popup {
                border-radius: 20px !important;
                border: 2px solid rgba(16, 185, 129, 0.2) !important;
            }
            .swal-error-popup {
                border-radius: 20px !important;
                border: 2px solid rgba(239, 68, 68, 0.2) !important;
            }
        `;
        document.head.appendChild(swalStyles);
    </script>
</body>
</html>