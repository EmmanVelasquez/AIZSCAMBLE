<?php
session_start();
include('../includes/db.php');

if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header('Content-Type: application/json');
    die(json_encode(['success' => false, 'error' => 'Unauthorized']));
}

$product_id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
if (!$product_id) {
    header('Content-Type: application/json');
    die(json_encode(['success' => false, 'error' => 'Invalid product ID']));
}

// Validate and sanitize inputs
$name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
$price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
$stock = filter_input(INPUT_POST, 'stock', FILTER_VALIDATE_INT);
$is_customizable = isset($_POST['is_customizable']) ? 1 : 0;
$description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
$remove_image = isset($_POST['remove_image']);

// Get ingredient data
$ingredient_ids = $_POST['ingredient_id'] ?? [];
$ingredient_quantities = $_POST['ingredient_quantity'] ?? [];

// Validate ingredients
$ingredients = [];
foreach ($ingredient_ids as $index => $ingredient_id) {
    $ingredient_id = filter_var($ingredient_id, FILTER_VALIDATE_INT);
    $quantity = filter_var($ingredient_quantities[$index] ?? 0, FILTER_VALIDATE_FLOAT);
    
    if ($ingredient_id && $quantity > 0) {
        $ingredients[] = [
            'id' => $ingredient_id,
            'quantity' => $quantity
        ];
    }
}

$image_path = null;
$current_image = null;
$error = null;

try {
    // Start transaction
    $conn->autocommit(false);

    // Get current image
    $stmt = $conn->prepare("SELECT image FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $current_image = $row['image'];
    }

    // Handle image upload/removal
    if (!empty($_FILES['product_image']['name'])) {
        // Remove old image if exists
        if ($current_image && file_exists($current_image)) {
            if (!unlink($current_image)) {
                throw new Exception("Failed to remove old image");
            }
        }
        
        $image_name = basename($_FILES["product_image"]["name"]);
        $target_dir = "../uploads/";
        $unique_name = time() . "_" . $image_name;
        $target_file = $target_dir . $unique_name;

        if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
            $image_path = $target_file;
        } else {
            throw new Exception("Failed to upload new image");
        }
    } elseif ($remove_image && $current_image) {
        // Remove current image
        if (file_exists($current_image)) {
            if (!unlink($current_image)) {
                throw new Exception("Failed to remove current image");
            }
        }
        $image_path = null;
    } else {
        // Keep current image
        $image_path = $current_image;
    }

    // Update product
    $sql = "UPDATE products SET name=?, price=?, stock=?, is_customizable=?, description=?";
    $types = "sdiis";
    $params = [$name, $price, $stock, $is_customizable, $description];
    
    if ($image_path !== null) {
        $sql .= ", image=?";
        $types .= "s";
        $params[] = $image_path;
    }
    
    $sql .= " WHERE id=?";
    $types .= "i";
    $params[] = $product_id;
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    
    if (!$stmt->execute()) {
        throw new Exception("Failed to update product: " . $stmt->error);
    }
    
    // Delete existing customizable options
    $delete_stmt = $conn->prepare("DELETE FROM customizable_options WHERE product_id = ?");
    $delete_stmt->bind_param("i", $product_id);
    if (!$delete_stmt->execute()) {
        throw new Exception("Failed to delete existing options: " . $delete_stmt->error);
    }
    
    // Process customizable options if product is customizable
    if ($is_customizable) {
        // Process sizes
        if (!empty($_POST['size_names'])) {
            $option_stmt = $conn->prepare("INSERT INTO customizable_options (product_id, option_name, option_value, price) VALUES (?, 'Size', ?, ?)");
            foreach ($_POST['size_names'] as $i => $name) {
                if (!empty($name) && isset($_POST['size_prices'][$i])) {
                    $option_stmt->bind_param("isd", $product_id, $name, $_POST['size_prices'][$i]);
                    if (!$option_stmt->execute()) {
                        throw new Exception("Failed to insert size option: " . $option_stmt->error);
                    }
                }
            }
        }
        
        // Process flavors
        if (!empty($_POST['flavor_names'])) {
            $option_stmt = $conn->prepare("INSERT INTO customizable_options (product_id, option_name, option_value, price) VALUES (?, 'Flavor', ?, ?)");
            foreach ($_POST['flavor_names'] as $i => $name) {
                if (!empty($name) && isset($_POST['flavor_prices'][$i])) {
                    $option_stmt->bind_param("isd", $product_id, $name, $_POST['flavor_prices'][$i]);
                    if (!$option_stmt->execute()) {
                        throw new Exception("Failed to insert flavor option: " . $option_stmt->error);
                    }
                }
            }
        }
        
        // Process add-ons
        if (!empty($_POST['add_on_names'])) {
            $option_stmt = $conn->prepare("INSERT INTO customizable_options (product_id, option_name, option_value, price) VALUES (?, 'Add-on', ?, ?)");
            foreach ($_POST['add_on_names'] as $i => $name) {
                if (!empty($name) && isset($_POST['add_on_prices'][$i])) {
                    $option_stmt->bind_param("isd", $product_id, $name, $_POST['add_on_prices'][$i]);
                    if (!$option_stmt->execute()) {
                        throw new Exception("Failed to insert add-on option: " . $option_stmt->error);
                    }
                }
            }
        }
    }
    
    // Handle product ingredients
    $delete_ingredients_stmt = $conn->prepare("DELETE FROM product_ingredients WHERE product_id = ?");
    $delete_ingredients_stmt->bind_param("i", $product_id);
    if (!$delete_ingredients_stmt->execute()) {
        throw new Exception("Failed to delete existing ingredients: " . $delete_ingredients_stmt->error);
    }
    
    if (!empty($ingredients)) {
        $ingredient_stmt = $conn->prepare("INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES (?, ?, ?)");
        foreach ($ingredients as $ingredient) {
            $ingredient_stmt->bind_param("iid", $product_id, $ingredient['id'], $ingredient['quantity']);
            if (!$ingredient_stmt->execute()) {
                throw new Exception("Failed to insert product ingredient: " . $ingredient_stmt->error);
            }
        }
    }
    
    // Commit transaction
    if (!$conn->commit()) {
        throw new Exception("Commit failed: " . $conn->error);
    }
    
    echo json_encode(['success' => true]);
    
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    
    header('Content-Type: application/json');
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString() 
    ]);
    
    error_log("Product update error: " . $e->getMessage());
} finally {
    // Restore autocommit
    $conn->autocommit(true);
}